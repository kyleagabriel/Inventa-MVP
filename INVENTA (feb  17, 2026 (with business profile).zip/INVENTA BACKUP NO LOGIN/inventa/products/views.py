from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST
from django.contrib import messages
from decimal import Decimal
from django.db import transaction
from django.urls import reverse
from django.db.models import Exists, OuterRef
from django.utils import timezone
from .analytics import build_product_demand_profile
from .forms import ProductForm, PurchaseOrderForm, PurchaseOrderItemFormSet, SalesInvoiceForm, SalesInvoiceItemFormSet, ProductPriceForm, BusinessProfileForm
from .models import Product, PurchaseOrder, PurchaseOrderItem, SalesInvoice, SalesInvoiceItem, BusinessProfile

# Create your views here.
def get_business_profile():
    profile, _ = BusinessProfile.objects.get_or_create(
        pk=1,
        defaults={"business_name": "", "address": "", "tin": ""}
    )
    return profile


def product_list(request):
    products = (
        Product.objects
        .filter(is_archived=False)               # 👈 hide archived
        .annotate(
            has_po_items=Exists(
                PurchaseOrderItem.objects.filter(product=OuterRef("pk"))
            ),
            has_si_items=Exists(
                SalesInvoiceItem.objects.filter(product=OuterRef("pk"))
            ),
        )
        .order_by("name")
    )

    return render(
        request,
        "products/product_list.html",
        {"products": products},
    )

def add_product(request):
    if request.method == "POST":
        form = ProductForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("product_list")  
    else:
        form = ProductForm()
    return render(request, "products/add_product.html", {"form": form})


@require_POST
def delete_product(request, pk):
    product = get_object_or_404(Product, pk=pk)

    # ❌ Block delete if product already used in any transaction
    has_po = PurchaseOrderItem.objects.filter(product=product).exists()
    has_si = SalesInvoiceItem.objects.filter(product=product).exists()

    if has_po or has_si:
        messages.error(
            request,
            "This product already has transactions and cannot be deleted. "
            "You can archive it instead."
        )
        return redirect("product_list")

    # ✅ Safe to hard-delete
    product.delete()
    messages.success(request, f"Product {product.sku} deleted.")
    return redirect("product_list")

def po_create(request):
    profile = get_business_profile()

    if request.method == "POST":
        form = PurchaseOrderForm(request.POST)
        formset = PurchaseOrderItemFormSet(request.POST)

        if form.is_valid() and formset.is_valid():
            po = form.save(commit=False)

            # ✅ enforce profile values (so user never needs to type them)
            po.business_name = profile.business_name
            po.business_address = profile.address
            po.business_tin = profile.tin

            # ✅ enforce today's date
            po.date = timezone.localdate()

            po.is_confirmed = False
            po.confirmed_at = None
            po.save()

            formset.instance = po
            formset.save()

            messages.success(request, "PO saved as draft ✅")
            return redirect("po_detail", pk=po.pk)
    else:
        # ✅ Pre-fill on create
        form = PurchaseOrderForm(initial={
            "business_name": profile.business_name,
            "business_address": profile.address,
            "business_tin": profile.tin,
            "date": timezone.localdate(),
        })
        formset = PurchaseOrderItemFormSet()

        # ✅ Make profile fields read-only so user doesn't touch them
        for f in ["business_name", "business_address", "business_tin", "date"]:
            if f in form.fields:
                form.fields[f].widget.attrs["readonly"] = True

    return render(request, "products/po_create.html", {"form": form, "formset": formset, "mode": "create"})

@transaction.atomic
def po_edit(request, pk):
    po = get_object_or_404(PurchaseOrder, pk=pk)

    if po.is_confirmed:
        messages.error(request, "This PO is already confirmed and cannot be edited.")
        return redirect("po_detail", pk=po.pk)

    if request.method == "POST":
        form = PurchaseOrderForm(request.POST, instance=po)
        formset = PurchaseOrderItemFormSet(request.POST, instance=po)

        # ✅ debug prints AFTER variables exist
        print("✅ po_edit received POST for PO:", pk)
        print("FORM valid?", form.is_valid())
        print("FORMSET valid?", formset.is_valid())
        if not form.is_valid():
            print("FORM errors:", form.errors)
        if not formset.is_valid():
            print("FORMSET errors:", formset.errors)
            print("FORMSET non_form_errors:", formset.non_form_errors())

        if form.is_valid() and formset.is_valid():
            form.save()
            formset.save()
            messages.success(request, "Draft updated ✅")
            return redirect("po_detail", pk=po.pk)
    else:
        form = PurchaseOrderForm(instance=po)
        formset = PurchaseOrderItemFormSet(instance=po)

    return render(request, "products/po_create.html", {
        "form": form,
        "formset": formset,
        "mode": "edit",
        "po": po,
    })

def po_detail(request, pk):
    po = get_object_or_404(PurchaseOrder, pk=pk)

    from_stock_card = request.GET.get("from_stock_card")

    if from_stock_card:
        # Opened from a product's stock card
        back_url = reverse("product_stock_card", args=[from_stock_card])
        back_label = "Back to Stock Card"
    else:
        # Normal behavior
        back_url = reverse("product_list")  # or "po_list" if you prefer
        back_label = "Back to Inventory"

    context = {
        "po": po,
        "back_url": back_url,
        "back_label": back_label,
    }
    return render(request, "products/po_detail.html", context)
    
def po_confirm(request, pk):
    if request.method != "POST":
        return redirect("po_detail", pk=pk)

    po = get_object_or_404(PurchaseOrder, pk=pk)

    if po.is_confirmed:
        messages.info(request, "This PO is already confirmed ✅")
        return redirect("po_detail", pk=po.pk)

    po.confirm_and_increase_stock()
    messages.success(request, "PO confirmed ✅ Stock updated 📦")
    return redirect("po_detail", pk=po.pk)



@transaction.atomic
def si_create(request):
    profile = get_business_profile()
    """Create a NEW Sales Invoice as DRAFT (no stock movement yet)."""
    if request.method == "POST":
        form = SalesInvoiceForm(request.POST)
        formset = SalesInvoiceItemFormSet(request.POST)

        if form.is_valid() and formset.is_valid():
            # 🔴 STOCK VALIDATION ON SAVE DRAFT (block oversell)
            requested_by_product = {}

            for f in formset:
                data = getattr(f, "cleaned_data", None) or {}
                if not data or data.get("DELETE"):
                    continue

                product = data.get("product")
                qty = data.get("quantity_sold") or 0
                if product and qty > 0:
                    requested_by_product[product] = requested_by_product.get(product, 0) + qty

            violations = []
            for product, total_qty in requested_by_product.items():
                product.refresh_from_db()
                if total_qty > product.quantity:
                    violations.append((product, total_qty, product.quantity))

            if violations:
                # attach errors per violating row so user sees it
                for f in formset:
                    data = getattr(f, "cleaned_data", None) or {}
                    if data.get("DELETE"):
                        continue
                    product = data.get("product")
                    if not product:
                        continue

                    for (vp, req, avail) in violations:
                        if product == vp:
                            f.add_error(
                                "quantity_sold",
                                f"Requested total {req}, but only {avail} in stock."
                            )

                # re-render page (do not save)
                products = Product.objects.all().order_by("name")
                return render(request, "products/si_create.html", {
                    "form": form,
                    "formset": formset,
                    "products": products,
                    "mode": "create",
                    "stock_error": True,
                    "stock_error_info": None,
                })


            invoice = form.save(commit=False)

            # ✅ enforce profile values
            invoice.business_name = profile.business_name
            invoice.business_address = profile.address
            invoice.business_tin = profile.tin

            # ✅ enforce today's date
            invoice.date = timezone.localdate()

            invoice.is_confirmed = False
            invoice.confirmed_at = None
            invoice.save()

            formset.instance = invoice
            formset.save()

            messages.success(request, f"Invoice #{invoice.id} saved as draft ✅")
            return redirect("si_detail", pk=invoice.pk)
    else:
        profile = get_business_profile()
        form = SalesInvoiceForm(initial={
            "business_name": profile.business_name,
            "business_address": profile.address,
            "business_tin": profile.tin,
            "date": timezone.localdate(),
        })
        formset = SalesInvoiceItemFormSet()

        for f in ["business_name", "business_address", "business_tin", "date"]:
            if f in form.fields:
                form.fields[f].widget.attrs["readonly"] = True

    products = Product.objects.all().order_by("name")

    return render(
        request,
        "products/si_create.html",
        {
            "form": form,
            "formset": formset,
            "products": products,
            # these can stay, but draft flow won't use stock_error anymore
            "stock_error": False,
            "stock_error_info": None,
        },
    )

def si_edit(request, pk):
    si = get_object_or_404(SalesInvoice, pk=pk)

    if si.is_confirmed:
        messages.error(request, "This SI is already confirmed and cannot be edited.")
        return redirect("si_detail", pk=si.pk)

    if request.method == "POST":
        form = SalesInvoiceForm(request.POST, instance=si)
        formset = SalesInvoiceItemFormSet(request.POST, instance=si)

        if form.is_valid() and formset.is_valid():
            # 🔴 STOCK VALIDATION ON SAVE DRAFT (block oversell)
            requested_by_product = {}

            for f in formset:
                data = getattr(f, "cleaned_data", None) or {}
                if not data or data.get("DELETE"):
                    continue

                product = data.get("product")
                qty = data.get("quantity_sold") or 0
                if product and qty > 0:
                    requested_by_product[product] = requested_by_product.get(product, 0) + qty

            violations = []
            for product, total_qty in requested_by_product.items():
                product.refresh_from_db()
                if total_qty > product.quantity:
                    violations.append((product, total_qty, product.quantity))

            if violations:
                # attach errors per violating row so user sees it
                for f in formset:
                    data = getattr(f, "cleaned_data", None) or {}
                    if data.get("DELETE"):
                        continue
                    product = data.get("product")
                    if not product:
                        continue

                    for (vp, req, avail) in violations:
                        if product == vp:
                            f.add_error(
                                "quantity_sold",
                                f"Requested total {req}, but only {avail} in stock."
                            )

                # re-render page (do not save)
                products = Product.objects.all().order_by("name")
                return render(request, "products/si_create.html", {
                    "form": form,
                    "formset": formset,
                    "products": products,
                    "mode": "edit",
                    "invoice": si,
                    "stock_error": True,
                    "stock_error_info": None,
                    })


            si = form.save()
            formset.save()
            messages.success(request, "Draft updated ✅")
            return redirect("si_detail", pk=si.pk)
    else:
        form = SalesInvoiceForm(instance=si)
        formset = SalesInvoiceItemFormSet(instance=si)

    return render(request, "products/si_create.html", {
    "form": form,
    "formset": formset,
    "products": Product.objects.all().order_by("name"),
    "mode": "edit",
    "invoice": si,  # IMPORTANT: template uses "invoice" in si_detail; consistent naming helps
    "stock_error": False,
    "stock_error_info": None,
    })


def si_detail(request, pk):
    invoice = get_object_or_404(SalesInvoice, pk=pk)

    from_stock_card = request.GET.get("from_stock_card")

    if from_stock_card:
        back_url = reverse("product_stock_card", args=[from_stock_card])
        back_label = "Back to Stock Card"
    else:
        back_url = reverse("product_list")  # or "si_list"
        back_label = "Back to Inventory"

    context = {
        "invoice": invoice,
        "back_url": back_url,
        "back_label": back_label,
    }
    return render(request, "products/si_detail.html", context)

def si_confirm(request, pk):
    """Confirm a DRAFT Sales Invoice: check stock, then decrease stock ONCE."""
    invoice = get_object_or_404(SalesInvoice, pk=pk)

    if invoice.is_confirmed:
        messages.info(request, "This invoice is already confirmed ✅")
        return redirect("si_detail", pk=invoice.pk)

    # 🔴 CHECK STOCK BEFORE CONFIRMING
    requested_by_product = {}

    # IMPORTANT: use the SAVED items now (not formset)
    for item in invoice.items.all():  # adjust if your related_name isn't "items"
        product = item.product
        qty = item.quantity_sold or 0
        if product and qty > 0:
            requested_by_product.setdefault(product, 0)
            requested_by_product[product] += qty

    for product, total_qty in requested_by_product.items():
        product.refresh_from_db()  # ensure latest qty (in case other txns happened)
        if total_qty > product.quantity:
            messages.error(
                request,
                f"Not enough stock for {product.name} ({product.sku}). "
                f"Requested {total_qty}, available {product.quantity}."
            )
            return redirect("si_detail", pk=invoice.pk)

    # ✅ OK TO CONFIRM
    invoice.confirm_and_decrease_stock()
    messages.success(request, f"Invoice #{invoice.id} confirmed ✅ Stock updated 🧾")
    return redirect("si_detail", pk=invoice.pk)

def product_stock_card(request, pk):
    product = get_object_or_404(Product, pk=pk)

    # Handle selling price update
    if request.method == "POST":
        price_form = ProductPriceForm(request.POST, instance=product)
        if price_form.is_valid():
            price_form.save()
            return redirect(request.path)
    else:
        price_form = ProductPriceForm(instance=product)

    entries = []
    total_qty_in = 0
    total_cost = Decimal("0.00")

    # 🟢 IN: Confirmed Purchase Orders only
    po_items = (
        PurchaseOrderItem.objects
        .filter(product=product, po__is_confirmed=True)   # ✅ confirmed only
        .select_related("po")
    )
    for item in po_items:
        po = item.po
        tx_datetime = po.confirmed_at or po.date  # ✅ use confirmed_at, fallback to date

        entries.append({
            "date": tx_datetime,
            "type": "IN",
            "ref_type": "PO",
            "ref_id": po.id,
            "partner": po.supplier_name,
            "qty_in": item.quantity_received,
            "qty_out": 0,
        })

        total_qty_in += item.quantity_received
        total_cost += item.unit_price * item.quantity_received

    # 🔴 OUT: Confirmed Sales Invoices only
    si_items = (
        SalesInvoiceItem.objects
        .filter(product=product, invoice__is_confirmed=True)  # ✅ confirmed only
        .select_related("invoice")
    )
    for item in si_items:
        inv = item.invoice
        tx_datetime = inv.confirmed_at or inv.date  # ✅ use confirmed_at, fallback to date

        entries.append({
            "date": tx_datetime,
            "type": "OUT",
            "ref_type": "SI",
            "ref_id": inv.id,
            "partner": inv.customer_name,
            "qty_in": 0,
            "qty_out": item.quantity_sold,
        })

    # 🧮 Compute correct balances

    # 1) sort oldest → newest
    entries.sort(key=lambda e: e["date"])

    # 2) net movement from all confirmed transactions
    total_delta = sum(e["qty_in"] - e["qty_out"] for e in entries)

    # 3) infer opening quantity so last balance = product.quantity
    current_qty = product.quantity
    opening_qty = current_qty - total_delta

    # 4) walk forward in time and assign running balance
    running = opening_qty
    for e in entries:
        delta = e["qty_in"] - e["qty_out"]
        running += delta
        e["balance"] = running

    # 5) for display: newest at the top
    entries.sort(key=lambda e: e["date"], reverse=True)

    # Average cost from confirmed IN movements only
    average_cost = (total_cost / total_qty_in) if total_qty_in > 0 else None

    context = {
        "product": product,
        "entries": entries,
        "average_cost": average_cost,
        "price_form": price_form,
    }
    return render(request, "products/stock_card.html", context)

@require_POST
def archive_product(request, pk):
    product = get_object_or_404(Product, pk=pk)
    product.is_archived = True
    product.save(update_fields=["is_archived"])

    messages.success(
        request,
        f"Product {product.sku} archived. It will no longer appear in the product list."
    )
    return redirect("product_list")

def archived_product_list(request):
    products = (
        Product.objects
        .filter(is_archived=True)
        .annotate(
            has_po_items=Exists(
                PurchaseOrderItem.objects.filter(product=OuterRef("pk"))
            ),
            has_si_items=Exists(
                SalesInvoiceItem.objects.filter(product=OuterRef("pk"))
            ),
        )
        .order_by("name")
    )

    return render(
        request,
        "products/archived_products.html",
        {"products": products},
    )

@require_POST
def unarchive_product(request, pk):
    product = get_object_or_404(Product, pk=pk)
    product.is_archived = False
    product.save(update_fields=["is_archived"])
    messages.success(request, f"{product.sku} restored.")
    return redirect("archived_products")

# -------------- ANALYTICS -----------------------

def inventory_intel(request):
    """
    Dashboard: per-product demand, forecast, ROP & stockout risk.
    """
    products = (
        Product.objects
        .filter(is_archived=False)
        .annotate(
            has_po_items=Exists(
                PurchaseOrderItem.objects.filter(product=OuterRef("pk"))
            ),
            has_si_items=Exists(
                SalesInvoiceItem.objects.filter(product=OuterRef("pk"))
            ),
        )
        .order_by("name")
    )

    rows = []
    for p in products:
        profile = build_product_demand_profile(p)
        rows.append({
            "product": p,
            **profile,
        })

    total_skus = len(rows)
    high_risk = sum(1 for r in rows if r["stockout_risk_14d"] > 0.7)
    med_risk = sum(1 for r in rows if 0.3 < r["stockout_risk_14d"] <= 0.7)
    low_risk = sum(1 for r in rows if r["stockout_risk_14d"] <= 0.3)

    total_recommended_units = sum(r["recommended_order_qty"] for r in rows)

    if rows:
        avg_daily_demand_overall = round(
            sum(r["forecast_daily"] for r in rows) / len(rows), 2
        )
    else:
        avg_daily_demand_overall = 0.0

    summary = {
        "total_skus": total_skus,
        "high_risk": high_risk,
        "med_risk": med_risk,
        "low_risk": low_risk,
        "total_recommended_units": total_recommended_units,
        "avg_daily_demand_overall": avg_daily_demand_overall,
    }

    # Top 5 highest-risk SKUs
    top_risky = sorted(
        rows,
        key=lambda r: r["stockout_risk_14d"],
        reverse=True,
    )[:5]

    context = {
        "rows": rows,
        "summary": summary,
        "top_risky": top_risky,
    }
    return render(request, "products/inventory_intel.html", context)

def business_profile(request):
    # MVP: single global profile (always edit row #1)
    profile, _ = BusinessProfile.objects.get_or_create(
        pk=1,
        defaults={
            "business_name": "",
            "address": "",
            "tin": "",
        }
    )

    if request.method == "POST":
        form = BusinessProfileForm(request.POST, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, "Business profile saved ✅")
            return redirect("business_profile")
    else:
        form = BusinessProfileForm(instance=profile)

    return render(request, "products/business_profile.html", {
        "form": form,
        "profile": profile,
    })