from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST
from django.contrib import messages
from decimal import Decimal
from django.urls import reverse
from .forms import ProductForm, PurchaseOrderForm, PurchaseOrderItemFormSet, SalesInvoiceForm, SalesInvoiceItemFormSet, ProductPriceForm
from .models import Product, PurchaseOrder, PurchaseOrderItem, SalesInvoice, SalesInvoiceItem


# Create your views here.
def product_list(request):
    products = Product.objects.all().order_by("name")
    return render(request, "products/product_list.html", {"products": products})

def add_product(request):
    if request.method == "POST":
        form = ProductForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("product_list")  
    else:
        form = ProductForm()
    return render(request, "products/add_product.html", {"form": form})

@require_POST
def delete_product(request, pk):
    product = get_object_or_404(Product, pk=pk)
    product.delete()  # hard delete; swap to soft delete if you prefer
    return redirect("product_list")

def po_create(request):
    """Encode a new Purchase Order (header + multiple items)."""
    if request.method == "POST":
        form = PurchaseOrderForm(request.POST)
        formset = PurchaseOrderItemFormSet(request.POST)
        if form.is_valid() and formset.is_valid():
            po = form.save()
            formset.instance = po
            formset.save()

            # 👇 NEW: immediately update stock
            po.confirm_and_increase_stock()

            messages.success(request, f"PO #{po.id} saved and stock updated ✅")
            return redirect("po_detail", pk=po.pk)
    else:
        form = PurchaseOrderForm()
        formset = PurchaseOrderItemFormSet()
    return render(request, "products/po_create.html", {"form": form, "formset": formset})


def po_detail(request, pk):
    po = get_object_or_404(PurchaseOrder, pk=pk)

    from_stock_card = request.GET.get("from_stock_card")

    if from_stock_card:
        # Opened from a product's stock card
        back_url = reverse("product_stock_card", args=[from_stock_card])
        back_label = "Back to Stock Card"
    else:
        # Normal behavior
        back_url = reverse("product_list")  # or "po_list" if you prefer
        back_label = "Back to Inventory"

    context = {
        "po": po,
        "back_url": back_url,
        "back_label": back_label,
    }
    return render(request, "products/po_detail.html", context)
    
def po_confirm(request, pk):
    """Confirm the PO and increase stock based on line items."""
    po = get_object_or_404(PurchaseOrder, pk=pk)
    po.confirm_and_increase_stock()
    messages.success(request, f"PO #{po.id} confirmed. Stock updated ✅")
    return redirect("product_list")  # or redirect back to po_detail

def si_create(request):
    """Encode a new Sales Invoice (out products)."""
    if request.method == "POST":
        form = SalesInvoiceForm(request.POST)
        formset = SalesInvoiceItemFormSet(request.POST)
        if form.is_valid() and formset.is_valid():
            invoice = form.save()
            formset.instance = invoice
            formset.save()

            # 👇 NEW: immediately decrease stock
            invoice.confirm_and_decrease_stock()

            messages.success(request, f"Invoice #{invoice.id} saved and stock updated ✅")
            return redirect("si_detail", pk=invoice.pk)
    else:
        form = SalesInvoiceForm()
        formset = SalesInvoiceItemFormSet()

    return render(request, "products/si_create.html", {"form": form, "formset": formset})



def si_detail(request, pk):
    invoice = get_object_or_404(SalesInvoice, pk=pk)

    from_stock_card = request.GET.get("from_stock_card")

    if from_stock_card:
        back_url = reverse("product_stock_card", args=[from_stock_card])
        back_label = "Back to Stock Card"
    else:
        back_url = reverse("product_list")  # or "si_list"
        back_label = "Back to Inventory"

    context = {
        "invoice": invoice,
        "back_url": back_url,
        "back_label": back_label,
    }
    return render(request, "products/si_detail.html", context)

def si_confirm(request, pk):
    """Confirm the invoice and decrease stock based on line items."""
    invoice = get_object_or_404(SalesInvoice, pk=pk)
    invoice.confirm_and_decrease_stock()
    messages.success(request, f"Invoice #{invoice.id} confirmed. Stock updated ✅")
    return redirect("product_list")


def product_stock_card(request, pk):
    product = get_object_or_404(Product, pk=pk)

    # Handle selling price update
    if request.method == "POST":
        price_form = ProductPriceForm(request.POST, instance=product)
        if price_form.is_valid():
            price_form.save()
            return redirect(request.path)
    else:
        price_form = ProductPriceForm(instance=product)

    entries = []
    total_qty_in = 0
    total_cost = Decimal("0.00")

    # 🟢 IN: Purchase Orders
    po_items = PurchaseOrderItem.objects.filter(product=product).select_related("po")
    for item in po_items:
        po = item.po
        tx_datetime = po.created_at  # use full date+time

        entries.append({
            "date": tx_datetime,
            "type": "IN",
            "ref_type": "PO",
            "ref_id": po.id,
            "partner": po.supplier_name,
            "qty_in": item.quantity_received,
            "qty_out": 0,
        })

        total_qty_in += item.quantity_received
        total_cost += item.unit_price * item.quantity_received

    # 🔴 OUT: Sales Invoices
    si_items = SalesInvoiceItem.objects.filter(product=product).select_related("invoice")
    for item in si_items:
        inv = item.invoice
        tx_datetime = inv.created_at  # use full date+time

        entries.append({
            "date": tx_datetime,
            "type": "OUT",
            "ref_type": "SI",
            "ref_id": inv.id,
            "partner": inv.customer_name,
            "qty_in": 0,
            "qty_out": item.quantity_sold,
        })

    # 🧮 Compute correct balances

    # 1) sort oldest → newest by datetime
    entries.sort(key=lambda e: e["date"])

    # 2) net movement from all transactions
    total_delta = sum(e["qty_in"] - e["qty_out"] for e in entries)

    # 3) infer opening quantity so last balance = product.quantity
    current_qty = product.quantity
    opening_qty = current_qty - total_delta

    # 4) walk forward in time and assign running balance
    running = opening_qty
    for e in entries:
        delta = e["qty_in"] - e["qty_out"]
        running += delta
        e["balance"] = running

    # 5) for display: newest at the top
    entries.sort(key=lambda e: e["date"], reverse=True)

    # Average cost from IN movements
    average_cost = (total_cost / total_qty_in) if total_qty_in > 0 else None

    context = {
        "product": product,
        "entries": entries,
        "average_cost": average_cost,
        "price_form": price_form,
    }
    return render(request, "products/stock_card.html", context)