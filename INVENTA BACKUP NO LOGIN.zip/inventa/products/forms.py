from django import forms
from django.forms import inlineformset_factory
from .models import Product, PurchaseOrder, PurchaseOrderItem, SalesInvoice, SalesInvoiceItem

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ["sku", "name", "selling_price"]   # quantity removed

    def clean(self):
        cleaned = super().clean()
        # Ensure quantity is always 0 for new products
        self.instance.quantity = 0
        return cleaned
    
class ProductPriceForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ["selling_price"]
        widgets = {
            "selling_price": forms.NumberInput(attrs={
                "step": "0.01",
                "min": "0",
                "class": "price-input",
                "placeholder": "0.00",
            })
        }

class PurchaseOrderForm(forms.ModelForm):
    class Meta:
        model = PurchaseOrder
        fields = [
            "supplier_name", "supplier_address",
            "business_name", "business_address",
            "business_tin", "business_contact", "business_email",
            "payment_terms", "tax_percent", "date",
            "footer_note",
        ]


class PurchaseOrderItemForm(forms.ModelForm):
    class Meta:
        model = PurchaseOrderItem
        fields = ["product", "quantity_received", "unit_price"]
        widgets = {
            "quantity_received": forms.NumberInput(attrs={"min": 1, "placeholder": "Qty"}),
            "unit_price": forms.NumberInput(attrs={"step": "0.01", "placeholder": "0.00"}),
        }

PurchaseOrderItemFormSet = inlineformset_factory(
    parent_model=PurchaseOrder,
    model=PurchaseOrderItem,
    form=PurchaseOrderItemForm,
    extra=0,          # one blank row by default
    can_delete=True,  # allow removing rows
    min_num=1,
    validate_min=True,
)

class SalesInvoiceForm(forms.ModelForm):
    class Meta:
        model = SalesInvoice
        fields = [
            "customer_name", "customer_address",
            "business_name", "business_address",
            "business_tin", "business_contact", "business_email",
            "date", "tax_percent", "payment_terms",
            "footer_note",
        ]



class SalesInvoiceItemForm(forms.ModelForm):
    class Meta:
        model = SalesInvoiceItem
        fields = ["product", "quantity_sold", "unit_price"]
        widgets = {
            "quantity_sold": forms.NumberInput(attrs={"min": 1, "placeholder": "Qty"}),
            "unit_price": forms.NumberInput(attrs={"step": "0.01", "placeholder": "0.00"}),
        }


SalesInvoiceItemFormSet = inlineformset_factory(
    parent_model=SalesInvoice,
    model=SalesInvoiceItem,
    form=SalesInvoiceItemForm,
    extra=0,
    can_delete=True,
    min_num=1,
    validate_min=True,
)
