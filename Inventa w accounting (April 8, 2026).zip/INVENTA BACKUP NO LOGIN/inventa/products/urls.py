from django.urls import path
from . import views

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("products/", views.product_list, name="product_list"),
    path("api/products/search/", views.product_search_api, name="product_search_api"),
    path("products/add/", views.add_product, name="add_product"),
    path("products/quick-add/", views.add_product_quick, name="add_product_quick"),
    path("products/<int:pk>/delete/", views.delete_product, name="delete_product"),

     # 🆕 Stock card per product
    path("products/<int:pk>/stock-card/", views.product_stock_card, name="product_stock_card"),

    path("po/new/", views.po_create, name="po_create"),
    path("po/<int:pk>/", views.po_detail, name="po_detail"),
    path("po/<int:pk>/edit/", views.po_edit, name="po_edit"),
    path("po/", views.po_list, name="po_list"),
    path("po/<int:pk>/confirm/", views.po_confirm, name="po_confirm"),
    path("po/<int:pk>/fulfill/", views.po_fulfill, name="po_fulfill"),
    path("po/<int:pk>/cancel/", views.po_cancel, name="po_cancel"),

    # Sales Invoices
    path("si/", views.si_list, name="si_list"),
    path("si/new/", views.si_create, name="si_create"),
    path("si/<int:pk>/", views.si_detail, name="si_detail"),
    path("si/<int:pk>/edit/", views.si_edit, name="si_edit"),
    path("si/<int:pk>/confirm/", views.si_confirm, name="si_confirm"),
    path("si/<int:pk>/fulfill/", views.si_fulfill, name="si_fulfill"),
    path("si/<int:pk>/cancel/", views.si_cancel, name="si_cancel"),
    
    path("products/<int:pk>/archive/", views.archive_product, name="archive_product"), 
    path("products/archived/", views.archived_product_list, name="archived_products"),
    path("products/<int:pk>/unarchive/", views.unarchive_product, name="unarchive_product"),

    path("analytics/inventory/", views.inventory_intel, name="inventory_intel"),

    path("profile/", views.business_profile, name="business_profile"),

    # E-Commerce Sales
    path("ecom/", views.ecom_list, name="ecom_list"),
    path("ecom/new/", views.ecom_create, name="ecom_create"),
    path("ecom/<int:pk>/", views.ecom_detail, name="ecom_detail"),
    path("ecom/<int:pk>/edit/", views.ecom_edit, name="ecom_edit"),
    path("ecom/<int:pk>/confirm/", views.ecom_confirm, name="ecom_confirm"),
    path("ecom/<int:pk>/fulfill/", views.ecom_fulfill, name="ecom_fulfill"),
    path("ecom/<int:pk>/cancel/", views.ecom_cancel, name="ecom_cancel"),

    # Category API
    path("api/categories/", views.category_search_api, name="category_search_api"),
    path("api/categories/list/", views.category_list_api, name="category_list_api"),
    path("api/categories/create/", views.category_create_api, name="category_create_api"),
    path("api/categories/<int:pk>/rename/", views.category_rename_api, name="category_rename_api"),
    path("api/categories/<int:pk>/delete/", views.category_delete_api, name="category_delete_api"),
    path("api/products/<int:product_pk>/assign-category/", views.category_assign_api, name="category_assign_api"),

    # Accounting
    path("accounting/pl/", views.accounting_pl, name="accounting_pl"),
    path("accounting/obligations/", views.accounting_obligations, name="accounting_obligations"),
    path("accounting/obligations/<str:model>/<int:pk>/pay/", views.accounting_log_payment, name="accounting_log_payment"),
    path("accounting/obligations/<str:model>/<int:pk>/payments/<int:payment_pk>/delete/", views.accounting_delete_payment, name="accounting_delete_payment"),
    path("accounting/expenses/", views.accounting_expenses, name="accounting_expenses"),
    path("accounting/expenses/<int:pk>/edit/", views.accounting_expense_edit, name="accounting_expense_edit"),
    path("accounting/expenses/<int:pk>/delete/", views.accounting_expense_delete, name="accounting_expense_delete"),
    path("accounting/obligations/<str:model>/<int:pk>/payments/", views.accounting_payment_history, name="accounting_payment_history"),
    ]
