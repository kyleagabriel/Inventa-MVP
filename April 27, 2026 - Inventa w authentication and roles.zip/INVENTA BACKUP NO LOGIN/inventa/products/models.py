from decimal import Decimal, ROUND_HALF_UP
from django.db import models, transaction
from django.utils import timezone
from django.core.validators import MinValueValidator, RegexValidator
from django.db.models import F
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType

# Create your models here.
class Product(models.Model):
    sku = models.CharField(max_length=64)
    name = models.CharField(max_length=255)
    quantity = models.IntegerField(default=0)
    category = models.ForeignKey(
        "Category",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="products",
    )
    selling_price = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        null=True,
        blank=True,
    )
    avg_cost = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal("0.00"),
        help_text="Weighted average cost per unit. Auto-updated when stock is received.",
    )
    is_archived = models.BooleanField(default=False)
    business_profile = models.ForeignKey(
        'BusinessProfile',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='products',
    )

    class Meta:
        unique_together = ("business_profile", "sku")

    def __str__(self):
        return f"{self.sku} — {self.name}"
    
class PurchaseOrder(models.Model):
    # Supplier Info
    supplier_name = models.CharField(max_length=255)
    supplier_address = models.CharField(max_length=255, blank=True)

    # Business Info
    business_name = models.CharField(max_length=255)
    business_address = models.CharField(max_length=255, blank=True)

    business_tin = models.CharField(max_length=64, blank=True)
    business_contact = models.CharField(max_length=64, blank=True)
    business_email = models.CharField(max_length=255, blank=True)
    footer_note = models.CharField(
        max_length=255,
        blank=True,
        default="THIS DOCUMENT IS NOT VALID FOR CLAIMING INPUT TAX"
    )


    # Payment Terms
    payment_terms = models.CharField(max_length=255, default="COD")

    # Date
    date = models.DateField(default=timezone.now)
    due_date = models.DateField(null=True, blank=True)

    # Tax and totals
    tax_percent = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal("12.00"),
        help_text="Tax rate as a whole percent (e.g., 12.00 for 12%)"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    is_confirmed = models.BooleanField(default=False)
    confirmed_at = models.DateTimeField(null=True, blank=True)
    
    is_fulfilled = models.BooleanField(default=False)
    fulfilled_at = models.DateTimeField(null=True, blank=True)

    is_cancelled = models.BooleanField(default=False)
    cancelled_at = models.DateTimeField(null=True, blank=True)

    business_profile = models.ForeignKey(
        'BusinessProfile',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='purchase_orders',
    )

    def __str__(self):
        return f"PO #{self.id} — {self.supplier_name} ({self.date})"

    # ---------- COMPUTED FIELDS ----------
    @property
    def po_number(self):
        if not self.pk:
            return ""
        return f"{self.date:%Y/%m/%d}-PO{self.pk}"


    @property
    def subtotal(self):
        # Sum of all line totals (unit_price × qty)
        return sum((item.line_total for item in self.items.all()), Decimal("0.00"))

    @property
    def total_order_price(self):
        return self.subtotal

    def tax_value(self):
        # Convert tax_amount (12) → 0.12
        rate = self.tax_percent / Decimal("100")
        value = self.subtotal * rate
        return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    @property
    def total_with_tax(self):
        rate = self.tax_percent / Decimal("100")  # convert to 0.12
        total = self.subtotal * (Decimal("1.00") + rate)
        return total.quantize(Decimal("0.01"))

    @property
    def status(self):
        if self.is_cancelled:
            return "Cancelled"
        if self.is_fulfilled:
            return "Fulfilled"
        if self.is_confirmed:
            return "Confirmed"
        return "Draft"

    @property
    def total_quantity_ordered(self):
        return sum(item.quantity_received for item in self.items.all())

    @property
    def total_quantity_fulfilled(self):
        return sum(r.quantity for r in FulfillmentRecord.objects.filter(po_item__po=self))

    @transaction.atomic
    def confirm_and_increase_stock(self):
        """Confirm PO — marks it as sent to supplier. Stock does NOT change here."""
        po = PurchaseOrder.objects.select_for_update().get(pk=self.pk)
        if po.is_confirmed:
            return
        po.is_confirmed = True
        po.confirmed_at = timezone.now()
        po.save(update_fields=["is_confirmed", "confirmed_at"])

    @transaction.atomic
    def cancel(self):
        """Cancel PO. Cannot cancel if already fully fulfilled."""
        po = PurchaseOrder.objects.select_for_update().get(pk=self.pk)
        if po.is_fulfilled:
            raise ValueError("A fully fulfilled PO cannot be cancelled.")
        if po.is_cancelled:
            return
        po.is_cancelled = True
        po.cancelled_at = timezone.now()
        po.save(update_fields=["is_cancelled", "cancelled_at"])

    @property
    def total_paid(self):
        ct = ContentType.objects.get_for_model(self.__class__)
        return PaymentRecord.objects.filter(
            content_type=ct, object_id=self.pk
        ).aggregate(total=models.Sum("amount"))["total"] or Decimal("0.00")

    @property
    def payment_status(self):
        if not self.is_fulfilled:
            return "N/A"
        amount_due = self.total_with_tax  # use net_payout instead for EcommerceSale
        paid = self.total_paid
        today = timezone.localdate()
        if paid >= amount_due:
            return "Paid"
        if paid > 0:
            if self.due_date and self.due_date < today:
                return "Overdue"
            return "Partially Paid"
        if self.due_date and self.due_date < today:
            return "Overdue"
        return "Unpaid"

    @property
    def balance_due(self):
        return max(Decimal("0.00"), self.total_with_tax - self.total_paid)

class PurchaseOrderItem(models.Model):
    # Link to Purchase Order
    po = models.ForeignKey(PurchaseOrder, on_delete=models.CASCADE, related_name="items")

    # 🔗 Link to Product
    product = models.ForeignKey(Product, on_delete=models.PROTECT)

    # Snapshot fields (keep historical name/SKU for printing)
    product_sku = models.CharField(max_length=64, blank=True)
    product_name = models.CharField(max_length=255, blank=True)

    # Order details
    quantity_received = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    unit_price = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(Decimal("0.00"))])

    def __str__(self):
        return f"PO#{self.po_id} • {self.product_sku or self.product.sku} x {self.quantity_received}"

    def save(self, *args, **kwargs):
        # Automatically copy product SKU and name for recordkeeping
        if not self.product_sku:
            self.product_sku = self.product.sku
        if not self.product_name:
            self.product_name = self.product.name
        super().save(*args, **kwargs)

    @property
    def line_total(self):
        # Total price per product
        return self.unit_price * self.quantity_received

    @property
    def quantity_fulfilled(self):
        return sum(r.quantity for r in self.fulfillments.all())

    @property
    def quantity_remaining(self):
        return self.quantity_received - self.quantity_fulfilled


class FulfillmentRecord(models.Model):
    """Tracks partial or full receipt of a PurchaseOrderItem."""
    po_item = models.ForeignKey(
        PurchaseOrderItem, on_delete=models.CASCADE, related_name="fulfillments"
    )
    quantity = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    received_at = models.DateTimeField(default=timezone.now)
    notes = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return f"Fulfillment of PO#{self.po_item.po_id} — {self.po_item.product_sku} x {self.quantity}"
    
class SalesInvoice(models.Model):
    # Customer Info
    customer_name = models.CharField(max_length=255)
    customer_address = models.CharField(max_length=255, blank=True)

    # Business Info (your business)
    business_name = models.CharField(max_length=255)
    business_address = models.CharField(max_length=255, blank=True)

    business_tin = models.CharField(max_length=64, blank=True)
    business_contact = models.CharField(max_length=64, blank=True)
    business_email = models.CharField(max_length=255, blank=True)
    footer_note = models.CharField(max_length=255, blank=True, default="THIS DOCUMENT IS NOT VALID FOR CLAIMING INPUT TAX")

    # Payment Terms
    payment_terms = models.CharField(max_length=255, default="COD")

    # Date
    date = models.DateField(default=timezone.now)
    due_date = models.DateField(null=True, blank=True)

    # Tax and totals
    tax_percent = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal("12.00"),
        help_text="Tax rate as a whole percent (e.g. 12.00 for 12%)"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    is_confirmed = models.BooleanField(default=False)
    confirmed_at = models.DateTimeField(null=True, blank=True)

    is_fulfilled = models.BooleanField(default=False)
    fulfilled_at = models.DateTimeField(null=True, blank=True)

    is_cancelled = models.BooleanField(default=False)
    cancelled_at = models.DateTimeField(null=True, blank=True)

    business_profile = models.ForeignKey(
        'BusinessProfile',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='sales_invoices',
    )

    def __str__(self):
        return f"SI #{self.id} — {self.customer_name} ({self.date})"

    # ---------- COMPUTED FIELDS ----------
    @property
    def si_number(self):
        if not self.pk:
            return ""
        return f"{self.date:%Y/%m/%d}-SI{self.pk}"


    @property
    def subtotal(self):
        return sum((item.line_total for item in self.items.all()), Decimal("0.00"))

    def tax_value(self):
        rate = self.tax_percent / Decimal("100")
        value = self.subtotal * rate
        return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    @property
    def total_with_tax(self):
        rate = self.tax_percent / Decimal("100")
        total = self.subtotal * (Decimal("1.00") + rate)
        return total.quantize(Decimal("0.01"))

    @property
    def status(self):
        if self.is_cancelled:
            return "Cancelled"
        if self.is_fulfilled:
            return "Fulfilled"
        if self.is_confirmed:
            has_fulfillments = SIFulfillmentRecord.objects.filter(si_item__invoice=self).exists()
            if has_fulfillments:
                return "Partial"
            return "Confirmed"
        return "Draft"

    @property
    def total_quantity_ordered(self):
        return sum(item.quantity_sold for item in self.items.all())

    @property
    def total_quantity_fulfilled(self):
        return sum(r.quantity for r in SIFulfillmentRecord.objects.filter(si_item__invoice=self))

    @transaction.atomic
    def confirm(self):
        """
        Confirm the SI — locks editing and commits it to the customer.
        Stock is NOT deducted here. Deduction happens per fulfillment record.
        Allowed even if stock is insufficient (lead-time use case).
        """
        si = SalesInvoice.objects.select_for_update().get(pk=self.pk)
        if si.is_confirmed:
            return
        si.is_confirmed = True
        si.confirmed_at = timezone.now()
        si.save(update_fields=["is_confirmed", "confirmed_at"])

    @transaction.atomic
    def cancel(self):
        """
        Cancel the SI. Cannot cancel a fully fulfilled SI.
        Stock already deducted through partial fulfillments stays deducted.
        """
        si = SalesInvoice.objects.select_for_update().get(pk=self.pk)
        if si.is_fulfilled:
            raise ValueError("A fully fulfilled Sales Invoice cannot be cancelled.")
        if si.is_cancelled:
            return
        si.is_cancelled = True
        si.cancelled_at = timezone.now()
        si.save(update_fields=["is_cancelled", "cancelled_at"])

    @property
    def total_paid(self):
        ct = ContentType.objects.get_for_model(self.__class__)
        return PaymentRecord.objects.filter(
            content_type=ct, object_id=self.pk
        ).aggregate(total=models.Sum("amount"))["total"] or Decimal("0.00")

    @property
    def payment_status(self):
        if not self.is_fulfilled:
            return "N/A"
        amount_due = self.total_with_tax  # use net_payout instead for EcommerceSale
        paid = self.total_paid
        today = timezone.localdate()
        if paid >= amount_due:
            return "Paid"
        if paid > 0:
            if self.due_date and self.due_date < today:
                return "Overdue"
            return "Partially Paid"
        if self.due_date and self.due_date < today:
            return "Overdue"
        return "Unpaid"

    @property
    def balance_due(self):
        return max(Decimal("0.00"), self.total_with_tax - self.total_paid)

class SalesInvoiceItem(models.Model):
    # Link to Sales Invoice
    invoice = models.ForeignKey(SalesInvoice, on_delete=models.CASCADE, related_name="items")

    # 🔗 Link to Product
    product = models.ForeignKey(Product, on_delete=models.PROTECT)

    # Snapshot fields
    product_sku = models.CharField(max_length=64, blank=True)
    product_name = models.CharField(max_length=255, blank=True)

    # Details
    quantity_sold = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    unit_price = models.DecimalField(
        max_digits=12, decimal_places=2,
        validators=[MinValueValidator(Decimal("0.00"))]
    )
    cost_override = models.DecimalField(
    max_digits=12,
    decimal_places=2,
    null=True,
    blank=True,
    help_text="Override the avg_cost used for COGS calculation. Leave blank to use product's avg_cost.",
    )


    def __str__(self):
        return f"SI#{self.invoice_id} • {self.product_sku or self.product.sku} x {self.quantity_sold}"

    def save(self, *args, **kwargs):
        if not self.product_sku:
            self.product_sku = self.product.sku
        if not self.product_name:
            self.product_name = self.product.name
        super().save(*args, **kwargs)

    @property
    def line_total(self):
        return self.unit_price * self.quantity_sold

    @property
    def quantity_fulfilled(self):
        """Units already delivered to the customer for this line item."""
        return sum(r.quantity for r in self.fulfillments.all())

    @property
    def quantity_remaining(self):
        """Units still owed to the customer."""
        return self.quantity_sold - self.quantity_fulfilled

    @property
    def has_stock_warning(self):
        """True if we cannot currently fulfill the remaining quantity."""
        return self.quantity_remaining > 0 and self.product.quantity < self.quantity_remaining

    @property
    def cogs(self):
        cost = self.cost_override if self.cost_override is not None else self.product.avg_cost
        return cost * self.quantity_sold

class SIFulfillmentRecord(models.Model):
    """
    Tracks partial or full delivery of a SalesInvoiceItem to the customer.
    Each record = one physical delivery batch.
    Stock is deducted from the product when each record is created.
    """
    si_item = models.ForeignKey(
        SalesInvoiceItem, on_delete=models.CASCADE, related_name="fulfillments"
    )
    quantity = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    delivered_at = models.DateTimeField(default=timezone.now)
    notes = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return f"SI Delivery SI#{self.si_item.invoice_id} — {self.si_item.product_sku} x {self.quantity}"

class BusinessProfile(models.Model):
    business_name = models.CharField(max_length=255)
    address = models.CharField(max_length=255)

    tin = models.CharField(
        max_length=15,
        verbose_name="TIN #",
        validators=[
            RegexValidator(
                regex=r"^[0-9\-]+$",
                message="TIN should contain only numbers and dashes."
            )
        ],
        blank=True,
        default="",
    )

    deadstock_threshold_days = models.PositiveIntegerField(
        default=30,
        help_text="Number of days with no sales before a product is considered deadstock.",
    )

    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.business_name
    
class EcommerceSale(models.Model):
    PLATFORM_CHOICES = [
        ("shopee", "Shopee"),
        ("lazada", "Lazada"),
        ("tiktok", "TikTok"),
        ("other", "Other"),
    ]

    # The unique Order ID from the platform (user inputs this manually)
    order_id = models.CharField(max_length=128, unique=True)
    platform = models.CharField(max_length=32, choices=PLATFORM_CHOICES)

    # Customer info (optional)
    customer_name = models.CharField(max_length=255, blank=True)

    # Platform fees (peso amount deducted from subtotal)
    platform_fees = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal("0.00"),
        help_text="Total platform fees in pesos (commission, payment fees, etc.)",
    )

    # Date of the order
    date = models.DateField(default=timezone.now)
    created_at = models.DateTimeField(auto_now_add=True)
    due_date = models.DateField(null=True, blank=True)

    # Status flags
    is_confirmed = models.BooleanField(default=False)
    confirmed_at = models.DateTimeField(null=True, blank=True)

    is_fulfilled = models.BooleanField(default=False)
    fulfilled_at = models.DateTimeField(null=True, blank=True)

    is_cancelled = models.BooleanField(default=False)
    cancelled_at = models.DateTimeField(null=True, blank=True)

    business_profile = models.ForeignKey(
        'BusinessProfile',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='ecommerce_sales',
    )

    def __str__(self):
        return f"Ecom {self.platform.upper()} — Order {self.order_id} ({self.date})"

    # ---------- COMPUTED FIELDS ----------
    @property
    def subtotal(self):
        return sum((item.line_total for item in self.items.all()), Decimal("0.00"))

    @property
    def net_payout(self):
        result = self.subtotal - self.platform_fees
        return result.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    @property
    def status(self):
        if self.is_cancelled:
            return "Cancelled"
        if self.is_fulfilled:
            return "Fulfilled"
        if self.is_confirmed:
            return "Confirmed"
        return "Draft"

    @property
    def total_quantity_ordered(self):
        return sum(item.quantity_sold for item in self.items.all())

    @property
    def total_quantity_fulfilled(self):
        return sum(
            r.quantity
            for r in EcommerceFulfillmentRecord.objects.filter(ecom_item__sale=self)
        )

    @transaction.atomic
    def confirm(self):
        sale = EcommerceSale.objects.select_for_update().get(pk=self.pk)
        if sale.is_confirmed:
            return
        sale.is_confirmed = True
        sale.confirmed_at = timezone.now()
        sale.save(update_fields=["is_confirmed", "confirmed_at"])

    @transaction.atomic
    def cancel(self):
        sale = EcommerceSale.objects.select_for_update().get(pk=self.pk)
        if sale.is_fulfilled:
            raise ValueError("A fully fulfilled E-commerce Sale cannot be cancelled.")
        if sale.is_cancelled:
            return
        sale.is_cancelled = True
        sale.cancelled_at = timezone.now()
        sale.save(update_fields=["is_cancelled", "cancelled_at"])

    @property
    def total_paid(self):
        ct = ContentType.objects.get_for_model(self.__class__)
        return PaymentRecord.objects.filter(
            content_type=ct, object_id=self.pk
        ).aggregate(total=models.Sum("amount"))["total"] or Decimal("0.00")

    @property
    def payment_status(self):
        if not self.is_fulfilled:
            return "N/A"
        amount_due = self.net_payout  # use net_payout instead for EcommerceSale
        paid = self.total_paid
        today = timezone.localdate()
        if paid >= amount_due:
            return "Paid"
        if paid > 0:
            if self.due_date and self.due_date < today:
                return "Overdue"
            return "Partially Paid"
        if self.due_date and self.due_date < today:
            return "Overdue"
        return "Unpaid"

    @property
    def balance_due(self):
        return max(Decimal("0.00"), self.net_payout - self.total_paid)

class EcommerceSaleItem(models.Model):
    sale = models.ForeignKey(EcommerceSale, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(Product, on_delete=models.PROTECT)

    # Snapshot fields
    product_sku = models.CharField(max_length=64, blank=True)
    product_name = models.CharField(max_length=255, blank=True)

    quantity_sold = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    unit_price = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.00"))],
    )
    cost_override = models.DecimalField(
    max_digits=12,
    decimal_places=2,
    null=True,
    blank=True,
    help_text="Override the avg_cost used for COGS calculation. Leave blank to use product's avg_cost.",
    )

    def __str__(self):
        return f"Ecom#{self.sale_id} • {self.product_sku or self.product.sku} x {self.quantity_sold}"

    def save(self, *args, **kwargs):
        if not self.product_sku:
            self.product_sku = self.product.sku
        if not self.product_name:
            self.product_name = self.product.name
        super().save(*args, **kwargs)

    @property
    def line_total(self):
        return self.unit_price * self.quantity_sold

    @property
    def quantity_fulfilled(self):
        return sum(r.quantity for r in self.fulfillments.all())

    @property
    def quantity_remaining(self):
        return self.quantity_sold - self.quantity_fulfilled

    @property
    def has_stock_warning(self):
        return self.quantity_remaining > 0 and self.product.quantity < self.quantity_remaining

    @property
    def cogs(self):
        cost = self.cost_override if self.cost_override is not None else self.product.avg_cost
        return cost * self.quantity_sold

class EcommerceFulfillmentRecord(models.Model):
    ecom_item = models.ForeignKey(
        EcommerceSaleItem, on_delete=models.CASCADE, related_name="fulfillments"
    )
    quantity = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    delivered_at = models.DateTimeField(default=timezone.now)
    notes = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return f"Ecom Delivery #{self.ecom_item.sale_id} — {self.ecom_item.product_sku} x {self.quantity}"
    
class Category(models.Model):
    COLOR_CHOICES = [
        ("cat-orange", "Orange"),
        ("cat-purple", "Purple"),
        ("cat-blue", "Blue"),
        ("cat-green", "Green"),
        ("cat-red", "Red"),
        ("cat-teal", "Teal"),
        ("cat-pink", "Pink"),
        ("cat-yellow", "Yellow"),
    ]

    name = models.CharField(max_length=100)
    color = models.CharField(
        max_length=20,
        choices=COLOR_CHOICES,
        default="cat-orange",
    )
    created_at = models.DateTimeField(auto_now_add=True)

    business_profile = models.ForeignKey(
        'BusinessProfile',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='categories',
    )

    def __str__(self):
        return self.name

    class Meta:
        verbose_name_plural = "Categories"
        ordering = ["name"]
        unique_together = ("business_profile", "name")

# ─────────────────────────────────────────────
#  ACCOUNTING MODELS
# ─────────────────────────────────────────────

class ExpenseCategory(models.Model):
    name = models.CharField(max_length=100, unique=True)
    is_default = models.BooleanField(
        default=False,
        help_text="True for the pre-loaded system categories."
    )

    def __str__(self):
        return self.name

    class Meta:
        verbose_name_plural = "Expense Categories"
        ordering = ["name"]


class Expense(models.Model):
    category = models.ForeignKey(
        ExpenseCategory,
        on_delete=models.PROTECT,
        related_name="expenses",
    )
    amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))],
    )
    date = models.DateField(default=timezone.now)
    notes = models.CharField(max_length=255, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    business_profile = models.ForeignKey(
        'BusinessProfile',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='expenses',
    )

    def __str__(self):
        return f"{self.category.name} — ₱{self.amount} ({self.date})"

    class Meta:
        ordering = ["-date", "-created_at"]


class PaymentRecord(models.Model):
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey("content_type", "object_id")

    amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))],
    )
    date = models.DateField(default=timezone.now)
    notes = models.CharField(max_length=255, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Payment ₱{self.amount} on {self.date} → {self.content_type} #{self.object_id}"

    class Meta:
        ordering = ["-date", "-created_at"]

# ─────────────────────────────────────────────
#  AUTHENTICATION & MULTI-TENANCY MODELS
# ─────────────────────────────────────────────

from django.contrib.auth.models import User

MODULE_CHOICES = [
    ("inventory",    "Inventory"),
    ("sales",        "Sales Invoice"),
    ("procurement",  "Purchase Order"),
    ("ecommerce",    "E-commerce Sales"),
    ("accounting",   "Accounting"),
    ("intelligence", "Inventory Intel"),
    ("settings",     "Business Profile & Settings"),
]


class Role(models.Model):
    """
    A named role belonging to a BusinessProfile.
    e.g. "Warehouse Staff", "Sales Rep", "Accountant"
    The Owner role is auto-created and protected.
    """
    business_profile = models.ForeignKey(
        BusinessProfile,
        on_delete=models.CASCADE,
        related_name="roles",
    )
    name = models.CharField(max_length=100)
    is_owner_role = models.BooleanField(
        default=False,
        help_text="Protected. Auto-created for the first user. Cannot be deleted or edited."
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("business_profile", "name")
        ordering = ["name"]

    def __str__(self):
        return f"{self.name} @ {self.business_profile.business_name}"


class ModulePermission(models.Model):
    """
    One row per module per Role.
    Controls whether that Role can access a given module.
    Owner role always has can_access=True for all modules.
    """
    role = models.ForeignKey(
        Role,
        on_delete=models.CASCADE,
        related_name="module_permissions",
    )
    module = models.CharField(max_length=50, choices=MODULE_CHOICES)
    can_access = models.BooleanField(default=False)

    class Meta:
        unique_together = ("role", "module")
        ordering = ["module"]

    def __str__(self):
        status = "✓" if self.can_access else "✗"
        return f"{self.role.name} — {self.module} {status}"


class Membership(models.Model):
    """
    Links a Django User to a BusinessProfile with an assigned Role.
    One user belongs to one business.
    """
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name="membership",
    )
    business_profile = models.ForeignKey(
        BusinessProfile,
        on_delete=models.CASCADE,
        related_name="memberships",
    )
    role = models.ForeignKey(
        Role,
        on_delete=models.PROTECT,
        related_name="memberships",
        help_text="The role assigned to this user within the business.",
    )
    joined_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} → {self.business_profile.business_name} ({self.role.name})"

    # ── Convenience helpers ──────────────────────────────────────────

    @property
    def is_owner(self):
        return self.role.is_owner_role

    def can_access(self, module: str) -> bool:
        """
        Returns True if this membership's role has access to the given module.
        Owner always returns True regardless of ModulePermission rows.
        Usage: request.user.membership.can_access('sales')
        """
        if self.is_owner:
            return True
        return self.role.module_permissions.filter(
            module=module, can_access=True
        ).exists()
    
    @property
    def display_role_name(self):
        name = self.role.name
        if name.startswith('_'):
            return name[1:]
        return name