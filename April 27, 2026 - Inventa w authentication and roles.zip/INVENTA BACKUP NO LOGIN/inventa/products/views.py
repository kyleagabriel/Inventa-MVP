from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout          
from django.contrib.auth.decorators import login_required 
from django.views.decorators.http import require_POST
from django.contrib import messages
from django.http import JsonResponse
from decimal import Decimal, ROUND_HALF_UP
from django.db import transaction, models
from django.urls import reverse
from django.db.models import Exists, OuterRef, F, Sum, Count, ExpressionWrapper, DecimalField, Case, When, IntegerField
from datetime import date
import datetime as dt
from django.utils import timezone
import json as _json
from .analytics import build_product_demand_profile, get_fast_movers_by_velocity, get_fast_movers_by_margin, get_deadstock_items
from .forms import ProductForm, PurchaseOrderForm, PurchaseOrderItemFormSet, SalesInvoiceForm, SalesInvoiceItemFormSet, ProductPriceForm, BusinessProfileForm, EcommerceSaleForm, EcommerceSaleItemFormSet, ExpenseForm, PaymentRecordForm
from .models import Product, PurchaseOrder, PurchaseOrderItem, SalesInvoice, SalesInvoiceItem, BusinessProfile, FulfillmentRecord, SIFulfillmentRecord, EcommerceSale, EcommerceSaleItem, EcommerceFulfillmentRecord, Category, Expense, ExpenseCategory, PaymentRecord,  Role, ModulePermission, Membership
from django.contrib.contenttypes.models import ContentType
from .decorators import module_required, any_module_required, owner_required
from django.contrib.auth.models import User

# Create your views here.
def get_business_profile(request):
    return request.business_profile

@login_required
@module_required('dashboard')
def dashboard(request):
    """Dashboard homepage showing today's summary and quick actions."""
    
    today = timezone.localdate()
    
    # 📊 TODAY'S SALES
    todays_invoices = SalesInvoice.objects.filter(
        business_profile=request.business_profile,
        date=today,
        is_confirmed=True
    )
    
    total_sales_today = sum(inv.subtotal for inv in todays_invoices)
    invoice_count_today = todays_invoices.count()
    
    # 🏆 TOP SELLING PRODUCTS TODAY
    top_products = (
    SalesInvoiceItem.objects
    .filter(invoice__business_profile=request.business_profile, invoice__date=today, invoice__is_confirmed=True)
    .values('product__name', 'product__sku', 'product_id')
    .annotate(
        total_revenue=Sum(
            ExpressionWrapper(
                F('quantity_sold') * F('unit_price'),
                output_field=DecimalField()
            )
        )
    )
    .order_by('-total_revenue')[:5]
)
    
    # ⚠️ LOW STOCK ALERTS (products below reorder point)
    low_stock_products = []
    products = Product.objects.filter(
        business_profile=request.business_profile,
        is_archived=False
    )
    
    for product in products:
        profile = build_product_demand_profile(product)
        if product.quantity < profile['reorder_point']:
            low_stock_products.append({
                'product': product,
                'current_stock': product.quantity,
                'reorder_point': profile['reorder_point'],
                'recommended_order': profile['recommended_order_qty'],
            })
    
    # Sort by urgency (lowest stock first)
    low_stock_products.sort(key=lambda x: x['current_stock'])
    low_stock_products = low_stock_products[:10]  # Top 10 most urgent
    
    # 📦 PENDING PURCHASE ORDERS (confirmed, awaiting delivery from supplier)
    pending_pos = PurchaseOrder.objects.filter(
        business_profile=request.business_profile,
        is_confirmed=True,
        is_fulfilled=False,
        is_cancelled=False
    ).count()

    # 🚚 PENDING DELIVERIES TO CUSTOMERS (confirmed SIs not yet fully fulfilled)
    pending_deliveries = SalesInvoice.objects.filter(
        business_profile=request.business_profile,
        is_confirmed=True,
        is_fulfilled=False,
        is_cancelled=False
    ).count()

    # List of those invoices for the dashboard card (latest 10)
    pending_delivery_invoices = SalesInvoice.objects.filter(
        business_profile=request.business_profile,
        is_confirmed=True,
        is_fulfilled=False,
        is_cancelled=False
    ).order_by('-created_at')[:10]

    # List of confirmed POs awaiting delivery from supplier (latest 10)
    pending_pos_list = PurchaseOrder.objects.filter(
        business_profile=request.business_profile,
        is_confirmed=True,
        is_fulfilled=False,
        is_cancelled=False
    ).order_by('-created_at')[:10]
    
    context = {
    'total_sales_today': total_sales_today,
    'invoice_count_today': invoice_count_today,
    'top_products': top_products,
    'low_stock_products': low_stock_products,
    'pending_pos': pending_pos,
    'pending_deliveries': pending_deliveries,
    'pending_delivery_invoices': pending_delivery_invoices,
    'pending_pos_list': pending_pos_list,
    'today': today,
}
    
    return render(request, 'products/dashboard.html', context)

@login_required
@any_module_required('inventory', 'sales', 'procurement', 'ecommerce')
def product_search_api(request):
    """API endpoint for product autocomplete search."""
    query = request.GET.get('q', '').strip()
    
    if len(query) < 1:  # Only search if 1 characters
        return JsonResponse({'results': []})
    
    # Search by name or SKU
    products = Product.objects.filter(
        business_profile=request.business_profile,
        is_archived=False
    ).filter(
        models.Q(name__icontains=query) | models.Q(sku__icontains=query)
    )[:20] # Limit to 20 results
    
    results = []
    for product in products:
        results.append({
            'id': product.id,
            'sku': product.sku,
            'name': product.name,
            'stock': product.quantity,
            'price': float(product.selling_price) if product.selling_price else 0.00,
        })
    
    return JsonResponse({'results': results})

@login_required
@module_required('inventory')
def product_list(request):
    category_filter = request.GET.get("category", "all")
    
    products = (
        Product.objects
        .filter(business_profile=request.business_profile, is_archived=False)
        .select_related("category")
        .annotate(
            has_po_items=Exists(
                PurchaseOrderItem.objects.filter(product=OuterRef("pk"))
            ),
            has_si_items=Exists(
                SalesInvoiceItem.objects.filter(product=OuterRef("pk"))
            ),
        )
        .order_by("name")
    )

    if category_filter != "all":
        if category_filter == "uncategorized":
            products = products.filter(category__isnull=True)
        else:
            products = products.filter(category__id=category_filter)

    categories = Category.objects.filter(business_profile=request.business_profile)

    return render(
        request,
        "products/product_list.html",
        {
            "products": products,
            "categories": categories,
            "category_filter": category_filter,
        },
    )

@login_required
@module_required('inventory')
def add_product(request):
    if request.method == "POST":
        form = ProductForm(request.POST, business_profile=request.business_profile)
        if form.is_valid():
            product = form.save(commit=False)
            product.business_profile = request.business_profile
            product.save()
            return redirect("product_list")
    else:
        form = ProductForm(business_profile=request.business_profile)
    
    categories = Category.objects.filter(business_profile=request.business_profile)
    return render(request, "products/add_product.html", {
        "form": form,
        "categories": categories,
    })

@login_required
@require_POST
@module_required('inventory')
def add_product_quick(request):
    """Quick-add a product via AJAX from the PO create modal."""
    sku = request.POST.get("sku", "").strip()
    name = request.POST.get("name", "").strip()
    selling_price = request.POST.get("selling_price", "").strip()

    errors = {}
    if not sku:
        errors["sku"] = "SKU is required."
    if not name:
        errors["name"] = "Product name is required."
    if Product.objects.filter(business_profile=request.business_profile, sku=sku).exists():
        errors["sku"] = "A product with this SKU already exists."

    if errors:
        return JsonResponse({"success": False, "errors": errors})

    product = Product.objects.create(
        sku=sku,
        name=name,
        quantity=0,
        selling_price=selling_price if selling_price else None,
        business_profile=request.business_profile,
    )
    return JsonResponse({
        "success": True,
        "product": {
            "id": product.id,
            "sku": product.sku,
            "name": product.name,
            "stock": 0,
            "price": float(product.selling_price) if product.selling_price else None,
        }
    })

@login_required
@require_POST
@module_required('inventory')
def delete_product(request, pk):
    product = get_object_or_404(Product, pk=pk)

    # ❌ Block delete if product already used in any transaction
    has_po = PurchaseOrderItem.objects.filter(product=product).exists()
    has_si = SalesInvoiceItem.objects.filter(product=product).exists()

    if has_po or has_si:
        messages.error(
            request,
            "This product already has transactions and cannot be deleted. "
            "You can archive it instead."
        )
        return redirect("product_list")

    # ✅ Safe to hard-delete
    product.delete()
    messages.success(request, f"Product {product.sku} deleted.")
    return redirect("product_list")

@login_required
@module_required('procurement')
def po_create(request):
    profile = get_business_profile(request)

    if request.method == "POST":
        form = PurchaseOrderForm(request.POST)
        formset = PurchaseOrderItemFormSet(request.POST)

        if form.is_valid() and formset.is_valid():
            po = form.save(commit=False)

            # ✅ enforce profile values (so user never needs to type them)
            po.business_name = profile.business_name
            po.business_address = profile.address
            po.business_tin = profile.tin

            po.business_profile = request.business_profile
            po.is_confirmed = False
            po.confirmed_at = None
            po.save()

            formset.instance = po
            formset.save()

            messages.success(request, "PO saved as draft ✅")
            return redirect("po_detail", pk=po.pk)
    else:
        # ✅ Pre-fill on create
        form = PurchaseOrderForm(initial={
            "business_name": profile.business_name,
            "business_address": profile.address,
            "business_tin": profile.tin,
            "date": timezone.localdate(),
        })
        formset = PurchaseOrderItemFormSet()

        # ✅ Make profile fields read-only so user doesn't touch them
        for f in ["business_name", "business_address", "business_tin"]:
            if f in form.fields:
                form.fields[f].widget.attrs["readonly"] = True

    return render(request, "products/po_create.html", {
    "form": form,
    "formset": formset,
    "mode": "create",
    "products": Product.objects.filter(business_profile=request.business_profile, is_archived=False).order_by("name"),
})

@login_required
@transaction.atomic
@module_required('procurement')
def po_edit(request, pk):
    po = get_object_or_404(PurchaseOrder, pk=pk)

    if po.is_confirmed:
        messages.error(request, "This PO is already confirmed and cannot be edited.")
        return redirect("po_detail", pk=po.pk)

    if request.method == "POST":
        form = PurchaseOrderForm(request.POST, instance=po)
        formset = PurchaseOrderItemFormSet(request.POST, instance=po)

        if form.is_valid() and formset.is_valid():
            form.save()
            formset.save()
            messages.success(request, "Draft updated ✅")
            return redirect("po_detail", pk=po.pk)
    else:
        form = PurchaseOrderForm(instance=po)
        formset = PurchaseOrderItemFormSet(instance=po)

    return render(request, "products/po_create.html", {
    "form": form,
    "formset": formset,
    "mode": "edit",
    "po": po,
    "products": Product.objects.filter(business_profile=request.business_profile, is_archived=False).order_by("name"),
})

@login_required
@module_required('procurement')
def po_detail(request, pk):
    po = get_object_or_404(PurchaseOrder, pk=pk)

    from_stock_card = request.GET.get("from_stock_card")

    if from_stock_card:
        # Opened from a product's stock card
        back_url = reverse("product_stock_card", args=[from_stock_card])
        back_label = "Back to Stock Card"
    else:
        # Normal behavior
        back_url = reverse("po_list")
        back_label = "Back to Purchase Orders"

    context = {
        "po": po,
        "back_url": back_url,
        "back_label": back_label,
    }
    return render(request, "products/po_detail.html", context)

@login_required   
@module_required('procurement') 
def po_confirm(request, pk):
    """Confirm PO = mark it as sent to supplier. Stock does NOT change here."""
    if request.method != "POST":
        return redirect("po_detail", pk=pk)

    po = get_object_or_404(PurchaseOrder, pk=pk)

    if po.is_confirmed:
        messages.info(request, "This PO is already confirmed ✅")
        return redirect("po_detail", pk=po.pk)

    po.confirm_and_increase_stock()
    messages.success(request, "PO confirmed ✅ — Awaiting delivery from supplier 🚚")
    return redirect("po_detail", pk=po.pk)

@login_required
@module_required('procurement')
def po_list(request):
    """List all purchase orders with status filtering."""
    status_filter = request.GET.get("status", "all")

    pos = PurchaseOrder.objects.filter(business_profile=request.business_profile).prefetch_related("items").order_by("-created_at")

    if status_filter == "draft":
        pos = pos.filter(is_confirmed=False, is_cancelled=False)
    elif status_filter == "confirmed":
        # Awaiting Delivery = confirmed, not fulfilled, not cancelled
        # Then we filter down to only those with NO fulfillment records
        confirmed_pos = pos.filter(is_confirmed=True, is_fulfilled=False, is_cancelled=False)
        po_ids_with_fulfillments = FulfillmentRecord.objects.filter(po_item__po__business_profile=request.business_profile).values_list("po_item__po_id", flat=True).distinct()
        pos = confirmed_pos.exclude(pk__in=po_ids_with_fulfillments)
    elif status_filter == "partial":
        confirmed_pos = pos.filter(is_confirmed=True, is_fulfilled=False, is_cancelled=False)
        po_ids_with_fulfillments = FulfillmentRecord.objects.filter(po_item__po__business_profile=request.business_profile).values_list("po_item__po_id", flat=True).distinct()
        pos = confirmed_pos.filter(pk__in=po_ids_with_fulfillments)
    elif status_filter == "fulfilled":
        pos = pos.filter(is_fulfilled=True)
    elif status_filter == "cancelled":
        pos = pos.filter(is_cancelled=True)

    # For counts
    bp = request.business_profile
    all_confirmed = PurchaseOrder.objects.filter(business_profile=bp, is_confirmed=True, is_fulfilled=False, is_cancelled=False)
    po_ids_with_fulfillments = FulfillmentRecord.objects.filter(po_item__po__business_profile=bp).values_list("po_item__po_id", flat=True).distinct()

    counts = {
        "all": PurchaseOrder.objects.filter(business_profile=bp).count(),
        "draft": PurchaseOrder.objects.filter(business_profile=bp, is_confirmed=False, is_cancelled=False).count(),
        "confirmed": all_confirmed.exclude(pk__in=po_ids_with_fulfillments).count(),
        "partial": all_confirmed.filter(pk__in=po_ids_with_fulfillments).count(),
        "fulfilled": PurchaseOrder.objects.filter(business_profile=bp, is_fulfilled=True).count(),
        "cancelled": PurchaseOrder.objects.filter(business_profile=bp, is_cancelled=True).count(),
    }

    return render(request, "products/po_list.html", {
        "pos": pos,
        "status_filter": status_filter,
        "counts": counts,
    })

@login_required
@transaction.atomic
@module_required('procurement')
def po_fulfill(request, pk):
    """Record a (partial) fulfillment — this is when stock actually increases."""
    po = get_object_or_404(PurchaseOrder, pk=pk)

    if not po.is_confirmed:
        messages.error(request, "PO must be confirmed before it can be fulfilled.")
        return redirect("po_detail", pk=pk)

    if po.is_cancelled:
        messages.error(request, "This PO has been cancelled.")
        return redirect("po_detail", pk=pk)

    if po.is_fulfilled:
        messages.info(request, "This PO is already fully fulfilled.")
        return redirect("po_detail", pk=pk)

    if request.method != "POST":
        return redirect("po_detail", pk=pk)

    items = po.items.all()
    any_received = False
    errors = []

    for item in items:
        field_key = f"qty_fulfill_{item.pk}"
        raw = request.POST.get(field_key, "").strip()
        if not raw:
            continue
        try:
            qty = int(raw)
        except ValueError:
            errors.append(f"Invalid quantity for {item.product_name}.")
            continue

        if qty <= 0:
            continue

        remaining = item.quantity_remaining
        if qty > remaining:
            errors.append(
                f"Cannot receive {qty} for {item.product_name} — only {remaining} units still outstanding."
            )
            continue

        notes = request.POST.get(f"notes_{item.pk}", "").strip()
        FulfillmentRecord.objects.create(po_item=item, quantity=qty, notes=notes)

        # Update quantity AND recalculate weighted average cost atomically
        product = Product.objects.select_for_update().get(pk=item.product_id)
        old_qty = product.quantity
        old_cost = product.avg_cost
        new_cost_per_unit = item.unit_price
        new_total_qty = old_qty + qty
        if new_total_qty > 0:
            weighted_avg = ((old_qty * old_cost) + (qty * new_cost_per_unit)) / new_total_qty
        else:
            weighted_avg = new_cost_per_unit
        weighted_avg = Decimal(str(weighted_avg)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        product.quantity = new_total_qty
        product.avg_cost = weighted_avg
        product.save(update_fields=["quantity", "avg_cost"])
        any_received = True

    if errors:
        for e in errors:
            messages.error(request, e)
        if not any_received:
            return redirect("po_detail", pk=pk)

    if not any_received and not errors:
        messages.warning(request, "No quantities entered. Nothing was recorded.")
        return redirect("po_detail", pk=pk)

    # Check if PO is now fully fulfilled
    po.refresh_from_db()
    all_items = po.items.prefetch_related("fulfillments").all()
    fully_fulfilled = all(
        item.quantity_fulfilled >= item.quantity_received for item in all_items
    )
    if fully_fulfilled:
        po.is_fulfilled = True
        po.fulfilled_at = timezone.now()
        po.save(update_fields=["is_fulfilled", "fulfilled_at"])
        messages.success(request, "PO fully fulfilled ✅ Stock has been updated 📦")
    else:
        messages.success(request, "Partial fulfillment recorded ✅ Stock updated for received items 📦")

    return redirect("po_detail", pk=pk)

@login_required
@require_POST
@module_required('procurement')
def po_cancel(request, pk):
    """Cancel a PO. Cannot cancel a fully fulfilled PO."""
    po = get_object_or_404(PurchaseOrder, pk=pk)
    try:
        po.cancel()
        messages.success(request, "Purchase Order cancelled.")
    except ValueError as e:
        messages.error(request, str(e))
    return redirect("po_detail", pk=pk)

@login_required
@transaction.atomic
@module_required('sales')
def si_create(request):
    """Create a NEW Sales Invoice as DRAFT — no stock movement."""
    profile = get_business_profile(request)

    if request.method == "POST":
        form = SalesInvoiceForm(request.POST)
        formset = SalesInvoiceItemFormSet(request.POST)

        if form.is_valid() and formset.is_valid():
            invoice = form.save(commit=False)
            invoice.business_name = profile.business_name
            invoice.business_address = profile.address
            invoice.business_tin = profile.tin
            invoice.business_profile = request.business_profile
            invoice.is_confirmed = False
            invoice.save()

            formset.instance = invoice
            formset.save()

            messages.success(request, "Sales Invoice draft created ✅ Review it and confirm when ready.")
            return redirect(f"/si/{invoice.pk}/?from=create")
    else:
        form = SalesInvoiceForm(initial={
            "business_name": profile.business_name,
            "business_address": profile.address,
            "business_tin": profile.tin,
            "date": timezone.localdate(),
        })
        formset = SalesInvoiceItemFormSet()

        for f in ["business_name", "business_address", "business_tin"]:
            if f in form.fields:
                form.fields[f].widget.attrs["readonly"] = True

    products = Product.objects.filter(business_profile=request.business_profile, is_archived=False).order_by("name")
    return render(request, "products/si_create.html", {
        "form": form,
        "formset": formset,
        "products": products,
        "mode": "create",
    })

@login_required
@module_required('sales')
def si_edit(request, pk):
    si = get_object_or_404(SalesInvoice, pk=pk)

    if si.is_confirmed:
        messages.error(request, "This SI is already confirmed and cannot be edited.")
        return redirect("si_detail", pk=si.pk)

    if si.is_cancelled:
        messages.error(request, "This SI has been cancelled and cannot be edited.")
        return redirect("si_detail", pk=si.pk)

    if request.method == "POST":
        form = SalesInvoiceForm(request.POST, instance=si)
        formset = SalesInvoiceItemFormSet(request.POST, instance=si)

        if form.is_valid() and formset.is_valid():
            form.save()
            formset.save()
            messages.success(request, "Sales Invoice draft updated ✅")
            return redirect(f"/si/{si.pk}/?from=create")
    else:
        form = SalesInvoiceForm(instance=si)
        formset = SalesInvoiceItemFormSet(instance=si)

    products = Product.objects.filter(business_profile=request.business_profile, is_archived=False).order_by("name")
    return render(request, "products/si_create.html", {
        "form": form,
        "formset": formset,
        "products": products,
        "mode": "edit",
        "invoice": si,
    })

@login_required
@module_required('sales')
def si_list(request):
    """List all Sales Invoices with status filter tabs."""
    status_filter = request.GET.get("status", "all")
    bp = request.business_profile
    sis = SalesInvoice.objects.filter(business_profile=bp).order_by("-created_at")

    si_ids_with_fulfillments = SIFulfillmentRecord.objects.filter(
        si_item__invoice__business_profile=bp
    ).values_list("si_item__invoice_id", flat=True).distinct()

    if status_filter == "draft":
        sis = sis.filter(is_confirmed=False, is_cancelled=False)
    elif status_filter == "confirmed":
        confirmed = sis.filter(is_confirmed=True, is_fulfilled=False, is_cancelled=False)
        sis = confirmed.exclude(pk__in=si_ids_with_fulfillments)
    elif status_filter == "partial":
        confirmed = sis.filter(is_confirmed=True, is_fulfilled=False, is_cancelled=False)
        sis = confirmed.filter(pk__in=si_ids_with_fulfillments)
    elif status_filter == "fulfilled":
        sis = sis.filter(is_fulfilled=True)
    elif status_filter == "cancelled":
        sis = sis.filter(is_cancelled=True)

    all_confirmed = SalesInvoice.objects.filter(business_profile=bp, is_confirmed=True, is_fulfilled=False, is_cancelled=False)
    counts = {
        "all": SalesInvoice.objects.filter(business_profile=bp).count(),
        "draft": SalesInvoice.objects.filter(business_profile=bp, is_confirmed=False, is_cancelled=False).count(),
        "confirmed": all_confirmed.exclude(pk__in=si_ids_with_fulfillments).count(),
        "partial": all_confirmed.filter(pk__in=si_ids_with_fulfillments).count(),
        "fulfilled": SalesInvoice.objects.filter(business_profile=bp, is_fulfilled=True).count(),
        "cancelled": SalesInvoice.objects.filter(business_profile=bp, is_cancelled=True).count(),
    }

    return render(request, "products/si_list.html", {
        "sis": sis,
        "status_filter": status_filter,
        "counts": counts,
    })

@login_required
@module_required('sales')
def si_detail(request, pk):
    invoice = get_object_or_404(SalesInvoice, pk=pk)

    from_create = request.GET.get("from")
    from_stock_card = request.GET.get("from_stock_card")

    if from_create == "create":
        back_url = reverse("si_list")
        back_label = "← Back to Sales Invoices"
    elif from_stock_card:
        back_url = reverse("product_stock_card", args=[from_stock_card])
        back_label = "← Back to Stock Card"
    else:
        back_url = reverse("si_list")
        back_label = "← Back to Sales Invoices"

    # Build stock warning data for each item (live stock vs remaining to deliver)
    items_with_warnings = []
    for item in invoice.items.select_related("product").all():
        item.product.refresh_from_db()
        items_with_warnings.append({
            "item": item,
            "warning": item.has_stock_warning,
            "live_stock": item.product.quantity,
        })

    context = {
        "invoice": invoice,
        "back_url": back_url,
        "back_label": back_label,
        "items_with_warnings": items_with_warnings,
        "any_stock_warning": any(i["warning"] for i in items_with_warnings),
    }
    return render(request, "products/si_detail.html", context)

@login_required
@require_POST
@transaction.atomic
@module_required('sales')
def si_confirm(request, pk):
    """
    Confirm the SI. Stock is NOT deducted here.
    Allowed even with insufficient stock (lead-time use case).
    A warning is shown if stock is short.
    """
    invoice = get_object_or_404(SalesInvoice, pk=pk)

    if invoice.is_confirmed:
        messages.info(request, "This invoice is already confirmed ✅")
        return redirect("si_detail", pk=invoice.pk)

    if invoice.is_cancelled:
        messages.error(request, "This invoice has been cancelled and cannot be confirmed.")
        return redirect("si_detail", pk=invoice.pk)

    invoice.confirm()

    # Warn if any items have insufficient stock — but do not block
    stock_warnings = []
    for item in invoice.items.select_related("product").all():
        item.product.refresh_from_db()
        if item.product.quantity < item.quantity_sold:
            stock_warnings.append(
                f"⚠️ {item.product_name} ({item.product_sku}): "
                f"need {item.quantity_sold}, only {item.product.quantity} in stock — order stock immediately."
            )

    if stock_warnings:
        messages.warning(request, f"Invoice #{invoice.id} confirmed 🧾 — but some items have insufficient stock:")
        for w in stock_warnings:
            messages.warning(request, w)
    else:
        messages.success(request, f"Invoice #{invoice.id} confirmed ✅ Ready to record deliveries.")

    return redirect("si_detail", pk=invoice.pk)

@login_required
@module_required('sales')
def si_fulfill(request, pk):
    """Record a (partial) delivery of a Sales Invoice — stock deducts here."""
    invoice = get_object_or_404(SalesInvoice, pk=pk)

    if not invoice.is_confirmed:
        messages.error(request, "SI must be confirmed before deliveries can be recorded.")
        return redirect("si_detail", pk=pk)

    if invoice.is_cancelled:
        messages.error(request, "This SI has been cancelled.")
        return redirect("si_detail", pk=pk)

    if invoice.is_fulfilled:
        messages.info(request, "This SI is already fully fulfilled.")
        return redirect("si_detail", pk=pk)

    if request.method != "POST":
        return redirect("si_detail", pk=pk)

    items = invoice.items.all()
    any_delivered = False
    errors = []

    with transaction.atomic():
        for item in items:
            field_key = f"qty_fulfill_{item.pk}"
            raw = request.POST.get(field_key, "").strip()
            if not raw:
                continue
            try:
                qty = int(raw)
            except ValueError:
                errors.append(f"Invalid quantity for {item.product_name}.")
                continue

            if qty <= 0:
                continue

            remaining = item.quantity_remaining
            if qty > remaining:
                errors.append(
                    f"Cannot deliver {qty} for {item.product_name} — "
                    f"only {remaining} units still outstanding."
                )
                continue

            # Lock the product row and validate live stock
            product = Product.objects.select_for_update().get(pk=item.product_id)
            if qty > product.quantity:
                errors.append(
                    f"Not enough stock to deliver {qty} of {item.product_name} — "
                    f"only {product.quantity} available. Order more stock first."
                )
                continue

            notes = request.POST.get(f"notes_{item.pk}", "").strip()
            SIFulfillmentRecord.objects.create(si_item=item, quantity=qty, notes=notes)

            # Deduct stock at point of fulfillment
            Product.objects.filter(pk=item.product_id).update(
                quantity=F("quantity") - qty
            )
            any_delivered = True

    if errors:
        for e in errors:
            messages.error(request, e)
        if not any_delivered:
            return redirect("si_detail", pk=pk)

    if not any_delivered and not errors:
        messages.warning(request, "No quantities entered. Nothing was recorded.")
        return redirect("si_detail", pk=pk)

    # Check if SI is now fully fulfilled
    invoice.refresh_from_db()
    all_items = invoice.items.prefetch_related("fulfillments").all()
    fully_fulfilled = all(item.quantity_remaining == 0 for item in all_items)
    if fully_fulfilled:
        invoice.is_fulfilled = True
        invoice.fulfilled_at = timezone.now()
        invoice.save(update_fields=["is_fulfilled", "fulfilled_at"])
        messages.success(request, "Sales Invoice fully fulfilled ✅ All items delivered, stock updated 📦")
    else:
        messages.success(request, "Partial delivery recorded ✅ Stock updated for delivered items 📦")

    return redirect("si_detail", pk=pk)

@login_required
@require_POST
@module_required('sales')
def si_cancel(request, pk):
    """Cancel a Sales Invoice. Cannot cancel a fully fulfilled SI."""
    invoice = get_object_or_404(SalesInvoice, pk=pk)
    try:
        invoice.cancel()
        messages.success(request, "Sales Invoice cancelled.")
    except ValueError as e:
        messages.error(request, str(e))
    return redirect("si_detail", pk=pk)

@login_required
@module_required('inventory')
def product_stock_card(request, pk):
    product = get_object_or_404(Product, pk=pk)

    if request.method == "POST":
        price_form = ProductPriceForm(request.POST, instance=product)
        if price_form.is_valid():
            price_form.save()
            return redirect(request.path)
    else:
        price_form = ProductPriceForm(instance=product)

    entries = []
    total_qty_in = 0
    total_cost = Decimal("0.00")

    fulfillments = (
        FulfillmentRecord.objects
        .filter(po_item__product=product)
        .select_related("po_item", "po_item__po")
    )
    for record in fulfillments:
        item = record.po_item
        po = item.po
        tx_datetime = record.received_at

        entries.append({
            "date": tx_datetime,
            "type": "IN",
            "ref_type": "PO",
            "ref_id": po.id,
            "partner": po.supplier_name,
            "qty_in": record.quantity,
            "qty_out": 0,
        })

        total_qty_in += record.quantity
        total_cost += item.unit_price * record.quantity

    si_fulfillments = (
        SIFulfillmentRecord.objects
        .filter(si_item__product=product)
        .select_related("si_item", "si_item__invoice")
    )
    for record in si_fulfillments:
        item = record.si_item
        inv = item.invoice
        tx_datetime = record.delivered_at

        entries.append({
            "date": tx_datetime,
            "type": "OUT",
            "ref_type": "SI",
            "ref_id": inv.id,
            "partner": inv.customer_name,
            "qty_in": 0,
            "qty_out": record.quantity,
        })

    entries.sort(key=lambda e: e["date"])
    total_delta = sum(e["qty_in"] - e["qty_out"] for e in entries)
    current_qty = product.quantity
    opening_qty = current_qty - total_delta

    running = opening_qty
    for e in entries:
        delta = e["qty_in"] - e["qty_out"]
        running += delta
        e["balance"] = running

    entries.sort(key=lambda e: e["date"], reverse=True)
    average_cost = (total_cost / total_qty_in) if total_qty_in > 0 else None

    categories = Category.objects.filter(business_profile=request.business_profile)

    context = {
        "product": product,
        "entries": entries,
        "average_cost": average_cost,
        "price_form": price_form,
        "categories": categories,
    }
    return render(request, "products/stock_card.html", context)

@login_required
@require_POST
@module_required('inventory')
def archive_product(request, pk):
    product = get_object_or_404(Product, pk=pk)
    product.is_archived = True
    product.save(update_fields=["is_archived"])

    messages.success(
        request,
        f"Product {product.sku} archived. It will no longer appear in the product list."
    )
    return redirect("product_list")

@login_required
@module_required('inventory')
def archived_product_list(request):
    products = (
        Product.objects
        .filter(business_profile=request.business_profile, is_archived=True)
        .annotate(
            has_po_items=Exists(
                PurchaseOrderItem.objects.filter(product=OuterRef("pk"))
            ),
            has_si_items=Exists(
                SalesInvoiceItem.objects.filter(product=OuterRef("pk"))
            ),
        )
        .order_by("name")
    )

    return render(
        request,
        "products/archived_products.html",
        {"products": products},
    )

@login_required
@require_POST
@module_required('inventory')
def unarchive_product(request, pk):
    product = get_object_or_404(Product, pk=pk)
    product.is_archived = False
    product.save(update_fields=["is_archived"])
    messages.success(request, f"{product.sku} restored.")
    return redirect("archived_products")

# -------------- ANALYTICS -----------------------
@login_required
@module_required('intelligence')
def inventory_intel(request):
    """
    Inventory Intelligence — 4 tabs:
    0. Overview
    1. Reorder Alerts
    2. Fast Movers (velocity + margin)
    3. Deadstock (with configurable threshold saved to BusinessProfile)
    """
    profile = request.business_profile

    # ── Handle deadstock threshold save ──
    if request.method == "POST" and "deadstock_threshold_days" in request.POST:
        try:
            threshold = int(request.POST["deadstock_threshold_days"])
            if threshold < 1:
                threshold = 1
            profile.deadstock_threshold_days = threshold
            profile.save(update_fields=["deadstock_threshold_days"])
            messages.success(request, "Deadstock threshold updated.")
        except (ValueError, TypeError):
            messages.error(request, "Invalid threshold value.")
        return redirect("inventory_intel")

    products = (
        Product.objects
        .filter(business_profile=request.business_profile, is_archived=False)
        .order_by("name")
    )
    products_list = list(products)

    # ── TAB 1: Reorder Alerts ──
    reorder_rows = []
    needs_reorder_count = 0
    high_risk_count = 0

    for p in products_list:
        prof = build_product_demand_profile(p)
        risk = prof["stockout_risk_14d"]
        if risk > 0.7:
            risk_label = "high"
            high_risk_count += 1
        elif risk > 0.3:
            risk_label = "medium"
        else:
            risk_label = "low"

        if prof["recommended_order_qty"] > 0:
            needs_reorder_count += 1

        reorder_rows.append({
            "product": p,
            "days_of_stock": prof["days_of_stock"],
            "reorder_by_date": prof["reorder_by_date"],
            "recommended_order_qty": prof["recommended_order_qty"],
            "risk_label": risk_label,
            "stockout_risk_14d": risk,
        })

    # Sort: high risk first
    risk_order = {"high": 0, "medium": 1, "low": 2}
    reorder_rows.sort(key=lambda r: risk_order[r["risk_label"]])

    # ── TAB 2: Fast Movers ──
    fast_by_velocity = get_fast_movers_by_velocity(products_list, days=30)
    fast_by_margin = get_fast_movers_by_margin(products_list)

    # ── TAB 3: Deadstock ──
    threshold = profile.deadstock_threshold_days
    deadstock_rows = get_deadstock_items(
        products_list,
        threshold_days=threshold,
        fast_movers=fast_by_velocity,
    )
    total_idle_capital = sum(r["idle_capital"] for r in deadstock_rows)

    active_tab = request.GET.get("tab", "overview")

    # ── TAB 0: OVERVIEW ──
    overview_days = 90
    overview_start = dt.date.today() - dt.timedelta(days=overview_days)

    daily_revenue_qs = (
        SalesInvoiceItem.objects
        .filter(
            invoice__business_profile=request.business_profile,
            invoice__date__gte=overview_start,
            invoice__is_cancelled=False,
            invoice__is_confirmed=True,
        )
        .values("invoice__date")
        .annotate(
            revenue=Sum(
                ExpressionWrapper(
                    F("quantity_sold") * F("unit_price"),
                    output_field=DecimalField()
                )
            ),
            units=Sum("quantity_sold"),
        )
        .order_by("invoice__date")
    )

    daily_revenue_data = [
        {
            "date": str(row["invoice__date"]),
            "revenue": float(row["revenue"] or 0),
            "units": int(row["units"] or 0),
        }
        for row in daily_revenue_qs
    ]

    invoice_counts_qs = (
        SalesInvoice.objects
        .filter(
            business_profile=request.business_profile,
            date__gte=overview_start,
            is_cancelled=False,
            is_confirmed=True,
        )
        .values("date")
        .annotate(count=Count("id"))
        .order_by("date")
    )

    invoice_counts_data = {
        str(row["date"]): row["count"]
        for row in invoice_counts_qs
    }

    for d in daily_revenue_data:
        d["invoices"] = invoice_counts_data.get(d["date"], 0)

    # Per-product revenue for overview top products table
    product_revenue_qs = (
        SalesInvoiceItem.objects
        .filter(
            invoice__business_profile=request.business_profile,
            invoice__date__gte=overview_start,
            invoice__is_cancelled=False,
            invoice__is_confirmed=True,
        )
        .values("product__id", "product__name", "product__sku", "invoice__date")
        .annotate(
            revenue=Sum(
                ExpressionWrapper(
                    F("quantity_sold") * F("unit_price"),
                    output_field=DecimalField()
                )
            ),
            units=Sum("quantity_sold"),
        )
    )

    product_revenue_data = []
    for row in product_revenue_qs:
        product_revenue_data.append({
            "product_id": row["product__id"],
            "name": row["product__name"],
            "sku": row["product__sku"],
            "date": str(row["invoice__date"]),
            "revenue": float(row["revenue"] or 0),
            "units": int(row["units"] or 0),
        })

    context = {
        "active_tab": active_tab,
        "overview_data_json": _json.dumps(daily_revenue_data),
        "overview_product_json": _json.dumps(product_revenue_data),
        # Tab 1
        "reorder_rows": reorder_rows,
        "needs_reorder_count": needs_reorder_count,
        "high_risk_count": high_risk_count,
        "total_skus": len(products_list),
        # Tab 2
        "fast_by_velocity": fast_by_velocity,
        "fast_by_margin": fast_by_margin,
        # Tab 3
        "deadstock_rows": deadstock_rows,
        "total_idle_capital": total_idle_capital,
        "deadstock_threshold": threshold,
    }
    return render(request, "products/inventory_intel.html", context)

@login_required
@module_required('settings')
def business_profile(request):
    # MVP: single global profile (always edit row #1)
    profile = request.business_profile

    if request.method == "POST":
        form = BusinessProfileForm(request.POST, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, "Business profile saved ✅")
            return redirect("business_profile")
    else:
        form = BusinessProfileForm(instance=profile)

    return render(request, "products/business_profile.html", {
        "form": form,
        "profile": profile,
    })

# ─────────────────────────────────────────────
#  E-COMMERCE SALES
# ─────────────────────────────────────────────
@login_required
@module_required('ecommerce')
def ecom_list(request):
    """List all E-commerce Sales with status filter tabs."""
    status_filter = request.GET.get("status", "all")
    bp = request.business_profile
    sales = EcommerceSale.objects.filter(business_profile=bp).order_by("-created_at")

    ecom_ids_with_fulfillments = EcommerceFulfillmentRecord.objects.filter(
        ecom_item__sale__business_profile=bp
    ).values_list("ecom_item__sale_id", flat=True).distinct()

    if status_filter == "draft":
        sales = sales.filter(is_confirmed=False, is_cancelled=False)
    elif status_filter == "confirmed":
        confirmed = sales.filter(is_confirmed=True, is_fulfilled=False, is_cancelled=False)
        sales = confirmed.exclude(pk__in=ecom_ids_with_fulfillments)
    elif status_filter == "fulfilled":
        sales = sales.filter(is_fulfilled=True)
    elif status_filter == "cancelled":
        sales = sales.filter(is_cancelled=True)

    all_confirmed = EcommerceSale.objects.filter(
        business_profile=bp, is_confirmed=True, is_fulfilled=False, is_cancelled=False
    )
    counts = {
        "all": EcommerceSale.objects.filter(business_profile=bp).count(),
        "draft": EcommerceSale.objects.filter(business_profile=bp, is_confirmed=False, is_cancelled=False).count(),
        "confirmed": all_confirmed.exclude(pk__in=ecom_ids_with_fulfillments).count(),
        "fulfilled": EcommerceSale.objects.filter(business_profile=bp, is_fulfilled=True).count(),
        "cancelled": EcommerceSale.objects.filter(business_profile=bp, is_cancelled=True).count(),
    }

    return render(request, "products/ecom_list.html", {
        "sales": sales,
        "status_filter": status_filter,
        "counts": counts,
    })

@login_required
@module_required('ecommerce')
def ecom_create(request):
    """Create a new E-commerce Sale as a draft."""
    if request.method == "POST":
        form = EcommerceSaleForm(request.POST)
        formset = EcommerceSaleItemFormSet(request.POST)

        if form.is_valid() and formset.is_valid():
            sale = form.save(commit=False)
            sale.business_profile = request.business_profile
            sale.is_confirmed = False
            sale.save()

            formset.instance = sale
            formset.save()

            messages.success(request, "E-commerce Sale draft created ✅ Review it and confirm when ready.")
            return redirect("ecom_detail", pk=sale.pk)
    else:
        form = EcommerceSaleForm()
        formset = EcommerceSaleItemFormSet()

    return render(request, "products/ecom_create.html", {
        "form": form,
        "formset": formset,
        "mode": "create",
        "products": Product.objects.filter(business_profile=request.business_profile, is_archived=False).order_by("name"),
    })

@login_required
@module_required('ecommerce')
def ecom_edit(request, pk):
    """Edit a draft E-commerce Sale."""
    sale = get_object_or_404(EcommerceSale, pk=pk)

    if sale.is_confirmed:
        messages.error(request, "This E-commerce Sale is already confirmed and cannot be edited.")
        return redirect("ecom_detail", pk=sale.pk)

    if sale.is_cancelled:
        messages.error(request, "This E-commerce Sale has been cancelled and cannot be edited.")
        return redirect("ecom_detail", pk=sale.pk)

    if request.method == "POST":
        form = EcommerceSaleForm(request.POST, instance=sale)
        formset = EcommerceSaleItemFormSet(request.POST, instance=sale)

        if form.is_valid() and formset.is_valid():
            form.save()
            formset.save()
            messages.success(request, "E-commerce Sale draft updated ✅")
            return redirect("ecom_detail", pk=sale.pk)
    else:
        form = EcommerceSaleForm(instance=sale)
        formset = EcommerceSaleItemFormSet(instance=sale)

    return render(request, "products/ecom_create.html", {
        "form": form,
        "formset": formset,
        "mode": "edit",
        "sale": sale,
        "products": Product.objects.filter(business_profile=request.business_profile, is_archived=False).order_by("name"),
    })

@login_required
@module_required('ecommerce')
def ecom_detail(request, pk):
    """Detail view for a single E-commerce Sale."""
    sale = get_object_or_404(EcommerceSale, pk=pk)

    items_with_warnings = []
    for item in sale.items.select_related("product").all():
        item.product.refresh_from_db()
        items_with_warnings.append({
            "item": item,
            "warning": item.has_stock_warning,
            "live_stock": item.product.quantity,
        })

    context = {
        "sale": sale,
        "items_with_warnings": items_with_warnings,
        "any_stock_warning": any(i["warning"] for i in items_with_warnings),
    }
    return render(request, "products/ecom_detail.html", context)

@login_required
@require_POST
@transaction.atomic
@module_required('ecommerce')
def ecom_confirm(request, pk):
    """Confirm the E-commerce Sale. Stock is NOT deducted here."""
    sale = get_object_or_404(EcommerceSale, pk=pk)

    if sale.is_confirmed:
        messages.info(request, "This sale is already confirmed ✅")
        return redirect("ecom_detail", pk=sale.pk)

    if sale.is_cancelled:
        messages.error(request, "This sale has been cancelled and cannot be confirmed.")
        return redirect("ecom_detail", pk=sale.pk)

    sale.confirm()

    # Warn if any items have insufficient stock — but do not block
    stock_warnings = []
    for item in sale.items.select_related("product").all():
        item.product.refresh_from_db()
        if item.product.quantity < item.quantity_sold:
            stock_warnings.append(
                f"⚠️ {item.product_name} ({item.product_sku}): "
                f"need {item.quantity_sold}, only {item.product.quantity} in stock."
            )

    if stock_warnings:
        messages.warning(request, f"Order {sale.order_id} confirmed 🧾 — but some items have insufficient stock:")
        for w in stock_warnings:
            messages.warning(request, w)
    else:
        messages.success(request, f"Order {sale.order_id} confirmed ✅ Ready to record fulfillment.")

    return redirect("ecom_detail", pk=sale.pk)

@login_required
@transaction.atomic
@module_required('ecommerce')
def ecom_fulfill(request, pk):
    """Fulfill an E-commerce Sale in full — stock deducts here."""
    sale = get_object_or_404(EcommerceSale, pk=pk)

    if not sale.is_confirmed:
        messages.error(request, "Sale must be confirmed before fulfillment can be recorded.")
        return redirect("ecom_detail", pk=pk)

    if sale.is_cancelled:
        messages.error(request, "This sale has been cancelled.")
        return redirect("ecom_detail", pk=pk)

    if sale.is_fulfilled:
        messages.info(request, "This sale is already fully fulfilled.")
        return redirect("ecom_detail", pk=pk)

    if request.method != "POST":
        return redirect("ecom_detail", pk=pk)

    items = list(sale.items.all())
    errors = []

    # Validate all items first before touching stock
    for item in items:
        product = Product.objects.select_for_update().get(pk=item.product_id)
        if item.quantity_sold > product.quantity:
            errors.append(
                f"Not enough stock for {item.product_name} — "
                f"need {item.quantity_sold}, only {product.quantity} available."
            )

    if errors:
        for e in errors:
            messages.error(request, e)
        return redirect("ecom_detail", pk=pk)

    # All clear — deduct stock and record fulfillment
    for item in items:
        notes = request.POST.get(f"notes_{item.pk}", "").strip()
        EcommerceFulfillmentRecord.objects.create(
            ecom_item=item,
            quantity=item.quantity_sold,
            notes=notes,
        )
        Product.objects.filter(pk=item.product_id).update(
            quantity=F("quantity") - item.quantity_sold
        )

    sale.is_fulfilled = True
    sale.fulfilled_at = timezone.now()
    sale.save(update_fields=["is_fulfilled", "fulfilled_at"])
    messages.success(request, "E-commerce order fulfilled ✅ Stock updated 📦")

    return redirect("ecom_detail", pk=pk)

@login_required
@require_POST
@module_required('ecommerce')
def ecom_cancel(request, pk):
    """Cancel an E-commerce Sale. Cannot cancel a fully fulfilled sale."""
    sale = get_object_or_404(EcommerceSale, pk=pk)
    try:
        sale.cancel()
        messages.success(request, "E-commerce Sale cancelled.")
    except ValueError as e:
        messages.error(request, str(e))
    return redirect("ecom_detail", pk=pk)

# ─────────────────────────────────────────────
#  CATEGORY API
# ─────────────────────────────────────────────
@login_required
@module_required('inventory')
def category_search_api(request):
    """Return all categories, optionally filtered by search query."""
    query = request.GET.get("q", "").strip()
    categories = Category.objects.filter(business_profile=request.business_profile)
    if query:
        categories = categories.filter(name__icontains=query)

    results = [
        {"id": c.id, "name": c.name, "color": c.color}
        for c in categories
    ]
    return JsonResponse({"results": results})

@login_required
@require_POST
@module_required('inventory')
def category_create_api(request):
    """Create a new category on the fly and return it."""
    name = request.POST.get("name", "").strip()

    if not name:
        return JsonResponse({"success": False, "error": "Name is required."})

    if Category.objects.filter(business_profile=request.business_profile, name__iexact=name).exists():
        cat = Category.objects.get(business_profile=request.business_profile, name__iexact=name)
        return JsonResponse({"success": True, "category": {
            "id": cat.id, "name": cat.name, "color": cat.color
        }})

    # Assign the next available color in order
    COLOR_SEQUENCE = [
        "cat-orange", "cat-purple", "cat-blue", "cat-green",
        "cat-red", "cat-teal", "cat-pink", "cat-yellow",
    ]
    used_colors = set(Category.objects.filter(business_profile=request.business_profile).values_list("color", flat=True))
    assigned_color = "cat-orange"  # fallback
    for color in COLOR_SEQUENCE:
        if color not in used_colors:
            assigned_color = color
            break

    cat = Category.objects.create(name=name, color=assigned_color, business_profile=request.business_profile)
    return JsonResponse({"success": True, "category": {
        "id": cat.id, "name": cat.name, "color": cat.color
    }})

@login_required
@require_POST
@module_required('inventory')
def category_assign_api(request, product_pk):
    """Assign or clear a category on a product."""
    product = get_object_or_404(Product, pk=product_pk)
    category_id = request.POST.get("category_id", "").strip()

    if not category_id or category_id == "none":
        product.category = None
    else:
        category = get_object_or_404(Category, pk=category_id)
        product.category = category

    product.save(update_fields=["category"])
    return JsonResponse({"success": True})

@login_required
@require_POST
@module_required('inventory')
def category_rename_api(request, pk):
    """Rename an existing category."""
    category = get_object_or_404(Category, pk=pk)
    new_name = request.POST.get("name", "").strip()

    if not new_name:
        return JsonResponse({"success": False, "error": "Name is required."})

    if Category.objects.filter(business_profile=request.business_profile, name__iexact=new_name).exclude(pk=pk).exists():
        return JsonResponse({"success": False, "error": "A category with this name already exists."})

    category.name = new_name
    category.save(update_fields=["name"])
    return JsonResponse({"success": True, "category": {
        "id": category.id, "name": category.name, "color": category.color
    }})

@login_required
@require_POST
@module_required('inventory')
def category_delete_api(request, pk):
    """Delete a category. Affected products become uncategorized."""
    category = get_object_or_404(Category, pk=pk)
    affected_count = category.products.count()
    category.delete()
    return JsonResponse({"success": True, "affected_count": affected_count})

@login_required
@module_required('inventory')
def category_list_api(request):
    """Return all categories with their product counts."""
    categories = Category.objects.filter(
        business_profile=request.business_profile
    ).annotate(
        product_count=models.Count("products")
    ).order_by("name")

    results = [
        {
            "id": c.id,
            "name": c.name,
            "color": c.color,
            "product_count": c.product_count,
        }
        for c in categories
    ]
    return JsonResponse({"results": results})

# ─────────────────────────────────────────────
#  ACCOUNTING VIEWS
# ─────────────────────────────────────────────
@login_required
@module_required('accounting')
def accounting_pl(request):
    """Profit & Loss report page."""
    today = timezone.localdate()

    # ── Period filter ──
    period = request.GET.get("period", "this_month")
    custom_start = request.GET.get("start", "")
    custom_end = request.GET.get("end", "")

    if period == "last_30":
        start_date = today - dt.timedelta(days=30)
        end_date = today
    elif period == "custom" and custom_start and custom_end:
        try:
            start_date = dt.date.fromisoformat(custom_start)
            end_date = dt.date.fromisoformat(custom_end)
        except ValueError:
            start_date = today.replace(day=1)
            end_date = today
    else:
        # Default: this month
        period = "this_month"
        start_date = today.replace(day=1)
        end_date = today

    # ── In-store Revenue & COGS (fulfilled SIs in period) ──
    bp = request.business_profile
    fulfilled_sis = SalesInvoice.objects.filter(
        business_profile=bp,
        is_fulfilled=True,
        fulfilled_at__date__gte=start_date,
        fulfilled_at__date__lte=end_date,
    )

    instore_revenue = Decimal("0.00")
    instore_cogs = Decimal("0.00")
    for si in fulfilled_sis:
        for item in si.items.select_related("product").all():
            instore_revenue += item.line_total
            instore_cogs += item.cogs

    # ── E-commerce Revenue & COGS (fulfilled Ecom orders in period) ──
    fulfilled_ecom = EcommerceSale.objects.filter(
        business_profile=bp,
        is_fulfilled=True,
        fulfilled_at__date__gte=start_date,
        fulfilled_at__date__lte=end_date,
    )

    ecom_revenue = Decimal("0.00")
    ecom_cogs = Decimal("0.00")
    for sale in fulfilled_ecom:
        ecom_revenue += sale.net_payout
        for item in sale.items.select_related("product").all():
            ecom_cogs += item.cogs

    # ── Totals ──
    total_revenue = instore_revenue + ecom_revenue
    total_cogs = instore_cogs + ecom_cogs
    gross_profit = total_revenue - total_cogs
    gross_margin_pct = (
        (gross_profit / total_revenue * 100).quantize(Decimal("0.1"))
        if total_revenue > 0 else Decimal("0.0")
    )

    # ── Operating Expenses (manual entries in period) ──
    expenses_qs = Expense.objects.filter(
        business_profile=bp,
        date__gte=start_date,
        date__lte=end_date,
    ).select_related("category")

    total_opex = expenses_qs.aggregate(
        total=models.Sum("amount")
    )["total"] or Decimal("0.00")

    # Expenses broken down by category
    expense_by_category = {}
    for exp in expenses_qs:
        cat_name = exp.category.name
        expense_by_category[cat_name] = expense_by_category.get(cat_name, Decimal("0.00")) + exp.amount

    expense_breakdown = sorted(
        [{"category": k, "amount": v} for k, v in expense_by_category.items()],
        key=lambda x: x["amount"],
        reverse=True,
    )

    # ── Net Profit ──
    net_profit = gross_profit - total_opex

    # ── Chart data — monthly revenue vs expenses ──
    # Build a range of months between start_date and end_date
    chart_labels = []
    chart_revenue = []
    chart_expenses = []

    cursor = start_date.replace(day=1)
    while cursor <= end_date:
        month_start = cursor
        # Last day of this month
        if cursor.month == 12:
            month_end = cursor.replace(day=31)
        else:
            month_end = (cursor.replace(month=cursor.month + 1, day=1)) - dt.timedelta(days=1)

        # Clamp to the selected period
        month_end = min(month_end, end_date)

        # Revenue for this month
        m_sis = SalesInvoice.objects.filter(
            business_profile=bp,
            is_fulfilled=True,
            fulfilled_at__date__gte=month_start,
            fulfilled_at__date__lte=month_end,
        )
        m_ecom = EcommerceSale.objects.filter(
            business_profile=bp,
            is_fulfilled=True,
            fulfilled_at__date__gte=month_start,
            fulfilled_at__date__lte=month_end,
        )
        m_revenue = Decimal("0.00")
        for si in m_sis:
            m_revenue += si.subtotal
        for sale in m_ecom:
            m_revenue += sale.net_payout

        # Expenses for this month
        m_expenses = Expense.objects.filter(
            business_profile=bp,
            date__gte=month_start,
            date__lte=month_end,
        ).aggregate(total=models.Sum("amount"))["total"] or Decimal("0.00")

        chart_labels.append(cursor.strftime("%b %Y"))
        chart_revenue.append(float(m_revenue))
        chart_expenses.append(float(m_expenses))

        # Advance to next month
        if cursor.month == 12:
            cursor = cursor.replace(year=cursor.year + 1, month=1, day=1)
        else:
            cursor = cursor.replace(month=cursor.month + 1, day=1)

    context = {
        "period": period,
        "start_date": start_date,
        "end_date": end_date,
        "custom_start": custom_start,
        "custom_end": custom_end,
        # Revenue
        "instore_revenue": instore_revenue,
        "ecom_revenue": ecom_revenue,
        "total_revenue": total_revenue,
        # COGS
        "instore_cogs": instore_cogs,
        "ecom_cogs": ecom_cogs,
        "total_cogs": total_cogs,
        # Profit
        "gross_profit": gross_profit,
        "gross_margin_pct": gross_margin_pct,
        # Expenses
        "total_opex": total_opex,
        "expense_breakdown": expense_breakdown,
        # Net
        "net_profit": net_profit,
        # Chart
        "chart_labels": _json.dumps(chart_labels),
        "chart_revenue": _json.dumps(chart_revenue),
        "chart_expenses": _json.dumps(chart_expenses),
    }
    return render(request, "products/accounting_pl.html", context)

@login_required
@module_required('accounting')
def accounting_obligations(request):
    """Payables & Receivables page with pill toggle."""
    view = request.GET.get("view", "receivables")

    # ── Status filter ──
    status_filter = request.GET.get("status", "all")

    STATUS_OPTIONS = ["all", "unpaid", "partially_paid", "paid", "overdue"]
    if status_filter not in STATUS_OPTIONS:
        status_filter = "all"

    def apply_status_filter(items):
        if status_filter == "all":
            return items
        label_map = {
            "unpaid": "Unpaid",
            "partially_paid": "Partially Paid",
            "paid": "Paid",
            "overdue": "Overdue",
        }
        target = label_map[status_filter]
        return [i for i in items if i["payment_status"] == target]

    receivables = []
    payables = []

    bp = request.business_profile
    if view == "receivables":
        # Fulfilled SIs
        for si in SalesInvoice.objects.filter(business_profile=bp, is_fulfilled=True).order_by("-fulfilled_at"):
            receivables.append({
                "model": "si",
                "pk": si.pk,
                "date": si.fulfilled_at.date() if si.fulfilled_at else si.date,
                "ref": si.si_number,
                "party": si.customer_name,
                "source": "In-store",
                "amount_due": si.total_with_tax,
                "total_paid": si.total_paid,
                "balance_due": si.balance_due,
                "payment_status": si.payment_status,
                "due_date": si.due_date,
            })

        # Fulfilled Ecom orders
        for sale in EcommerceSale.objects.filter(business_profile=bp, is_fulfilled=True).order_by("-fulfilled_at"):
            receivables.append({
                "model": "ecom",
                "pk": sale.pk,
                "date": sale.fulfilled_at.date() if sale.fulfilled_at else sale.date,
                "ref": sale.order_id,
                "party": sale.customer_name or "—",
                "source": sale.get_platform_display(),
                "amount_due": sale.net_payout,
                "total_paid": sale.total_paid,
                "balance_due": sale.balance_due,
                "payment_status": sale.payment_status,
                "due_date": sale.due_date,
            })

        receivables.sort(key=lambda x: x["date"], reverse=True)
        receivables = apply_status_filter(receivables)

    else:
        # Fulfilled POs
        for po in PurchaseOrder.objects.filter(business_profile=bp, is_fulfilled=True).order_by("-fulfilled_at"):
            payables.append({
                "model": "po",
                "pk": po.pk,
                "date": po.fulfilled_at.date() if po.fulfilled_at else po.date,
                "ref": po.po_number,
                "party": po.supplier_name,
                "amount_due": po.total_with_tax,
                "total_paid": po.total_paid,
                "balance_due": po.balance_due,
                "payment_status": po.payment_status,
                "due_date": po.due_date,
            })

        payables = apply_status_filter(payables)

    context = {
        "view": view,
        "status_filter": status_filter,
        "receivables": receivables,
        "payables": payables,
    }
    return render(request, "products/accounting_obligations.html", context)

@login_required
@require_POST
@module_required('accounting')
def accounting_log_payment(request, model, pk):
    """Log a payment installment against an SI, Ecom order, or PO."""
    MODEL_MAP = {
        "si": SalesInvoice,
        "ecom": EcommerceSale,
        "po": PurchaseOrder,
    }
    if model not in MODEL_MAP:
        messages.error(request, "Invalid payment target.")
        return redirect("accounting_obligations")

    obj = get_object_or_404(MODEL_MAP[model], pk=pk)
    form = PaymentRecordForm(request.POST)

    if form.is_valid():
        payment = form.save(commit=False)
        payment.content_type = ContentType.objects.get_for_model(obj)
        payment.object_id = obj.pk
        payment.save()
        messages.success(request, f"Payment of ₱{payment.amount} logged successfully ✅")
    else:
        for field, errors in form.errors.items():
            for error in errors:
                messages.error(request, f"{error}")

    # Determine which view to return to
    view = "payables" if model == "po" else "receivables"
    return redirect(f"{reverse('accounting_obligations')}?view={view}")

@login_required
@require_POST
@module_required('accounting')
def accounting_delete_payment(request, model, pk, payment_pk):
    """Delete a specific payment record."""
    payment = get_object_or_404(PaymentRecord, pk=payment_pk)
    payment.delete()
    messages.success(request, "Payment record deleted.")
    view = "payables" if model == "po" else "receivables"
    return redirect(f"{reverse('accounting_obligations')}?view={view}")

@login_required
@module_required('accounting')
def accounting_expenses(request):
    """Expense log page with inline create and edit/delete."""
    from django.db.models import Case, When, IntegerField
    form = ExpenseForm(request.POST or None)

    if request.method == "POST":
        if form.is_valid():
            expense = form.save(commit=False)
            expense.business_profile = request.business_profile
            expense.save()
            messages.success(request, "Expense logged ✅")
            return redirect("accounting_expenses")

    # Filters — read from URL
    category_filter = request.GET.get("category", "all")
    start_filter = request.GET.get("start", "")
    end_filter = request.GET.get("end", "")

    expenses = Expense.objects.filter(business_profile=request.business_profile).select_related("category").order_by("-date", "-created_at")

    if category_filter != "all":
        try:
            expenses = expenses.filter(category__id=int(category_filter))
        except (ValueError, TypeError):
            category_filter = "all"

    if start_filter:
        try:
            expenses = expenses.filter(date__gte=dt.date.fromisoformat(start_filter))
        except ValueError:
            pass

    if end_filter:
        try:
            expenses = expenses.filter(date__lte=dt.date.fromisoformat(end_filter))
        except ValueError:
            pass

    total_filtered = expenses.aggregate(
        total=models.Sum("amount")
    )["total"] or Decimal("0.00")

    # Categories for dropdown — Other always last
    categories = ExpenseCategory.objects.all().annotate(
        sort_order=Case(
            When(name="Other", then=1),
            default=0,
            output_field=IntegerField(),
        )
    ).order_by("sort_order", "name")

    context = {
        "form": form,
        "expenses": expenses,
        "categories": categories,
        "category_filter": category_filter,
        "start_filter": start_filter,
        "end_filter": end_filter,
        "total_filtered": total_filtered,
    }
    return render(request, "products/accounting_expenses.html", context)

@login_required
@module_required('accounting')
def accounting_expense_edit(request, pk):
    """Edit an existing expense entry."""
    expense = get_object_or_404(Expense, pk=pk)

    if request.method == "POST":
        form = ExpenseForm(request.POST, instance=expense)
        if form.is_valid():
            form.save()
            messages.success(request, "Expense updated ✅")
            return redirect("accounting_expenses")
    else:
        form = ExpenseForm(instance=expense)

    # Pass full expense list context so the page renders correctly behind the modal
    from django.db.models import Case, When, IntegerField
    expenses = Expense.objects.filter(business_profile=request.business_profile).select_related("category").order_by("-date", "-created_at")
    total_filtered = expenses.aggregate(
        total=models.Sum("amount")
    )["total"] or Decimal("0.00")
    categories = ExpenseCategory.objects.all().annotate(
        sort_order=Case(
            When(name="Other", then=1),
            default=0,
            output_field=IntegerField(),
        )
    ).order_by("sort_order", "name")

    context = {
        "form": form,
        "expense": expense,
        "editing": True,
        "expenses": expenses,
        "categories": categories,
        "category_filter": "all",
        "start_filter": "",
        "end_filter": "",
        "total_filtered": total_filtered,
    }
    return render(request, "products/accounting_expenses.html", context)

@login_required
@require_POST
@module_required('accounting')
def accounting_expense_delete(request, pk):
    """Delete an expense entry."""
    expense = get_object_or_404(Expense, pk=pk)
    expense.delete()
    messages.success(request, "Expense deleted.")
    return redirect("accounting_expenses")

@login_required
@module_required('accounting')
def accounting_payment_history(request, model, pk):
    """Return payment history for a given SI, Ecom, or PO as JSON."""
    MODEL_MAP = {
        "si": SalesInvoice,
        "ecom": EcommerceSale,
        "po": PurchaseOrder,
    }
    if model not in MODEL_MAP:
        return JsonResponse({"error": "Invalid model."}, status=400)

    obj = get_object_or_404(MODEL_MAP[model], pk=pk)
    ct = ContentType.objects.get_for_model(obj)
    payments = PaymentRecord.objects.filter(
        content_type=ct, object_id=pk
    ).order_by("-date", "-created_at")

    data = {
        "payments": [
            {
                "pk": p.pk,
                "date": p.date.strftime("%b %d, %Y"),
                "amount": float(p.amount),
                "notes": p.notes or "—",
            }
            for p in payments
        ],
        "total_paid": float(obj.total_paid),
        "balance_due": float(obj.balance_due),
        "amount_due": float(obj.total_with_tax if model != "ecom" else obj.net_payout),
    }
    return JsonResponse(data)

# ─────────────────────────────────────────────
#  SETTINGS & TEAM MANAGEMENT VIEWS
# ─────────────────────────────────────────────

MODULE_CHOICES_LIST = [
    ("dashboard",    "Dashboard"),
    ("inventory",    "Inventory"),
    ("sales",        "Sales Invoice"),
    ("procurement",  "Purchase Order"),
    ("ecommerce",    "E-commerce Sales"),
    ("accounting",   "Accounting"),
    ("intelligence", "Inventory Intel"),
    ("settings",     "Business Profile & Settings"),
]


@login_required
@module_required('settings')
def settings_view(request):
    """
    Main settings page with tabs:
    - Tab 1: Business Profile
    - Tab 2: Team Members (Owner only)
    """
    profile = request.business_profile
    membership = request.membership
    active_tab = request.GET.get('tab', 'profile')

    # Only Owner can access team tab
    if active_tab == 'team' and membership and not membership.is_owner:
        active_tab = 'profile'

    # Business Profile form
    if request.method == 'POST' and 'save_profile' in request.POST:
        form = BusinessProfileForm(request.POST, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, "Business profile saved ✅")
            return redirect(f"{reverse('settings')}?tab=profile")
    else:
        form = BusinessProfileForm(instance=profile)

    # Team members list
    memberships = []
    if membership and membership.is_owner:
        memberships = (
            Membership.objects
            .filter(business_profile=profile)
            .select_related('user', 'role')
            .prefetch_related('role__module_permissions')
            .order_by('joined_at')
        )

    context = {
        'form': form,
        'profile': profile,
        'active_tab': active_tab,
        'memberships': memberships,
        'is_owner': membership.is_owner if membership else False,
        'module_choices': MODULE_CHOICES_LIST,
    }
    return render(request, 'products/settings.html', context)


@login_required
@module_required('settings')
@owner_required
def team_member_create(request):
    """Create a new team member with module-level permissions."""
    if request.method != 'POST':
        return redirect(f"{reverse('settings')}?tab=team")

    profile = request.business_profile
    username = request.POST.get('username', '').strip()
    password = request.POST.get('password', '').strip()
    modules = request.POST.getlist('modules')

    errors = []

    if not username:
        errors.append("Username is required.")
    if not password:
        errors.append("Password is required.")
    if len(password) < 8:
        errors.append("Password must be at least 8 characters.")
    if User.objects.filter(username=username).exists():
        errors.append(f"Username '{username}' is already taken.")

    if errors:
        for e in errors:
            messages.error(request, e)
        return redirect(f"{reverse('settings')}?tab=team")

    # Create user
    user = User.objects.create_user(username=username, password=password)

    # Create a personal role for this user
    role = Role.objects.create(
        business_profile=profile,
        name=f"_{username}",  # underscore prefix = auto-generated personal role
        is_owner_role=False,
    )

    # Set module permissions
    for module_key, _ in MODULE_CHOICES_LIST:
        ModulePermission.objects.create(
            role=role,
            module=module_key,
            can_access=(module_key in modules),
        )

    # Create membership
    Membership.objects.create(
        user=user,
        business_profile=profile,
        role=role,
    )

    messages.success(request, f"Team member '{username}' created successfully ✅")
    return redirect(f"{reverse('settings')}?tab=team")


@login_required
@module_required('settings')
@owner_required
def team_member_edit(request, pk):
    """Edit a team member's module permissions."""
    if request.method != 'POST':
        return redirect(f"{reverse('settings')}?tab=team")

    membership = get_object_or_404(
        Membership,
        pk=pk,
        business_profile=request.business_profile
    )

    # Cannot edit the Owner's own membership
    if membership.is_owner:
        messages.error(request, "The Owner's permissions cannot be modified.")
        return redirect(f"{reverse('settings')}?tab=team")

    modules = request.POST.getlist('modules')

    # Update module permissions
    for module_key, _ in MODULE_CHOICES_LIST:
        ModulePermission.objects.update_or_create(
            role=membership.role,
            module=module_key,
            defaults={'can_access': (module_key in modules)},
        )

    messages.success(
        request,
        f"Permissions updated for '{membership.user.username}' ✅"
    )
    return redirect(f"{reverse('settings')}?tab=team")


@login_required
@module_required('settings')
@owner_required
def team_member_toggle_active(request, pk):
    """Activate or deactivate a team member's login access."""
    if request.method != 'POST':
        return redirect(f"{reverse('settings')}?tab=team")

    membership = get_object_or_404(
        Membership,
        pk=pk,
        business_profile=request.business_profile
    )

    if membership.is_owner:
        messages.error(request, "The Owner account cannot be deactivated.")
        return redirect(f"{reverse('settings')}?tab=team")

    user = membership.user
    user.is_active = not user.is_active
    user.save(update_fields=['is_active'])

    status = "activated" if user.is_active else "deactivated"
    messages.success(request, f"'{user.username}' has been {status} ✅")
    return redirect(f"{reverse('settings')}?tab=team")


@login_required
@module_required('settings')
@owner_required
def team_member_reset_password(request, pk):
    """Reset a team member's password."""
    if request.method != 'POST':
        return redirect(f"{reverse('settings')}?tab=team")

    membership = get_object_or_404(
        Membership,
        pk=pk,
        business_profile=request.business_profile
    )

    if membership.is_owner:
        messages.error(request, "Use the Django admin to change the Owner's password.")
        return redirect(f"{reverse('settings')}?tab=team")

    new_password = request.POST.get('new_password', '').strip()

    if not new_password:
        messages.error(request, "Password cannot be empty.")
        return redirect(f"{reverse('settings')}?tab=team")

    if len(new_password) < 8:
        messages.error(request, "Password must be at least 8 characters.")
        return redirect(f"{reverse('settings')}?tab=team")

    membership.user.set_password(new_password)
    membership.user.save()

    messages.success(
        request,
        f"Password for '{membership.user.username}' has been reset ✅"
    )
    return redirect(f"{reverse('settings')}?tab=team")


# ─────────────────────────────────────────────
#  AUTHENTICATION VIEWS
# ─────────────────────────────────────────────

def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '')
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            next_url = request.GET.get('next')
            if next_url:
                return redirect(next_url)

            # Smart redirect — send user to first accessible module
            try:
                membership = Membership.objects.select_related('role').get(user=user)
                from .decorators import get_first_accessible_url
                fallback = get_first_accessible_url(membership)
                return redirect(fallback)
            except Membership.DoesNotExist:
                # Superuser with no membership — go to dashboard
                return redirect('dashboard')
        else:
            messages.error(request, 'Invalid username or password.')

    return render(request, 'products/login.html')

def logout_view(request):
    logout(request)
    return redirect('login')

def no_access_view(request):
    return render(request, 'products/no_access.html')