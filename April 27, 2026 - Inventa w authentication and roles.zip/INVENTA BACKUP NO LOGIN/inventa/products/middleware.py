from .models import Membership


class BusinessProfileMiddleware:
    """
    Attaches the current user's BusinessProfile and Membership
    to every request, if the user is authenticated and has a membership.

    Usage in any view:
        request.business_profile  → the BusinessProfile instance
        request.membership        → the Membership instance (has .role, .is_owner, .can_access())
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        request.business_profile = None
        request.membership = None

        if request.user.is_authenticated:
            try:
                membership = (
                    Membership.objects
                    .select_related('business_profile', 'role')
                    .get(user=request.user)
                )
                request.membership = membership
                request.business_profile = membership.business_profile
            except Membership.DoesNotExist:
                pass

        response = self.get_response(request)
        return response