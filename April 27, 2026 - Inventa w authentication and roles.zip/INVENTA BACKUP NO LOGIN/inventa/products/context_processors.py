def membership_context(request):
    membership = getattr(request, 'membership', None)

    if membership is None:
        # Superuser with no membership — grant everything
        perms = {
            'can_access_dashboard': True,
            'can_access_inventory': True,
            'can_access_sales': True,
            'can_access_procurement': True,
            'can_access_ecommerce': True,
            'can_access_accounting': True,
            'can_access_intelligence': True,
            'can_access_settings': True,
        }
    else:
        perms = {
            'can_access_dashboard':    membership.can_access('dashboard'),
            'can_access_inventory':    membership.can_access('inventory'),
            'can_access_sales':        membership.can_access('sales'),
            'can_access_procurement':  membership.can_access('procurement'),
            'can_access_ecommerce':    membership.can_access('ecommerce'),
            'can_access_accounting':   membership.can_access('accounting'),
            'can_access_intelligence': membership.can_access('intelligence'),
            'can_access_settings':     membership.can_access('settings'),
        }

    return {'user_membership': membership, **perms}