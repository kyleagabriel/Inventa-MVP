from django.contrib import admin
from .models import (
    Product, BusinessProfile,
    Role, ModulePermission, Membership
)


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("sku", "name", "quantity", "business_profile")
    search_fields = ("sku", "name")
    ordering = ("name",)


@admin.register(BusinessProfile)
class BusinessProfileAdmin(admin.ModelAdmin):
    list_display = ("business_name", "tin", "address")
    search_fields = ("business_name",)


class ModulePermissionInline(admin.TabularInline):
    model = ModulePermission
    extra = 0


@admin.register(Role)
class RoleAdmin(admin.ModelAdmin):
    list_display = ("name", "business_profile", "is_owner_role")
    list_filter = ("is_owner_role", "business_profile")
    inlines = [ModulePermissionInline]


@admin.register(Membership)
class MembershipAdmin(admin.ModelAdmin):
    list_display = ("user", "business_profile", "role", "joined_at")
    list_filter = ("business_profile", "role")
    search_fields = ("user__username",)