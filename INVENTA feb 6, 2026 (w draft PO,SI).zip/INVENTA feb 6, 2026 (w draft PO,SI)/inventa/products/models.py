from decimal import Decimal, ROUND_HALF_UP
from django.db import models, transaction
from django.utils import timezone
from django.core.validators import MinValueValidator
from django.db.models import F

# Create your models here.
class Product(models.Model):
    sku = models.CharField(max_length=64, unique=True)
    name = models.CharField(max_length=255)
    quantity = models.IntegerField(default=0)
    selling_price = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        null=True,
        blank=True,
    )
    is_archived = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.sku} — {self.name}"
    
class PurchaseOrder(models.Model):
    # Supplier Info
    supplier_name = models.CharField(max_length=255)
    supplier_address = models.CharField(max_length=255, blank=True)

    # Business Info
    business_name = models.CharField(max_length=255)
    business_address = models.CharField(max_length=255, blank=True)

    business_tin = models.CharField(max_length=64, blank=True)
    business_contact = models.CharField(max_length=64, blank=True)
    business_email = models.CharField(max_length=255, blank=True)
    footer_note = models.CharField(
        max_length=255,
        blank=True,
        default="THIS DOCUMENT IS NOT VALID FOR CLAIMING INPUT TAX"
    )


    # Payment Terms
    payment_terms = models.CharField(max_length=255, default="COD")

    # Date
    date = models.DateField(default=timezone.now)

    # Tax and totals
    tax_percent = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal("12.00"),
        help_text="Tax rate as a whole percent (e.g., 12.00 for 12%)"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    is_confirmed = models.BooleanField(default=False)
    confirmed_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"PO #{self.id} — {self.supplier_name} ({self.date})"

    # ---------- COMPUTED FIELDS ----------
    @property
    def subtotal(self):
        # Sum of all line totals (unit_price × qty)
        return sum((item.line_total for item in self.items.all()), Decimal("0.00"))

    @property
    def total_order_price(self):
        return self.subtotal

    def tax_value(self):
        # Convert tax_amount (12) → 0.12
        rate = self.tax_percent / Decimal("100")
        value = self.subtotal * rate
        return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    @property
    def total_with_tax(self):
        rate = self.tax_percent / Decimal("100")  # convert to 0.12
        total = self.subtotal * (Decimal("1.00") + rate)
        return total.quantize(Decimal("0.01"))

    @transaction.atomic
    def confirm_and_increase_stock(self):
        """Confirm PO once and increase stock."""
        po = PurchaseOrder.objects.select_for_update().get(pk=self.pk)

        if po.is_confirmed:
            return

        for item in po.items.select_related("product").all():
            Product.objects.filter(pk=item.product_id).update(
                quantity=F("quantity") + item.quantity_received
            )

        po.is_confirmed = True
        po.confirmed_at = timezone.now()
        po.save(update_fields=["is_confirmed", "confirmed_at"])


class PurchaseOrderItem(models.Model):
    # Link to Purchase Order
    po = models.ForeignKey(PurchaseOrder, on_delete=models.CASCADE, related_name="items")

    # 🔗 Link to Product
    product = models.ForeignKey(Product, on_delete=models.PROTECT)

    # Snapshot fields (keep historical name/SKU for printing)
    product_sku = models.CharField(max_length=64, blank=True)
    product_name = models.CharField(max_length=255, blank=True)

    # Order details
    quantity_received = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    unit_price = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(Decimal("0.00"))])

    def __str__(self):
        return f"PO#{self.po_id} • {self.product_sku or self.product.sku} x {self.quantity_received}"

    def save(self, *args, **kwargs):
        # Automatically copy product SKU and name for recordkeeping
        if not self.product_sku:
            self.product_sku = self.product.sku
        if not self.product_name:
            self.product_name = self.product.name
        super().save(*args, **kwargs)

    @property
    def line_total(self):
        # Total price per product
        return self.unit_price * self.quantity_received
    
class SalesInvoice(models.Model):
    # Customer Info
    customer_name = models.CharField(max_length=255)
    customer_address = models.CharField(max_length=255, blank=True)

    # Business Info (your business)
    business_name = models.CharField(max_length=255)
    business_address = models.CharField(max_length=255, blank=True)

    business_tin = models.CharField(max_length=64, blank=True)
    business_contact = models.CharField(max_length=64, blank=True)
    business_email = models.CharField(max_length=255, blank=True)
    footer_note = models.CharField(max_length=255, blank=True, default="THIS DOCUMENT IS NOT VALID FOR CLAIMING INPUT TAX")

    # Payment Terms
    payment_terms = models.CharField(max_length=255, default="COD")

    # Date
    date = models.DateField(default=timezone.now)

    # Tax and totals
    tax_percent = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal("12.00"),
        help_text="Tax rate as a whole percent (e.g. 12.00 for 12%)"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    is_confirmed = models.BooleanField(default=False)
    confirmed_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"SI #{self.id} — {self.customer_name} ({self.date})"

    # ---------- COMPUTED FIELDS ----------
    @property
    def subtotal(self):
        return sum((item.line_total for item in self.items.all()), Decimal("0.00"))

    def tax_value(self):
        rate = self.tax_percent / Decimal("100")
        value = self.subtotal * rate
        return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    @property
    def total_with_tax(self):
        rate = self.tax_percent / Decimal("100")
        total = self.subtotal * (Decimal("1.00") + rate)
        return total.quantize(Decimal("0.01"))

    @transaction.atomic
    def confirm_and_decrease_stock(self):
        """Confirm SI once and decrease stock (with stock validation)."""
        si = SalesInvoice.objects.select_for_update().get(pk=self.pk)

        if si.is_confirmed:
            return

        # Validate stock BEFORE applying updates
        for item in si.items.select_related("product").all():
            item.product.refresh_from_db()
            if item.product.quantity < item.quantity_sold:
                raise ValueError(
                    f"Not enough stock for {item.product.name} "
                    f"(available {item.product.quantity}, trying to sell {item.quantity_sold})"
                )

        # Apply decreases
        for item in si.items.all():
            Product.objects.filter(pk=item.product_id).update(
                quantity=F("quantity") - item.quantity_sold
            )

        si.is_confirmed = True
        si.confirmed_at = timezone.now()
        si.save(update_fields=["is_confirmed", "confirmed_at"])


class SalesInvoiceItem(models.Model):
    # Link to Sales Invoice
    invoice = models.ForeignKey(SalesInvoice, on_delete=models.CASCADE, related_name="items")

    # 🔗 Link to Product
    product = models.ForeignKey(Product, on_delete=models.PROTECT)

    # Snapshot fields
    product_sku = models.CharField(max_length=64, blank=True)
    product_name = models.CharField(max_length=255, blank=True)

    # Details
    quantity_sold = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    unit_price = models.DecimalField(
        max_digits=12, decimal_places=2,
        validators=[MinValueValidator(Decimal("0.00"))]
    )


    def __str__(self):
        return f"SI#{self.invoice_id} • {self.product_sku or self.product.sku} x {self.quantity_sold}"

    def save(self, *args, **kwargs):
        if not self.product_sku:
            self.product_sku = self.product.sku
        if not self.product_name:
            self.product_name = self.product.name
        super().save(*args, **kwargs)

    @property
    def line_total(self):
        return self.unit_price * self.quantity_sold

