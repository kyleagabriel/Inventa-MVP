from django.urls import path
from . import views

urlpatterns = [
    path("products/", views.product_list, name="product_list"),
    path("products/add/", views.add_product, name="add_product"),
    path("products/<int:pk>/delete/", views.delete_product, name="delete_product"),

     # 🆕 Stock card per product
    path("products/<int:pk>/stock-card/", views.product_stock_card, name="product_stock_card"),

    path("po/new/", views.po_create, name="po_create"),
    path("po/<int:pk>/", views.po_detail, name="po_detail"),
    path("po/<int:pk>/edit/", views.po_edit, name="po_edit"),
    path("po/<int:pk>/confirm/", views.po_confirm, name="po_confirm"),

    # 🆕 Out products / Sales Invoices
    path("si/new/", views.si_create, name="si_create"),
    path("si/<int:pk>/", views.si_detail, name="si_detail"),
    path("si/<int:pk>/edit/", views.si_edit, name="si_edit"),
    path("si/<int:pk>/confirm/", views.si_confirm, name="si_confirm"),
    
    path("products/<int:pk>/archive/", views.archive_product, name="archive_product"), 
    path("products/archived/", views.archived_product_list, name="archived_products"),
    path("products/<int:pk>/unarchive/", views.unarchive_product, name="unarchive_product"),

    path("analytics/inventory/", views.inventory_intel, name="inventory_intel"),
    ]
