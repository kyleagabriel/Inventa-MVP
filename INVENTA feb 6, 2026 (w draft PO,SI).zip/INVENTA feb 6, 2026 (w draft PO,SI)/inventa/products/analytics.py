# products/analytics.py

import datetime as dt
from statistics import mean, pstdev

from django.db.models import Sum

from .models import Product, SalesInvoiceItem


HISTORY_DAYS_DEFAULT = 180        # how far back we look
FORECAST_DAYS_DEFAULT = 30        # forecast horizon
LEAD_TIME_DAYS_DEFAULT = 7        # assumed supplier lead time (days)
Z_SERVICE_LEVEL = 1.65            # ~95% service level for safety stock


def _daterange(start_date, end_date):
    """Yield dates from start_date to end_date inclusive."""
    for n in range((end_date - start_date).days + 1):
        yield start_date + dt.timedelta(days=n)


def _get_daily_sales_series(product, history_days=HISTORY_DAYS_DEFAULT):
    """
    Returns a list of (date, qty_sold) for the last `history_days` days
    for a given product. Missing days will have qty 0.
    """
    today = dt.date.today()
    start_date = today - dt.timedelta(days=history_days)

    qs = (
        SalesInvoiceItem.objects
        .filter(
            product=product,
            invoice__date__gte=start_date,
            invoice__date__lte=today,
        )
        .values("invoice__date")
        .annotate(qty=Sum("quantity_sold"))
    )

    raw = {row["invoice__date"]: row["qty"] for row in qs}

    series = []
    for d in _daterange(start_date, today):
        series.append((d, raw.get(d, 0)))
    return series


def _simple_exponential_smoothing(values, alpha=0.3):
    """
    Very small SES implementation.
    values: list of numbers (daily demand)
    returns: smoothed_last_value, smoothed_series
    """
    if not values:
        return 0.0, []

    s = values[0]
    smoothed = [s]
    for x in values[1:]:
        s = alpha * x + (1 - alpha) * s
        smoothed.append(s)
    return s, smoothed


def build_product_demand_profile(
    product: Product,
    history_days: int = HISTORY_DAYS_DEFAULT,
    forecast_days: int = FORECAST_DAYS_DEFAULT,
    lead_time_days: int = LEAD_TIME_DAYS_DEFAULT,
):
    """
    Core engine for a single product.

    Returns a dict with:
      - avg_daily_demand
      - demand_std_daily
      - forecast_total_horizon
      - forecast_daily
      - reorder_point
      - safety_stock
      - stockout_risk_14d
      - recommended_order_qty
    """
    series = _get_daily_sales_series(product, history_days=history_days)
    daily_values = [qty for _, qty in series]

    # 1) Average + smoothed daily demand
    if any(daily_values):
        avg_daily = sum(daily_values) / len(daily_values)
    else:
        avg_daily = 0.0

    smoothed_last, smoothed_series = _simple_exponential_smoothing(daily_values)
    # We'll treat smoothed_last as our "expected" daily demand
    forecast_daily = smoothed_last

    # 2) Demand variability (std dev)
    nonzero_days = [v for v in daily_values if v > 0]
    if len(nonzero_days) >= 2:
        demand_std_daily = float(pstdev(nonzero_days))
    else:
        demand_std_daily = 0.0

    # 3) Forecast total demand over horizon (e.g., 30 days)
    forecast_total_horizon = forecast_daily * forecast_days

    # 4) Safety stock & reorder point
    safety_stock = Z_SERVICE_LEVEL * demand_std_daily * (lead_time_days ** 0.5)
    demand_during_lead_time = forecast_daily * lead_time_days
    reorder_point = demand_during_lead_time + safety_stock

    # 5) Stockout risk over next 14 days (approx)
    horizon14 = 14
    forecast_14d = forecast_daily * horizon14
    on_hand = float(product.quantity or 0)
    # For now we ignore on-order; can be extended using PurchaseOrderItems
    on_order_14d = 0.0

    coverage = on_hand + on_order_14d
    if forecast_14d <= 0:
        stockout_risk_14d = 0.0
    else:
        shortfall = max(0.0, forecast_14d - coverage)
        stockout_risk_14d = shortfall / forecast_14d  # 0–1

    # 6) Recommended order quantity (if below ROP)
    target_days_of_cover = forecast_days  # e.g. we want stock for the next 30 days
    target_stock_level = forecast_daily * target_days_of_cover
    if on_hand < reorder_point:
        recommended_order_qty = max(0.0, target_stock_level - on_hand)
    else:
        recommended_order_qty = 0.0

    return {
        "avg_daily_demand": round(avg_daily, 2),
        "forecast_daily": round(forecast_daily, 2),
        "forecast_total_horizon": round(forecast_total_horizon, 2),
        "demand_std_daily": round(demand_std_daily, 2),
        "safety_stock": round(safety_stock, 2),
        "reorder_point": round(reorder_point, 2),
        "stockout_risk_14d": round(stockout_risk_14d, 3),
        "recommended_order_qty": int(round(recommended_order_qty)),
    }
