from django import forms
from django.forms import inlineformset_factory
from .models import Product, PurchaseOrder, PurchaseOrderItem, SalesInvoice, SalesInvoiceItem

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ["sku", "name", "quantity", "selling_price"]
        widgets = {
            "sku": forms.TextInput(attrs={"placeholder": "Enter SKU"}),
            "name": forms.TextInput(attrs={"placeholder": "Enter product name"}),
            "quantity": forms.NumberInput(
                attrs={
                    "min": 0,
                    "step": 1,
                    "placeholder": "Enter quantity (e.g. 25)",
                }
            ),
            "selling_price": forms.NumberInput(
                attrs={
                    "min": 0,
                    "step": "0.01",
                    "placeholder": "Selling price (e.g. 2499.00)"},
            ),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Only for new, unbound forms (Add Product)
        if not self.instance.pk and not self.is_bound:
            self.fields["quantity"].initial = ""

    
class ProductPriceForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ["selling_price"]
        widgets = {
            "selling_price": forms.NumberInput(attrs={
                "step": "0.01",
                "min": "0",
                "class": "price-input",
                "placeholder": "0.00",
            })
        }

class PurchaseOrderForm(forms.ModelForm):
    class Meta:
        model = PurchaseOrder
        fields = [
            "supplier_name", "supplier_address",
            "business_name", "business_address",
            "business_tin", "business_contact", "business_email",
            "payment_terms", "tax_percent", "date",
            "footer_note",
        ]


class PurchaseOrderItemForm(forms.ModelForm):
    class Meta:
        model = PurchaseOrderItem
        fields = ["product", "quantity_received", "unit_price"]
        widgets = {
            "quantity_received": forms.NumberInput(attrs={"min": 1, "placeholder": "Qty"}),
            "unit_price": forms.NumberInput(attrs={"step": "0.01", "placeholder": "0.00"}),
        }

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.fields["product"].queryset = Product.objects.filter(is_archived=False).order_by("name")

PurchaseOrderItemFormSet = inlineformset_factory(
    parent_model=PurchaseOrder,
    model=PurchaseOrderItem,
    form=PurchaseOrderItemForm,
    extra=0,          # one blank row by default
    can_delete=True,  # allow removing rows
    min_num=1,
    validate_min=True,
)

class SalesInvoiceForm(forms.ModelForm):
    class Meta:
        model = SalesInvoice
        fields = [
            "customer_name", "customer_address",
            "business_name", "business_address",
            "business_tin", "business_contact", "business_email",
            "date", "tax_percent", "payment_terms",
            "footer_note",
        ]



class SalesInvoiceItemForm(forms.ModelForm):
    class Meta:
        model = SalesInvoiceItem
        fields = ["product", "quantity_sold", "unit_price"]
        widgets = {
            "quantity_sold": forms.NumberInput(attrs={"min": 1, "placeholder": "Qty"}),
            "unit_price": forms.NumberInput(attrs={"step": "0.01", "placeholder": "0.00"}),
        }

    def clean(self):
        cleaned_data = super().clean()
        product = cleaned_data.get("product")
        qty = cleaned_data.get("quantity_sold")

        def clean(self):
            cleaned_data = super().clean()
            product = cleaned_data.get("product")
            qty = cleaned_data.get("quantity_sold")

            # reset helper attributes each clean
            self.available_stock = None
            self.requested_qty = None
            self.product_name = None
            self.product_sku = None

            if product and qty is not None:
                if qty > product.quantity:
                    # save info for the view/template
                    self.available_stock = product.quantity
                    self.requested_qty = qty
                    self.product_name = product.name
                    self.product_sku = product.sku

                    self.add_error(
                        "quantity_sold",
                        f"Only {product.quantity} units available. You entered {qty}."
                    )

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.fields["product"].queryset = Product.objects.filter(is_archived=False).order_by("name")

        return cleaned_data

SalesInvoiceItemFormSet = inlineformset_factory(
    parent_model=SalesInvoice,
    model=SalesInvoiceItem,
    form=SalesInvoiceItemForm,
    extra=0,
    can_delete=True,
    min_num=1,
    validate_min=True,
)
