from decimal import Decimal
import datetime as dt
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.contrib import messages
from django.urls import reverse
from django.db import models
from django.db.models import Sum, Count, Case, When, IntegerField
from django.utils import timezone
from django.contrib.contenttypes.models import ContentType

from apps.core.decorators import module_required
from apps.sales.models import SalesInvoice, SalesInvoiceItem
from apps.ecommerce.models import EcommerceSale
from apps.procurement.models import PurchaseOrder
from apps.accounting.models import Expense, ExpenseCategory, PaymentRecord
from apps.accounting.forms import ExpenseForm, PaymentRecordForm


@login_required
@module_required('accounting')
def accounting_pl(request):
    today = timezone.localdate()

    period = request.GET.get("period", "this_month")
    custom_start = request.GET.get("start", "")
    custom_end = request.GET.get("end", "")

    if period == "last_30":
        start_date = today - dt.timedelta(days=30)
        end_date = today
    elif period == "custom" and custom_start and custom_end:
        try:
            start_date = dt.date.fromisoformat(custom_start)
            end_date = dt.date.fromisoformat(custom_end)
        except ValueError:
            start_date = today.replace(day=1)
            end_date = today
    else:
        period = "this_month"
        start_date = today.replace(day=1)
        end_date = today

    bp = request.business_profile

    # ── In-store Revenue & COGS ──
    fulfilled_sis = SalesInvoice.objects.filter(
        business_profile=bp,
        is_fulfilled=True,
        fulfilled_at__date__gte=start_date,
        fulfilled_at__date__lte=end_date,
    )
    instore_revenue = Decimal("0.00")
    instore_cogs = Decimal("0.00")
    for si in fulfilled_sis:
        for item in si.items.select_related("product").all():
            instore_revenue += item.line_total
            instore_cogs += item.cogs

    # ── E-commerce Revenue & COGS ──
    fulfilled_ecom = EcommerceSale.objects.filter(
        business_profile=bp,
        is_fulfilled=True,
        fulfilled_at__date__gte=start_date,
        fulfilled_at__date__lte=end_date,
    )
    ecom_revenue = Decimal("0.00")
    ecom_cogs = Decimal("0.00")
    for sale in fulfilled_ecom:
        ecom_revenue += sale.net_payout
        for item in sale.items.select_related("product").all():
            ecom_cogs += item.cogs

    # ── Totals ──
    total_revenue = instore_revenue + ecom_revenue
    total_cogs = instore_cogs + ecom_cogs
    gross_profit = total_revenue - total_cogs
    gross_margin_pct = (
        (gross_profit / total_revenue * 100).quantize(Decimal("0.1"))
        if total_revenue > 0 else Decimal("0.0")
    )

    # ── Operating Expenses ──
    expenses_qs = Expense.objects.filter(
        business_profile=bp,
        date__gte=start_date,
        date__lte=end_date,
    ).select_related("category")

    total_opex = expenses_qs.aggregate(
        total=models.Sum("amount")
    )["total"] or Decimal("0.00")

    expense_by_category = {}
    for exp in expenses_qs:
        cat_name = exp.category.name
        expense_by_category[cat_name] = expense_by_category.get(cat_name, Decimal("0.00")) + exp.amount

    expense_breakdown = sorted(
        [{"category": k, "amount": v} for k, v in expense_by_category.items()],
        key=lambda x: x["amount"],
        reverse=True,
    )

    net_profit = gross_profit - total_opex

    # ── Chart data ──
    import json as _json
    chart_labels = []
    chart_revenue = []
    chart_expenses = []

    cursor = start_date.replace(day=1)
    while cursor <= end_date:
        month_start = cursor
        if cursor.month == 12:
            month_end = cursor.replace(day=31)
        else:
            month_end = (cursor.replace(month=cursor.month + 1, day=1)) - dt.timedelta(days=1)
        month_end = min(month_end, end_date)

        m_sis = SalesInvoice.objects.filter(
            business_profile=bp, is_fulfilled=True,
            fulfilled_at__date__gte=month_start, fulfilled_at__date__lte=month_end,
        )
        m_ecom = EcommerceSale.objects.filter(
            business_profile=bp, is_fulfilled=True,
            fulfilled_at__date__gte=month_start, fulfilled_at__date__lte=month_end,
        )
        m_revenue = Decimal("0.00")
        for si in m_sis:
            m_revenue += si.subtotal
        for sale in m_ecom:
            m_revenue += sale.net_payout

        m_expenses = Expense.objects.filter(
            business_profile=bp,
            date__gte=month_start,
            date__lte=month_end,
        ).aggregate(total=models.Sum("amount"))["total"] or Decimal("0.00")

        chart_labels.append(cursor.strftime("%b %Y"))
        chart_revenue.append(float(m_revenue))
        chart_expenses.append(float(m_expenses))

        if cursor.month == 12:
            cursor = cursor.replace(year=cursor.year + 1, month=1, day=1)
        else:
            cursor = cursor.replace(month=cursor.month + 1, day=1)

    context = {
        "period": period,
        "start_date": start_date,
        "end_date": end_date,
        "custom_start": custom_start,
        "custom_end": custom_end,
        "instore_revenue": instore_revenue,
        "ecom_revenue": ecom_revenue,
        "total_revenue": total_revenue,
        "instore_cogs": instore_cogs,
        "ecom_cogs": ecom_cogs,
        "total_cogs": total_cogs,
        "gross_profit": gross_profit,
        "gross_margin_pct": gross_margin_pct,
        "total_opex": total_opex,
        "expense_breakdown": expense_breakdown,
        "net_profit": net_profit,
        "chart_labels": _json.dumps(chart_labels),
        "chart_revenue": _json.dumps(chart_revenue),
        "chart_expenses": _json.dumps(chart_expenses),
    }
    return render(request, "accounting/accounting_pl.html", context)


@login_required
@module_required('accounting')
def accounting_obligations(request):
    view = request.GET.get("view", "receivables")
    status_filter = request.GET.get("status", "all")

    STATUS_OPTIONS = ["all", "unpaid", "partially_paid", "paid", "overdue"]
    if status_filter not in STATUS_OPTIONS:
        status_filter = "all"

    def apply_status_filter(items):
        if status_filter == "all":
            return items
        label_map = {
            "unpaid": "Unpaid",
            "partially_paid": "Partially Paid",
            "paid": "Paid",
            "overdue": "Overdue",
        }
        target = label_map[status_filter]
        return [i for i in items if i["payment_status"] == target]

    receivables = []
    payables = []
    bp = request.business_profile

    if view == "receivables":
        for si in SalesInvoice.objects.filter(
            business_profile=bp, is_fulfilled=True
        ).order_by("-fulfilled_at"):
            receivables.append({
                "model": "si",
                "pk": si.pk,
                "date": si.fulfilled_at.date() if si.fulfilled_at else si.date,
                "ref": si.si_number,
                "party": si.customer_name,
                "source": "In-store",
                "amount_due": si.total_with_tax,
                "total_paid": si.total_paid,
                "balance_due": si.balance_due,
                "payment_status": si.payment_status,
                "due_date": si.due_date,
            })

        for sale in EcommerceSale.objects.filter(
            business_profile=bp, is_fulfilled=True
        ).order_by("-fulfilled_at"):
            receivables.append({
                "model": "ecom",
                "pk": sale.pk,
                "date": sale.fulfilled_at.date() if sale.fulfilled_at else sale.date,
                "ref": sale.order_id,
                "party": sale.customer_name or "—",
                "source": sale.get_platform_display(),
                "amount_due": sale.net_payout,
                "total_paid": sale.total_paid,
                "balance_due": sale.balance_due,
                "payment_status": sale.payment_status,
                "due_date": sale.due_date,
            })

        receivables.sort(key=lambda x: x["date"], reverse=True)
        receivables = apply_status_filter(receivables)

    else:
        for po in PurchaseOrder.objects.filter(
            business_profile=bp, is_fulfilled=True
        ).order_by("-fulfilled_at"):
            payables.append({
                "model": "po",
                "pk": po.pk,
                "date": po.fulfilled_at.date() if po.fulfilled_at else po.date,
                "ref": po.po_number,
                "party": po.supplier_name,
                "amount_due": po.total_with_tax,
                "total_paid": po.total_paid,
                "balance_due": po.balance_due,
                "payment_status": po.payment_status,
                "due_date": po.due_date,
            })
        payables = apply_status_filter(payables)

    return render(request, "accounting/accounting_obligations.html", {
        "view": view,
        "status_filter": status_filter,
        "receivables": receivables,
        "payables": payables,
    })


@login_required
@require_POST
@module_required('accounting')
def accounting_log_payment(request, model, pk):
    MODEL_MAP = {
        "si":   SalesInvoice,
        "ecom": EcommerceSale,
        "po":   PurchaseOrder,
    }
    if model not in MODEL_MAP:
        messages.error(request, "Invalid payment target.")
        return redirect("accounting_obligations")

    obj = get_object_or_404(MODEL_MAP[model], pk=pk)
    form = PaymentRecordForm(request.POST)

    if form.is_valid():
        payment = form.save(commit=False)
        payment.content_type = ContentType.objects.get_for_model(obj)
        payment.object_id = obj.pk
        payment.save()
        messages.success(request, f"Payment of ₱{payment.amount} logged successfully ✅")
    else:
        for field, errors in form.errors.items():
            for error in errors:
                messages.error(request, f"{error}")

    view = "payables" if model == "po" else "receivables"
    return redirect(f"{reverse('accounting_obligations')}?view={view}")


@login_required
@require_POST
@module_required('accounting')
def accounting_delete_payment(request, model, pk, payment_pk):
    payment = get_object_or_404(PaymentRecord, pk=payment_pk)
    payment.delete()
    messages.success(request, "Payment record deleted.")
    view = "payables" if model == "po" else "receivables"
    return redirect(f"{reverse('accounting_obligations')}?view={view}")


@login_required
@module_required('accounting')
def accounting_expenses(request):
    form = ExpenseForm(request.POST or None)

    if request.method == "POST":
        if form.is_valid():
            expense = form.save(commit=False)
            expense.business_profile = request.business_profile
            expense.save()
            messages.success(request, "Expense logged ✅")
            return redirect("accounting_expenses")

    category_filter = request.GET.get("category", "all")
    start_filter = request.GET.get("start", "")
    end_filter = request.GET.get("end", "")

    expenses = Expense.objects.filter(
        business_profile=request.business_profile
    ).select_related("category").order_by("-date", "-created_at")

    if category_filter != "all":
        try:
            expenses = expenses.filter(category__id=int(category_filter))
        except (ValueError, TypeError):
            category_filter = "all"

    if start_filter:
        try:
            expenses = expenses.filter(date__gte=dt.date.fromisoformat(start_filter))
        except ValueError:
            pass

    if end_filter:
        try:
            expenses = expenses.filter(date__lte=dt.date.fromisoformat(end_filter))
        except ValueError:
            pass

    total_filtered = expenses.aggregate(
        total=models.Sum("amount")
    )["total"] or Decimal("0.00")

    categories = ExpenseCategory.objects.all().annotate(
        sort_order=Case(
            When(name="Other", then=1),
            default=0,
            output_field=IntegerField(),
        )
    ).order_by("sort_order", "name")

    return render(request, "accounting/accounting_expenses.html", {
        "form": form,
        "expenses": expenses,
        "categories": categories,
        "category_filter": category_filter,
        "start_filter": start_filter,
        "end_filter": end_filter,
        "total_filtered": total_filtered,
    })


@login_required
@module_required('accounting')
def accounting_expense_edit(request, pk):
    expense = get_object_or_404(Expense, pk=pk)

    if request.method == "POST":
        form = ExpenseForm(request.POST, instance=expense)
        if form.is_valid():
            form.save()
            messages.success(request, "Expense updated ✅")
            return redirect("accounting_expenses")
    else:
        form = ExpenseForm(instance=expense)

    expenses = Expense.objects.filter(
        business_profile=request.business_profile
    ).select_related("category").order_by("-date", "-created_at")

    total_filtered = expenses.aggregate(
        total=models.Sum("amount")
    )["total"] or Decimal("0.00")

    categories = ExpenseCategory.objects.all().annotate(
        sort_order=Case(
            When(name="Other", then=1),
            default=0,
            output_field=IntegerField(),
        )
    ).order_by("sort_order", "name")

    return render(request, "accounting/accounting_expenses.html", {
        "form": form,
        "expense": expense,
        "editing": True,
        "expenses": expenses,
        "categories": categories,
        "category_filter": "all",
        "start_filter": "",
        "end_filter": "",
        "total_filtered": total_filtered,
    })


@login_required
@require_POST
@module_required('accounting')
def accounting_expense_delete(request, pk):
    expense = get_object_or_404(Expense, pk=pk)
    expense.delete()
    messages.success(request, "Expense deleted.")
    return redirect("accounting_expenses")


@login_required
@module_required('accounting')
def accounting_payment_history(request, model, pk):
    MODEL_MAP = {
        "si":   SalesInvoice,
        "ecom": EcommerceSale,
        "po":   PurchaseOrder,
    }
    if model not in MODEL_MAP:
        from django.http import JsonResponse
        return JsonResponse({"error": "Invalid model."}, status=400)

    obj = get_object_or_404(MODEL_MAP[model], pk=pk)
    ct = ContentType.objects.get_for_model(obj)
    payments = PaymentRecord.objects.filter(
        content_type=ct, object_id=pk
    ).order_by("-date", "-created_at")

    from django.http import JsonResponse
    data = {
        "payments": [
            {
                "pk": p.pk,
                "date": p.date.strftime("%b %d, %Y"),
                "amount": float(p.amount),
                "notes": p.notes or "—",
            }
            for p in payments
        ],
        "total_paid": float(obj.total_paid),
        "balance_due": float(obj.balance_due),
        "amount_due": float(
            obj.total_with_tax if model != "ecom" else obj.net_payout
        ),
    }
    return JsonResponse(data)