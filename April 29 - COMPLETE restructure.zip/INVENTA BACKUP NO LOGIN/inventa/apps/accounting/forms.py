from django import forms
from django.db.models import Case, When, IntegerField
from apps.accounting.models import Expense, ExpenseCategory, PaymentRecord


class ExpenseForm(forms.ModelForm):
    class Meta:
        model = Expense
        fields = ["category", "amount", "date", "notes"]
        widgets = {
            "category": forms.Select(attrs={"class": "form-select"}),
            "amount": forms.NumberInput(attrs={
                "step": "0.01",
                "min": "0.01",
                "placeholder": "0.00",
                "class": "form-input",
            }),
            "date": forms.DateInput(attrs={
                "type": "date",
                "class": "form-input",
            }),
            "notes": forms.TextInput(attrs={
                "placeholder": "Optional note (e.g. May rent, Meralco bill)",
                "class": "form-input",
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["category"].queryset = ExpenseCategory.objects.all().annotate(
            sort_order=Case(
                When(name="Other", then=1),
                default=0,
                output_field=IntegerField(),
            )
        ).order_by("sort_order", "name")
        self.fields["notes"].required = False


class PaymentRecordForm(forms.ModelForm):
    class Meta:
        model = PaymentRecord
        fields = ["amount", "date", "notes"]
        widgets = {
            "amount": forms.NumberInput(attrs={
                "step": "0.01",
                "min": "0.01",
                "placeholder": "0.00",
                "class": "form-input",
            }),
            "date": forms.DateInput(attrs={
                "type": "date",
                "class": "form-input",
            }),
            "notes": forms.TextInput(attrs={
                "placeholder": "Optional note (e.g. GCash transfer, cash payment)",
                "class": "form-input",
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["notes"].required = False