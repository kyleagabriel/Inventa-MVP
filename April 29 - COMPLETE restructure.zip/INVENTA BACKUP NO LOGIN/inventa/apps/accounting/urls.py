from django.urls import path
from apps.accounting import views

urlpatterns = [
    path('pl/', views.accounting_pl, name='accounting_pl'),
    path('obligations/', views.accounting_obligations, name='accounting_obligations'),
    path('obligations/<str:model>/<int:pk>/pay/', views.accounting_log_payment, name='accounting_log_payment'),
    path('obligations/<str:model>/<int:pk>/payments/<int:payment_pk>/delete/', views.accounting_delete_payment, name='accounting_delete_payment'),
    path('obligations/<str:model>/<int:pk>/payments/', views.accounting_payment_history, name='accounting_payment_history'),
    path('expenses/', views.accounting_expenses, name='accounting_expenses'),
    path('expenses/<int:pk>/edit/', views.accounting_expense_edit, name='accounting_expense_edit'),
    path('expenses/<int:pk>/delete/', views.accounting_expense_delete, name='accounting_expense_delete'),
]