import datetime as dt
import json as _json
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Sum, Count, ExpressionWrapper, DecimalField, F

from apps.core.models import Product
from apps.core.decorators import module_required
from apps.sales.models import SalesInvoice, SalesInvoiceItem
from apps.intelligence.analytics import (
    build_product_demand_profile,
    get_fast_movers_by_velocity,
    get_fast_movers_by_margin,
    get_deadstock_items,
)


@login_required
@module_required('intelligence')
def inventory_intel(request):
    profile = request.business_profile

    # ── Handle deadstock threshold save ──
    if request.method == "POST" and "deadstock_threshold_days" in request.POST:
        try:
            threshold = int(request.POST["deadstock_threshold_days"])
            if threshold < 1:
                threshold = 1
            profile.deadstock_threshold_days = threshold
            profile.save(update_fields=["deadstock_threshold_days"])
            messages.success(request, "Deadstock threshold updated.")
        except (ValueError, TypeError):
            messages.error(request, "Invalid threshold value.")
        return redirect("inventory_intel")

    products = (
        Product.objects
        .filter(business_profile=request.business_profile, is_archived=False)
        .order_by("name")
    )
    products_list = list(products)

    # ── TAB 1: Reorder Alerts ──
    reorder_rows = []
    needs_reorder_count = 0
    high_risk_count = 0

    for p in products_list:
        prof = build_product_demand_profile(p)
        risk = prof["stockout_risk_14d"]
        if risk > 0.7:
            risk_label = "high"
            high_risk_count += 1
        elif risk > 0.3:
            risk_label = "medium"
        else:
            risk_label = "low"

        if prof["recommended_order_qty"] > 0:
            needs_reorder_count += 1

        reorder_rows.append({
            "product":               p,
            "days_of_stock":         prof["days_of_stock"],
            "reorder_by_date":       prof["reorder_by_date"],
            "recommended_order_qty": prof["recommended_order_qty"],
            "risk_label":            risk_label,
            "stockout_risk_14d":     risk,
        })

    risk_order = {"high": 0, "medium": 1, "low": 2}
    reorder_rows.sort(key=lambda r: risk_order[r["risk_label"]])

    # ── TAB 2: Fast Movers ──
    fast_by_velocity = get_fast_movers_by_velocity(products_list, days=30)
    fast_by_margin = get_fast_movers_by_margin(products_list)

    # ── TAB 3: Deadstock ──
    threshold = profile.deadstock_threshold_days
    deadstock_rows = get_deadstock_items(
        products_list,
        threshold_days=threshold,
        fast_movers=fast_by_velocity,
    )
    total_idle_capital = sum(r["idle_capital"] for r in deadstock_rows)

    active_tab = request.GET.get("tab", "overview")

    # ── TAB 0: Overview ──
    overview_days = 90
    overview_start = dt.date.today() - dt.timedelta(days=overview_days)

    daily_revenue_qs = (
        SalesInvoiceItem.objects
        .filter(
            invoice__business_profile=request.business_profile,
            invoice__date__gte=overview_start,
            invoice__is_cancelled=False,
            invoice__is_confirmed=True,
        )
        .values("invoice__date")
        .annotate(
            revenue=Sum(
                ExpressionWrapper(
                    F("quantity_sold") * F("unit_price"),
                    output_field=DecimalField()
                )
            ),
            units=Sum("quantity_sold"),
        )
        .order_by("invoice__date")
    )

    daily_revenue_data = [
        {
            "date":    str(row["invoice__date"]),
            "revenue": float(row["revenue"] or 0),
            "units":   int(row["units"] or 0),
        }
        for row in daily_revenue_qs
    ]

    invoice_counts_qs = (
        SalesInvoice.objects
        .filter(
            business_profile=request.business_profile,
            date__gte=overview_start,
            is_cancelled=False,
            is_confirmed=True,
        )
        .values("date")
        .annotate(count=Count("id"))
        .order_by("date")
    )

    invoice_counts_data = {
        str(row["date"]): row["count"]
        for row in invoice_counts_qs
    }

    for d in daily_revenue_data:
        d["invoices"] = invoice_counts_data.get(d["date"], 0)

    product_revenue_qs = (
        SalesInvoiceItem.objects
        .filter(
            invoice__business_profile=request.business_profile,
            invoice__date__gte=overview_start,
            invoice__is_cancelled=False,
            invoice__is_confirmed=True,
        )
        .values("product__id", "product__name", "product__sku", "invoice__date")
        .annotate(
            revenue=Sum(
                ExpressionWrapper(
                    F("quantity_sold") * F("unit_price"),
                    output_field=DecimalField()
                )
            ),
            units=Sum("quantity_sold"),
        )
    )

    product_revenue_data = [
        {
            "product_id": row["product__id"],
            "name":       row["product__name"],
            "sku":        row["product__sku"],
            "date":       str(row["invoice__date"]),
            "revenue":    float(row["revenue"] or 0),
            "units":      int(row["units"] or 0),
        }
        for row in product_revenue_qs
    ]

    context = {
        "active_tab":            active_tab,
        "overview_data_json":    _json.dumps(daily_revenue_data),
        "overview_product_json": _json.dumps(product_revenue_data),
        "reorder_rows":          reorder_rows,
        "needs_reorder_count":   needs_reorder_count,
        "high_risk_count":       high_risk_count,
        "total_skus":            len(products_list),
        "fast_by_velocity":      fast_by_velocity,
        "fast_by_margin":        fast_by_margin,
        "deadstock_rows":        deadstock_rows,
        "total_idle_capital":    total_idle_capital,
        "deadstock_threshold":   threshold,
    }
    return render(request, "intelligence/inventory_intel.html", context)