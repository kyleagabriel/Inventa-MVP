from django.urls import path
from apps.intelligence import views

urlpatterns = [
    path('', views.inventory_intel, name='inventory_intel'),
]