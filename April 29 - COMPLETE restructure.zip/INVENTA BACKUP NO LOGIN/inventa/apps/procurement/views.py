from decimal import Decimal, ROUND_HALF_UP
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.contrib import messages
from django.urls import reverse
from django.db import transaction
from django.utils import timezone

from apps.core.models import Product
from apps.core.decorators import module_required
from apps.procurement.models import PurchaseOrder, PurchaseOrderItem, FulfillmentRecord
from apps.procurement.forms import PurchaseOrderForm, PurchaseOrderItemFormSet


@login_required
@module_required('procurement')
def po_list(request):
    status_filter = request.GET.get("status", "all")
    bp = request.business_profile

    pos = PurchaseOrder.objects.filter(
        business_profile=bp
    ).prefetch_related("items").order_by("-created_at")

    po_ids_with_fulfillments = FulfillmentRecord.objects.filter(
        po_item__po__business_profile=bp
    ).values_list("po_item__po_id", flat=True).distinct()

    if status_filter == "draft":
        pos = pos.filter(is_confirmed=False, is_cancelled=False)
    elif status_filter == "confirmed":
        confirmed_pos = pos.filter(is_confirmed=True, is_fulfilled=False, is_cancelled=False)
        pos = confirmed_pos.exclude(pk__in=po_ids_with_fulfillments)
    elif status_filter == "partial":
        confirmed_pos = pos.filter(is_confirmed=True, is_fulfilled=False, is_cancelled=False)
        pos = confirmed_pos.filter(pk__in=po_ids_with_fulfillments)
    elif status_filter == "fulfilled":
        pos = pos.filter(is_fulfilled=True)
    elif status_filter == "cancelled":
        pos = pos.filter(is_cancelled=True)

    all_confirmed = PurchaseOrder.objects.filter(
        business_profile=bp, is_confirmed=True, is_fulfilled=False, is_cancelled=False
    )
    counts = {
        "all":       PurchaseOrder.objects.filter(business_profile=bp).count(),
        "draft":     PurchaseOrder.objects.filter(business_profile=bp, is_confirmed=False, is_cancelled=False).count(),
        "confirmed": all_confirmed.exclude(pk__in=po_ids_with_fulfillments).count(),
        "partial":   all_confirmed.filter(pk__in=po_ids_with_fulfillments).count(),
        "fulfilled": PurchaseOrder.objects.filter(business_profile=bp, is_fulfilled=True).count(),
        "cancelled": PurchaseOrder.objects.filter(business_profile=bp, is_cancelled=True).count(),
    }

    return render(request, "procurement/po_list.html", {
        "pos": pos,
        "status_filter": status_filter,
        "counts": counts,
    })


@login_required
@module_required('procurement')
def po_create(request):
    profile = request.business_profile

    if request.method == "POST":
        form = PurchaseOrderForm(request.POST)
        formset = PurchaseOrderItemFormSet(
            request.POST, business_profile=request.business_profile
        )
        if form.is_valid() and formset.is_valid():
            po = form.save(commit=False)
            po.business_name = profile.business_name
            po.business_address = profile.address
            po.business_tin = profile.tin
            po.business_profile = request.business_profile
            po.is_confirmed = False
            po.confirmed_at = None
            po.save()
            formset.instance = po
            formset.save()
            messages.success(request, "PO saved as draft ✅")
            return redirect("po_detail", pk=po.pk)
    else:
        form = PurchaseOrderForm(initial={
            "business_name":    profile.business_name,
            "business_address": profile.address,
            "business_tin":     profile.tin,
            "date":             timezone.localdate(),
        })
        formset = PurchaseOrderItemFormSet(business_profile=request.business_profile)
        for f in ["business_name", "business_address", "business_tin"]:
            if f in form.fields:
                form.fields[f].widget.attrs["readonly"] = True

    return render(request, "procurement/po_create.html", {
        "form": form,
        "formset": formset,
        "mode": "create",
        "products": Product.objects.filter(
            business_profile=request.business_profile, is_archived=False
        ).order_by("name"),
    })


@login_required
@transaction.atomic
@module_required('procurement')
def po_edit(request, pk):
    po = get_object_or_404(PurchaseOrder, pk=pk)

    if po.is_confirmed:
        messages.error(request, "This PO is already confirmed and cannot be edited.")
        return redirect("po_detail", pk=po.pk)

    if request.method == "POST":
        form = PurchaseOrderForm(request.POST, instance=po)
        formset = PurchaseOrderItemFormSet(
            request.POST, instance=po, business_profile=request.business_profile
        )
        if form.is_valid() and formset.is_valid():
            form.save()
            formset.save()
            messages.success(request, "Draft updated ✅")
            return redirect("po_detail", pk=po.pk)
    else:
        form = PurchaseOrderForm(instance=po)
        formset = PurchaseOrderItemFormSet(
            instance=po, business_profile=request.business_profile
        )

    return render(request, "procurement/po_create.html", {
        "form": form,
        "formset": formset,
        "mode": "edit",
        "po": po,
        "products": Product.objects.filter(
            business_profile=request.business_profile, is_archived=False
        ).order_by("name"),
    })


@login_required
@module_required('procurement')
def po_detail(request, pk):
    po = get_object_or_404(PurchaseOrder, pk=pk)

    from_stock_card = request.GET.get("from_stock_card")
    if from_stock_card:
        back_url = reverse("product_stock_card", args=[from_stock_card])
        back_label = "Back to Stock Card"
    else:
        back_url = reverse("po_list")
        back_label = "Back to Purchase Orders"

    return render(request, "procurement/po_detail.html", {
        "po": po,
        "back_url": back_url,
        "back_label": back_label,
    })


@login_required
@module_required('procurement')
def po_confirm(request, pk):
    if request.method != "POST":
        return redirect("po_detail", pk=pk)

    po = get_object_or_404(PurchaseOrder, pk=pk)

    if po.is_confirmed:
        messages.info(request, "This PO is already confirmed ✅")
        return redirect("po_detail", pk=po.pk)

    po.confirm_and_increase_stock()
    messages.success(request, "PO confirmed ✅ — Awaiting delivery from supplier 🚚")
    return redirect("po_detail", pk=po.pk)


@login_required
@transaction.atomic
@module_required('procurement')
def po_fulfill(request, pk):
    po = get_object_or_404(PurchaseOrder, pk=pk)

    if not po.is_confirmed:
        messages.error(request, "PO must be confirmed before it can be fulfilled.")
        return redirect("po_detail", pk=pk)
    if po.is_cancelled:
        messages.error(request, "This PO has been cancelled.")
        return redirect("po_detail", pk=pk)
    if po.is_fulfilled:
        messages.info(request, "This PO is already fully fulfilled.")
        return redirect("po_detail", pk=pk)
    if request.method != "POST":
        return redirect("po_detail", pk=pk)

    items = po.items.all()
    any_received = False
    errors = []

    for item in items:
        field_key = f"qty_fulfill_{item.pk}"
        raw = request.POST.get(field_key, "").strip()
        if not raw:
            continue
        try:
            qty = int(raw)
        except ValueError:
            errors.append(f"Invalid quantity for {item.product_name}.")
            continue
        if qty <= 0:
            continue

        remaining = item.quantity_remaining
        if qty > remaining:
            errors.append(
                f"Cannot receive {qty} for {item.product_name} — "
                f"only {remaining} units still outstanding."
            )
            continue

        notes = request.POST.get(f"notes_{item.pk}", "").strip()
        FulfillmentRecord.objects.create(po_item=item, quantity=qty, notes=notes)

        product = Product.objects.select_for_update().get(pk=item.product_id)
        old_qty = product.quantity
        old_cost = product.avg_cost
        new_cost_per_unit = item.unit_price
        new_total_qty = old_qty + qty
        if new_total_qty > 0:
            weighted_avg = ((old_qty * old_cost) + (qty * new_cost_per_unit)) / new_total_qty
        else:
            weighted_avg = new_cost_per_unit
        weighted_avg = Decimal(str(weighted_avg)).quantize(
            Decimal("0.01"), rounding=ROUND_HALF_UP
        )
        product.quantity = new_total_qty
        product.avg_cost = weighted_avg
        product.save(update_fields=["quantity", "avg_cost"])
        any_received = True

    if errors:
        for e in errors:
            messages.error(request, e)
        if not any_received:
            return redirect("po_detail", pk=pk)

    if not any_received and not errors:
        messages.warning(request, "No quantities entered. Nothing was recorded.")
        return redirect("po_detail", pk=pk)

    po.refresh_from_db()
    all_items = po.items.prefetch_related("fulfillments").all()
    fully_fulfilled = all(
        item.quantity_fulfilled >= item.quantity_received for item in all_items
    )
    if fully_fulfilled:
        po.is_fulfilled = True
        po.fulfilled_at = timezone.now()
        po.save(update_fields=["is_fulfilled", "fulfilled_at"])
        messages.success(request, "PO fully fulfilled ✅ Stock has been updated 📦")
    else:
        messages.success(request, "Partial fulfillment recorded ✅ Stock updated for received items 📦")

    return redirect("po_detail", pk=pk)


@login_required
@require_POST
@module_required('procurement')
def po_cancel(request, pk):
    po = get_object_or_404(PurchaseOrder, pk=pk)
    try:
        po.cancel()
        messages.success(request, "Purchase Order cancelled.")
    except ValueError as e:
        messages.error(request, str(e))
    return redirect("po_detail", pk=pk)