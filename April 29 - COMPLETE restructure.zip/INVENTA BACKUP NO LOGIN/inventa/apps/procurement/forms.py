from django import forms
from django.forms import inlineformset_factory
from apps.core.models import Product
from apps.procurement.models import PurchaseOrder, PurchaseOrderItem


class PurchaseOrderForm(forms.ModelForm):
    class Meta:
        model = PurchaseOrder
        fields = [
            "supplier_name", "supplier_address",
            "business_name", "business_address",
            "business_tin", "business_contact", "business_email",
            "payment_terms", "tax_percent", "date",
            "footer_note",
        ]
        widgets = {
            "date": forms.DateInput(attrs={"type": "date"}),
        }


class PurchaseOrderItemForm(forms.ModelForm):
    class Meta:
        model = PurchaseOrderItem
        fields = ["product", "quantity_received", "unit_price"]
        widgets = {
            "quantity_received": forms.NumberInput(attrs={"min": 1, "placeholder": "Qty"}),
            "unit_price": forms.NumberInput(attrs={"step": "0.01", "placeholder": "0.00"}),
        }

    def __init__(self, *args, **kwargs):
        self.business_profile = kwargs.pop("business_profile", None)
        super().__init__(*args, **kwargs)
        if self.business_profile:
            self.fields["product"].queryset = Product.objects.filter(
                business_profile=self.business_profile, is_archived=False
            ).order_by("name")
        else:
            self.fields["product"].queryset = Product.objects.none()


class PurchaseOrderItemFormSetBase(forms.BaseInlineFormSet):
    def __init__(self, *args, **kwargs):
        self.business_profile = kwargs.pop("business_profile", None)
        super().__init__(*args, **kwargs)

    def _construct_form(self, i, **kwargs):
        kwargs["business_profile"] = self.business_profile
        return super()._construct_form(i, **kwargs)


PurchaseOrderItemFormSet = inlineformset_factory(
    parent_model=PurchaseOrder,
    model=PurchaseOrderItem,
    form=PurchaseOrderItemForm,
    formset=PurchaseOrderItemFormSetBase,
    extra=0,
    can_delete=True,
    min_num=1,
    validate_min=True,
)