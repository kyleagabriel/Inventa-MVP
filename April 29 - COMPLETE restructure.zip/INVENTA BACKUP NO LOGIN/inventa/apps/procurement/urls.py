from django.urls import path
from apps.procurement import views

urlpatterns = [
    path('', views.po_list, name='po_list'),
    path('new/', views.po_create, name='po_create'),
    path('<int:pk>/', views.po_detail, name='po_detail'),
    path('<int:pk>/edit/', views.po_edit, name='po_edit'),
    path('<int:pk>/confirm/', views.po_confirm, name='po_confirm'),
    path('<int:pk>/fulfill/', views.po_fulfill, name='po_fulfill'),
    path('<int:pk>/cancel/', views.po_cancel, name='po_cancel'),
]