from decimal import Decimal
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.contrib import messages
from django.http import JsonResponse
from django.db.models import Exists, OuterRef, F

from apps.core.models import Product, Category
from apps.core.forms import ProductForm, ProductPriceForm
from apps.core.decorators import module_required, any_module_required
from apps.procurement.models import PurchaseOrderItem, FulfillmentRecord
from apps.sales.models import SalesInvoiceItem, SIFulfillmentRecord


# ─────────────────────────────────────────────
#  PRODUCT SEARCH API
# ─────────────────────────────────────────────

@login_required
@any_module_required('inventory', 'sales', 'procurement', 'ecommerce')
def product_search_api(request):
    from django.db import models
    query = request.GET.get('q', '').strip()

    if len(query) < 1:
        return JsonResponse({'results': []})

    products = Product.objects.filter(
        business_profile=request.business_profile,
        is_archived=False
    ).filter(
        models.Q(name__icontains=query) | models.Q(sku__icontains=query)
    )[:20]

    results = []
    for product in products:
        results.append({
            'id': product.id,
            'sku': product.sku,
            'name': product.name,
            'stock': product.quantity,
            'price': float(product.selling_price) if product.selling_price else 0.00,
        })

    return JsonResponse({'results': results})


# ─────────────────────────────────────────────
#  PRODUCT VIEWS
# ─────────────────────────────────────────────

@login_required
@module_required('inventory')
def product_list(request):
    category_filter = request.GET.get("category", "all")

    products = (
        Product.objects
        .filter(business_profile=request.business_profile, is_archived=False)
        .select_related("category")
        .annotate(
            has_po_items=Exists(
                PurchaseOrderItem.objects.filter(product=OuterRef("pk"))
            ),
            has_si_items=Exists(
                SalesInvoiceItem.objects.filter(product=OuterRef("pk"))
            ),
        )
        .order_by("name")
    )

    if category_filter != "all":
        if category_filter == "uncategorized":
            products = products.filter(category__isnull=True)
        else:
            products = products.filter(category__id=category_filter)

    categories = Category.objects.filter(business_profile=request.business_profile)

    return render(request, "inventory/product_list.html", {
        "products": products,
        "categories": categories,
        "category_filter": category_filter,
    })


@login_required
@module_required('inventory')
def add_product(request):
    if request.method == "POST":
        form = ProductForm(request.POST, business_profile=request.business_profile)
        if form.is_valid():
            product = form.save(commit=False)
            product.business_profile = request.business_profile
            product.save()
            return redirect("product_list")
    else:
        form = ProductForm(business_profile=request.business_profile)

    categories = Category.objects.filter(business_profile=request.business_profile)
    return render(request, "inventory/add_product.html", {
        "form": form,
        "categories": categories,
    })


@login_required
@require_POST
@module_required('inventory')
def add_product_quick(request):
    sku = request.POST.get("sku", "").strip()
    name = request.POST.get("name", "").strip()
    selling_price = request.POST.get("selling_price", "").strip()

    errors = {}
    if not sku:
        errors["sku"] = "SKU is required."
    if not name:
        errors["name"] = "Product name is required."
    if Product.objects.filter(business_profile=request.business_profile, sku=sku).exists():
        errors["sku"] = "A product with this SKU already exists."

    if errors:
        return JsonResponse({"success": False, "errors": errors})

    product = Product.objects.create(
        sku=sku,
        name=name,
        quantity=0,
        selling_price=selling_price if selling_price else None,
        business_profile=request.business_profile,
    )
    return JsonResponse({
        "success": True,
        "product": {
            "id": product.id,
            "sku": product.sku,
            "name": product.name,
            "stock": 0,
            "price": float(product.selling_price) if product.selling_price else None,
        }
    })


@login_required
@require_POST
@module_required('inventory')
def delete_product(request, pk):
    product = get_object_or_404(Product, pk=pk)

    has_po = PurchaseOrderItem.objects.filter(product=product).exists()
    has_si = SalesInvoiceItem.objects.filter(product=product).exists()

    if has_po or has_si:
        messages.error(
            request,
            "This product already has transactions and cannot be deleted. "
            "You can archive it instead."
        )
        return redirect("product_list")

    product.delete()
    messages.success(request, f"Product {product.sku} deleted.")
    return redirect("product_list")


@login_required
@module_required('inventory')
def product_stock_card(request, pk):
    product = get_object_or_404(Product, pk=pk)

    if request.method == "POST":
        price_form = ProductPriceForm(request.POST, instance=product)
        if price_form.is_valid():
            price_form.save()
            return redirect(request.path)
    else:
        price_form = ProductPriceForm(instance=product)

    entries = []
    total_qty_in = 0
    total_cost = Decimal("0.00")

    fulfillments = (
        FulfillmentRecord.objects
        .filter(po_item__product=product)
        .select_related("po_item", "po_item__po")
    )
    for record in fulfillments:
        item = record.po_item
        po = item.po
        entries.append({
            "date": record.received_at,
            "type": "IN",
            "ref_type": "PO",
            "ref_id": po.id,
            "partner": po.supplier_name,
            "qty_in": record.quantity,
            "qty_out": 0,
        })
        total_qty_in += record.quantity
        total_cost += item.unit_price * record.quantity

    si_fulfillments = (
        SIFulfillmentRecord.objects
        .filter(si_item__product=product)
        .select_related("si_item", "si_item__invoice")
    )
    for record in si_fulfillments:
        item = record.si_item
        inv = item.invoice
        entries.append({
            "date": record.delivered_at,
            "type": "OUT",
            "ref_type": "SI",
            "ref_id": inv.id,
            "partner": inv.customer_name,
            "qty_in": 0,
            "qty_out": record.quantity,
        })

    entries.sort(key=lambda e: e["date"])
    total_delta = sum(e["qty_in"] - e["qty_out"] for e in entries)
    current_qty = product.quantity
    opening_qty = current_qty - total_delta

    running = opening_qty
    for e in entries:
        delta = e["qty_in"] - e["qty_out"]
        running += delta
        e["balance"] = running

    entries.sort(key=lambda e: e["date"], reverse=True)
    average_cost = (total_cost / total_qty_in) if total_qty_in > 0 else None

    categories = Category.objects.filter(business_profile=request.business_profile)

    return render(request, "inventory/stock_card.html", {
        "product": product,
        "entries": entries,
        "average_cost": average_cost,
        "price_form": price_form,
        "categories": categories,
    })


@login_required
@require_POST
@module_required('inventory')
def archive_product(request, pk):
    product = get_object_or_404(Product, pk=pk)
    product.is_archived = True
    product.save(update_fields=["is_archived"])
    messages.success(
        request,
        f"Product {product.sku} archived. It will no longer appear in the product list."
    )
    return redirect("product_list")


@login_required
@module_required('inventory')
def archived_product_list(request):
    products = (
        Product.objects
        .filter(business_profile=request.business_profile, is_archived=True)
        .annotate(
            has_po_items=Exists(
                PurchaseOrderItem.objects.filter(product=OuterRef("pk"))
            ),
            has_si_items=Exists(
                SalesInvoiceItem.objects.filter(product=OuterRef("pk"))
            ),
        )
        .order_by("name")
    )
    return render(request, "inventory/archived_products.html", {"products": products})


@login_required
@require_POST
@module_required('inventory')
def unarchive_product(request, pk):
    product = get_object_or_404(Product, pk=pk)
    product.is_archived = False
    product.save(update_fields=["is_archived"])
    messages.success(request, f"{product.sku} restored.")
    return redirect("archived_products")


# ─────────────────────────────────────────────
#  CATEGORY API
# ─────────────────────────────────────────────

@login_required
@module_required('inventory')
def category_search_api(request):
    query = request.GET.get("q", "").strip()
    categories = Category.objects.filter(business_profile=request.business_profile)
    if query:
        categories = categories.filter(name__icontains=query)
    results = [{"id": c.id, "name": c.name, "color": c.color} for c in categories]
    return JsonResponse({"results": results})


@login_required
@require_POST
@module_required('inventory')
def category_create_api(request):
    name = request.POST.get("name", "").strip()

    if not name:
        return JsonResponse({"success": False, "error": "Name is required."})

    if Category.objects.filter(
        business_profile=request.business_profile, name__iexact=name
    ).exists():
        cat = Category.objects.get(
            business_profile=request.business_profile, name__iexact=name
        )
        return JsonResponse({"success": True, "category": {
            "id": cat.id, "name": cat.name, "color": cat.color
        }})

    COLOR_SEQUENCE = [
        "cat-orange", "cat-purple", "cat-blue", "cat-green",
        "cat-red", "cat-teal", "cat-pink", "cat-yellow",
    ]
    used_colors = set(
        Category.objects.filter(
            business_profile=request.business_profile
        ).values_list("color", flat=True)
    )
    assigned_color = "cat-orange"
    for color in COLOR_SEQUENCE:
        if color not in used_colors:
            assigned_color = color
            break

    cat = Category.objects.create(
        name=name,
        color=assigned_color,
        business_profile=request.business_profile
    )
    return JsonResponse({"success": True, "category": {
        "id": cat.id, "name": cat.name, "color": cat.color
    }})


@login_required
@require_POST
@module_required('inventory')
def category_assign_api(request, product_pk):
    product = get_object_or_404(Product, pk=product_pk)
    category_id = request.POST.get("category_id", "").strip()

    if not category_id or category_id == "none":
        product.category = None
    else:
        category = get_object_or_404(Category, pk=category_id)
        product.category = category

    product.save(update_fields=["category"])
    return JsonResponse({"success": True})


@login_required
@require_POST
@module_required('inventory')
def category_rename_api(request, pk):
    category = get_object_or_404(Category, pk=pk)
    new_name = request.POST.get("name", "").strip()

    if not new_name:
        return JsonResponse({"success": False, "error": "Name is required."})

    if Category.objects.filter(
        business_profile=request.business_profile, name__iexact=new_name
    ).exclude(pk=pk).exists():
        return JsonResponse({"success": False, "error": "A category with this name already exists."})

    category.name = new_name
    category.save(update_fields=["name"])
    return JsonResponse({"success": True, "category": {
        "id": category.id, "name": category.name, "color": category.color
    }})


@login_required
@require_POST
@module_required('inventory')
def category_delete_api(request, pk):
    category = get_object_or_404(Category, pk=pk)
    affected_count = category.products.count()
    category.delete()
    return JsonResponse({"success": True, "affected_count": affected_count})


@login_required
@module_required('inventory')
def category_list_api(request):
    from django.db import models
    categories = Category.objects.filter(
        business_profile=request.business_profile
    ).annotate(
        product_count=models.Count("products")
    ).order_by("name")

    results = [
        {
            "id": c.id,
            "name": c.name,
            "color": c.color,
            "product_count": c.product_count,
        }
        for c in categories
    ]
    return JsonResponse({"results": results})