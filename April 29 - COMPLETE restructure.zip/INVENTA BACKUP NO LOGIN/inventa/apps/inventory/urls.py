from django.urls import path
from apps.inventory import views

urlpatterns = [
    path('', views.product_list, name='product_list'),
    path('add/', views.add_product, name='add_product'),
    path('quick-add/', views.add_product_quick, name='add_product_quick'),
    path('<int:pk>/delete/', views.delete_product, name='delete_product'),
    path('<int:pk>/stock-card/', views.product_stock_card, name='product_stock_card'),
    path('<int:pk>/archive/', views.archive_product, name='archive_product'),
    path('<int:pk>/unarchive/', views.unarchive_product, name='unarchive_product'),
    path('archived/', views.archived_product_list, name='archived_products'),
    path('api/search/', views.product_search_api, name='product_search_api'),
    path('api/categories/', views.category_search_api, name='category_search_api'),
    path('api/categories/list/', views.category_list_api, name='category_list_api'),
    path('api/categories/create/', views.category_create_api, name='category_create_api'),
    path('api/categories/<int:pk>/rename/', views.category_rename_api, name='category_rename_api'),
    path('api/categories/<int:pk>/delete/', views.category_delete_api, name='category_delete_api'),
    path('api/<int:product_pk>/assign-category/', views.category_assign_api, name='category_assign_api'),
]