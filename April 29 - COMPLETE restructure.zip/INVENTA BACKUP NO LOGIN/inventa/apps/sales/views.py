from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.contrib import messages
from django.urls import reverse
from django.db import transaction
from django.db.models import F

from apps.core.models import Product
from apps.core.decorators import module_required
from apps.sales.models import SalesInvoice, SalesInvoiceItem, SIFulfillmentRecord
from apps.sales.forms import SalesInvoiceForm, SalesInvoiceItemFormSet


@login_required
@module_required('sales')
def si_list(request):
    status_filter = request.GET.get("status", "all")
    bp = request.business_profile
    sis = SalesInvoice.objects.filter(business_profile=bp).order_by("-created_at")

    si_ids_with_fulfillments = SIFulfillmentRecord.objects.filter(
        si_item__invoice__business_profile=bp
    ).values_list("si_item__invoice_id", flat=True).distinct()

    if status_filter == "draft":
        sis = sis.filter(is_confirmed=False, is_cancelled=False)
    elif status_filter == "confirmed":
        confirmed = sis.filter(is_confirmed=True, is_fulfilled=False, is_cancelled=False)
        sis = confirmed.exclude(pk__in=si_ids_with_fulfillments)
    elif status_filter == "partial":
        confirmed = sis.filter(is_confirmed=True, is_fulfilled=False, is_cancelled=False)
        sis = confirmed.filter(pk__in=si_ids_with_fulfillments)
    elif status_filter == "fulfilled":
        sis = sis.filter(is_fulfilled=True)
    elif status_filter == "cancelled":
        sis = sis.filter(is_cancelled=True)

    all_confirmed = SalesInvoice.objects.filter(
        business_profile=bp, is_confirmed=True, is_fulfilled=False, is_cancelled=False
    )
    counts = {
        "all":       SalesInvoice.objects.filter(business_profile=bp).count(),
        "draft":     SalesInvoice.objects.filter(business_profile=bp, is_confirmed=False, is_cancelled=False).count(),
        "confirmed": all_confirmed.exclude(pk__in=si_ids_with_fulfillments).count(),
        "partial":   all_confirmed.filter(pk__in=si_ids_with_fulfillments).count(),
        "fulfilled": SalesInvoice.objects.filter(business_profile=bp, is_fulfilled=True).count(),
        "cancelled": SalesInvoice.objects.filter(business_profile=bp, is_cancelled=True).count(),
    }

    return render(request, "sales/si_list.html", {
        "sis": sis,
        "status_filter": status_filter,
        "counts": counts,
    })


@login_required
@transaction.atomic
@module_required('sales')
def si_create(request):
    profile = request.business_profile

    if request.method == "POST":
        form = SalesInvoiceForm(request.POST)
        formset = SalesInvoiceItemFormSet(
            request.POST, business_profile=request.business_profile
        )
        if form.is_valid() and formset.is_valid():
            invoice = form.save(commit=False)
            invoice.business_name = profile.business_name
            invoice.business_address = profile.address
            invoice.business_tin = profile.tin
            invoice.business_profile = request.business_profile
            invoice.is_confirmed = False
            invoice.save()
            formset.instance = invoice
            formset.save()
            messages.success(request, "Sales Invoice draft created ✅ Review it and confirm when ready.")
            return redirect(f"/si/{invoice.pk}/?from=create")
    else:
        from django.utils import timezone
        form = SalesInvoiceForm(initial={
            "business_name":    profile.business_name,
            "business_address": profile.address,
            "business_tin":     profile.tin,
            "date":             timezone.localdate(),
        })
        formset = SalesInvoiceItemFormSet(business_profile=request.business_profile)
        for f in ["business_name", "business_address", "business_tin"]:
            if f in form.fields:
                form.fields[f].widget.attrs["readonly"] = True

    products = Product.objects.filter(
        business_profile=request.business_profile, is_archived=False
    ).order_by("name")
    return render(request, "sales/si_create.html", {
        "form": form,
        "formset": formset,
        "products": products,
        "mode": "create",
    })


@login_required
@module_required('sales')
def si_edit(request, pk):
    si = get_object_or_404(SalesInvoice, pk=pk)

    if si.is_confirmed:
        messages.error(request, "This SI is already confirmed and cannot be edited.")
        return redirect("si_detail", pk=si.pk)

    if si.is_cancelled:
        messages.error(request, "This SI has been cancelled and cannot be edited.")
        return redirect("si_detail", pk=si.pk)

    if request.method == "POST":
        form = SalesInvoiceForm(request.POST, instance=si)
        formset = SalesInvoiceItemFormSet(
            request.POST, instance=si, business_profile=request.business_profile
        )
        if form.is_valid() and formset.is_valid():
            form.save()
            formset.save()
            messages.success(request, "Sales Invoice draft updated ✅")
            return redirect(f"/si/{si.pk}/?from=create")
    else:
        form = SalesInvoiceForm(instance=si)
        formset = SalesInvoiceItemFormSet(
            instance=si, business_profile=request.business_profile
        )

    products = Product.objects.filter(
        business_profile=request.business_profile, is_archived=False
    ).order_by("name")
    return render(request, "sales/si_create.html", {
        "form": form,
        "formset": formset,
        "products": products,
        "mode": "edit",
        "invoice": si,
    })


@login_required
@module_required('sales')
def si_detail(request, pk):
    invoice = get_object_or_404(SalesInvoice, pk=pk)

    from_create = request.GET.get("from")
    from_stock_card = request.GET.get("from_stock_card")

    if from_stock_card:
        back_url = reverse("product_stock_card", args=[from_stock_card])
        back_label = "← Back to Stock Card"
    else:
        back_url = reverse("si_list")
        back_label = "← Back to Sales Invoices"

    items_with_warnings = []
    for item in invoice.items.select_related("product").all():
        item.product.refresh_from_db()
        items_with_warnings.append({
            "item": item,
            "warning": item.has_stock_warning,
            "live_stock": item.product.quantity,
        })

    return render(request, "sales/si_detail.html", {
        "invoice": invoice,
        "back_url": back_url,
        "back_label": back_label,
        "items_with_warnings": items_with_warnings,
        "any_stock_warning": any(i["warning"] for i in items_with_warnings),
    })


@login_required
@require_POST
@transaction.atomic
@module_required('sales')
def si_confirm(request, pk):
    invoice = get_object_or_404(SalesInvoice, pk=pk)

    if invoice.is_confirmed:
        messages.info(request, "This invoice is already confirmed ✅")
        return redirect("si_detail", pk=invoice.pk)

    if invoice.is_cancelled:
        messages.error(request, "This invoice has been cancelled and cannot be confirmed.")
        return redirect("si_detail", pk=invoice.pk)

    invoice.confirm()

    stock_warnings = []
    for item in invoice.items.select_related("product").all():
        item.product.refresh_from_db()
        if item.product.quantity < item.quantity_sold:
            stock_warnings.append(
                f"⚠️ {item.product_name} ({item.product_sku}): "
                f"need {item.quantity_sold}, only {item.product.quantity} in stock — order stock immediately."
            )

    if stock_warnings:
        messages.warning(request, f"Invoice #{invoice.id} confirmed 🧾 — but some items have insufficient stock:")
        for w in stock_warnings:
            messages.warning(request, w)
    else:
        messages.success(request, f"Invoice #{invoice.id} confirmed ✅ Ready to record deliveries.")

    return redirect("si_detail", pk=invoice.pk)


@login_required
@module_required('sales')
def si_fulfill(request, pk):
    invoice = get_object_or_404(SalesInvoice, pk=pk)

    if not invoice.is_confirmed:
        messages.error(request, "SI must be confirmed before deliveries can be recorded.")
        return redirect("si_detail", pk=pk)
    if invoice.is_cancelled:
        messages.error(request, "This SI has been cancelled.")
        return redirect("si_detail", pk=pk)
    if invoice.is_fulfilled:
        messages.info(request, "This SI is already fully fulfilled.")
        return redirect("si_detail", pk=pk)
    if request.method != "POST":
        return redirect("si_detail", pk=pk)

    items = invoice.items.all()
    any_delivered = False
    errors = []

    with transaction.atomic():
        for item in items:
            field_key = f"qty_fulfill_{item.pk}"
            raw = request.POST.get(field_key, "").strip()
            if not raw:
                continue
            try:
                qty = int(raw)
            except ValueError:
                errors.append(f"Invalid quantity for {item.product_name}.")
                continue
            if qty <= 0:
                continue

            remaining = item.quantity_remaining
            if qty > remaining:
                errors.append(
                    f"Cannot deliver {qty} for {item.product_name} — "
                    f"only {remaining} units still outstanding."
                )
                continue

            product = Product.objects.select_for_update().get(pk=item.product_id)
            if qty > product.quantity:
                errors.append(
                    f"Not enough stock to deliver {qty} of {item.product_name} — "
                    f"only {product.quantity} available. Order more stock first."
                )
                continue

            notes = request.POST.get(f"notes_{item.pk}", "").strip()
            SIFulfillmentRecord.objects.create(si_item=item, quantity=qty, notes=notes)
            Product.objects.filter(pk=item.product_id).update(quantity=F("quantity") - qty)
            any_delivered = True

    if errors:
        for e in errors:
            messages.error(request, e)
        if not any_delivered:
            return redirect("si_detail", pk=pk)

    if not any_delivered and not errors:
        messages.warning(request, "No quantities entered. Nothing was recorded.")
        return redirect("si_detail", pk=pk)

    from django.utils import timezone
    invoice.refresh_from_db()
    all_items = invoice.items.prefetch_related("fulfillments").all()
    fully_fulfilled = all(item.quantity_remaining == 0 for item in all_items)
    if fully_fulfilled:
        invoice.is_fulfilled = True
        invoice.fulfilled_at = timezone.now()
        invoice.save(update_fields=["is_fulfilled", "fulfilled_at"])
        messages.success(request, "Sales Invoice fully fulfilled ✅ All items delivered, stock updated 📦")
    else:
        messages.success(request, "Partial delivery recorded ✅ Stock updated for delivered items 📦")

    return redirect("si_detail", pk=pk)


@login_required
@require_POST
@module_required('sales')
def si_cancel(request, pk):
    invoice = get_object_or_404(SalesInvoice, pk=pk)
    try:
        invoice.cancel()
        messages.success(request, "Sales Invoice cancelled.")
    except ValueError as e:
        messages.error(request, str(e))
    return redirect("si_detail", pk=pk)