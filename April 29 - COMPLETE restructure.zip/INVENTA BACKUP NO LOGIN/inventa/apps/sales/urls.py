from django.urls import path
from apps.sales import views

urlpatterns = [
    path('', views.si_list, name='si_list'),
    path('new/', views.si_create, name='si_create'),
    path('<int:pk>/', views.si_detail, name='si_detail'),
    path('<int:pk>/edit/', views.si_edit, name='si_edit'),
    path('<int:pk>/confirm/', views.si_confirm, name='si_confirm'),
    path('<int:pk>/fulfill/', views.si_fulfill, name='si_fulfill'),
    path('<int:pk>/cancel/', views.si_cancel, name='si_cancel'),
]