from django import forms
from django.forms import inlineformset_factory
from apps.core.models import Product
from apps.sales.models import SalesInvoice, SalesInvoiceItem


class SalesInvoiceForm(forms.ModelForm):
    class Meta:
        model = SalesInvoice
        fields = [
            "customer_name", "customer_address",
            "business_name", "business_address",
            "business_tin", "business_contact", "business_email",
            "date", "tax_percent", "payment_terms",
            "footer_note",
        ]
        widgets = {
            "date": forms.DateInput(attrs={"type": "date"}),
        }


class SalesInvoiceItemForm(forms.ModelForm):
    class Meta:
        model = SalesInvoiceItem
        fields = ["product", "quantity_sold", "unit_price"]
        widgets = {
            "quantity_sold": forms.NumberInput(attrs={"min": 1, "placeholder": "Qty"}),
            "unit_price": forms.NumberInput(attrs={"step": "0.01", "placeholder": "0.00"}),
        }

    def __init__(self, *args, **kwargs):
        self.business_profile = kwargs.pop("business_profile", None)
        super().__init__(*args, **kwargs)
        if self.business_profile:
            self.fields["product"].queryset = Product.objects.filter(
                business_profile=self.business_profile, is_archived=False
            ).order_by("name")
        else:
            self.fields["product"].queryset = Product.objects.none()

    def clean(self):
        cleaned_data = super().clean()
        return cleaned_data


class SalesInvoiceItemFormSetBase(forms.BaseInlineFormSet):
    def __init__(self, *args, **kwargs):
        self.business_profile = kwargs.pop("business_profile", None)
        super().__init__(*args, **kwargs)

    def _construct_form(self, i, **kwargs):
        kwargs["business_profile"] = self.business_profile
        return super()._construct_form(i, **kwargs)


SalesInvoiceItemFormSet = inlineformset_factory(
    parent_model=SalesInvoice,
    model=SalesInvoiceItem,
    form=SalesInvoiceItemForm,
    formset=SalesInvoiceItemFormSetBase,
    extra=0,
    can_delete=True,
    min_num=1,
    validate_min=True,
)