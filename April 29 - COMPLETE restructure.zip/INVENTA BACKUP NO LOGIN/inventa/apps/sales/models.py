from decimal import Decimal, ROUND_HALF_UP
from django.db import models, transaction
from django.utils import timezone
from django.core.validators import MinValueValidator
from django.contrib.contenttypes.models import ContentType

from apps.core.models import Product, BusinessProfile


class SalesInvoice(models.Model):
    # Customer Info
    customer_name = models.CharField(max_length=255)
    customer_address = models.CharField(max_length=255, blank=True)

    # Business Info
    business_name = models.CharField(max_length=255)
    business_address = models.CharField(max_length=255, blank=True)
    business_tin = models.CharField(max_length=64, blank=True)
    business_contact = models.CharField(max_length=64, blank=True)
    business_email = models.CharField(max_length=255, blank=True)
    footer_note = models.CharField(
        max_length=255,
        blank=True,
        default="THIS DOCUMENT IS NOT VALID FOR CLAIMING INPUT TAX"
    )

    # Payment Terms
    payment_terms = models.CharField(max_length=255, default="COD")

    # Date
    date = models.DateField(default=timezone.now)
    due_date = models.DateField(null=True, blank=True)

    # Tax and totals
    tax_percent = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal("12.00"),
        help_text="Tax rate as a whole percent (e.g. 12.00 for 12%)"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    is_confirmed = models.BooleanField(default=False)
    confirmed_at = models.DateTimeField(null=True, blank=True)

    is_fulfilled = models.BooleanField(default=False)
    fulfilled_at = models.DateTimeField(null=True, blank=True)

    is_cancelled = models.BooleanField(default=False)
    cancelled_at = models.DateTimeField(null=True, blank=True)

    business_profile = models.ForeignKey(
        BusinessProfile,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='sales_invoices',
    )

    def __str__(self):
        return f"SI #{self.id} — {self.customer_name} ({self.date})"

    @property
    def si_number(self):
        if not self.pk:
            return ""
        return f"{self.date:%Y/%m/%d}-SI{self.pk}"

    @property
    def subtotal(self):
        return sum((item.line_total for item in self.items.all()), Decimal("0.00"))

    def tax_value(self):
        rate = self.tax_percent / Decimal("100")
        value = self.subtotal * rate
        return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    @property
    def total_with_tax(self):
        rate = self.tax_percent / Decimal("100")
        total = self.subtotal * (Decimal("1.00") + rate)
        return total.quantize(Decimal("0.01"))

    @property
    def status(self):
        if self.is_cancelled:
            return "Cancelled"
        if self.is_fulfilled:
            return "Fulfilled"
        if self.is_confirmed:
            has_fulfillments = SIFulfillmentRecord.objects.filter(
                si_item__invoice=self
            ).exists()
            if has_fulfillments:
                return "Partial"
            return "Confirmed"
        return "Draft"

    @property
    def total_quantity_ordered(self):
        return sum(item.quantity_sold for item in self.items.all())

    @property
    def total_quantity_fulfilled(self):
        return sum(
            r.quantity for r in SIFulfillmentRecord.objects.filter(si_item__invoice=self)
        )

    @transaction.atomic
    def confirm(self):
        si = SalesInvoice.objects.select_for_update().get(pk=self.pk)
        if si.is_confirmed:
            return
        si.is_confirmed = True
        si.confirmed_at = timezone.now()
        si.save(update_fields=["is_confirmed", "confirmed_at"])

    @transaction.atomic
    def cancel(self):
        si = SalesInvoice.objects.select_for_update().get(pk=self.pk)
        if si.is_fulfilled:
            raise ValueError("A fully fulfilled Sales Invoice cannot be cancelled.")
        if si.is_cancelled:
            return
        si.is_cancelled = True
        si.cancelled_at = timezone.now()
        si.save(update_fields=["is_cancelled", "cancelled_at"])

    @property
    def total_paid(self):
        from apps.accounting.models import PaymentRecord
        ct = ContentType.objects.get_for_model(self.__class__)
        return PaymentRecord.objects.filter(
            content_type=ct, object_id=self.pk
        ).aggregate(total=models.Sum("amount"))["total"] or Decimal("0.00")

    @property
    def payment_status(self):
        if not self.is_fulfilled:
            return "N/A"
        paid = self.total_paid
        today = timezone.localdate()
        if paid >= self.total_with_tax:
            return "Paid"
        if paid > 0:
            if self.due_date and self.due_date < today:
                return "Overdue"
            return "Partially Paid"
        if self.due_date and self.due_date < today:
            return "Overdue"
        return "Unpaid"

    @property
    def balance_due(self):
        return max(Decimal("0.00"), self.total_with_tax - self.total_paid)


class SalesInvoiceItem(models.Model):
    invoice = models.ForeignKey(SalesInvoice, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(Product, on_delete=models.PROTECT)

    product_sku = models.CharField(max_length=64, blank=True)
    product_name = models.CharField(max_length=255, blank=True)

    quantity_sold = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    unit_price = models.DecimalField(
        max_digits=12, decimal_places=2,
        validators=[MinValueValidator(Decimal("0.00"))]
    )
    cost_override = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="Override the avg_cost used for COGS calculation. Leave blank to use product's avg_cost.",
    )

    def __str__(self):
        return f"SI#{self.invoice_id} • {self.product_sku or self.product.sku} x {self.quantity_sold}"

    def save(self, *args, **kwargs):
        if not self.product_sku:
            self.product_sku = self.product.sku
        if not self.product_name:
            self.product_name = self.product.name
        super().save(*args, **kwargs)

    @property
    def line_total(self):
        return self.unit_price * self.quantity_sold

    @property
    def quantity_fulfilled(self):
        return sum(r.quantity for r in self.fulfillments.all())

    @property
    def quantity_remaining(self):
        return self.quantity_sold - self.quantity_fulfilled

    @property
    def has_stock_warning(self):
        return self.quantity_remaining > 0 and self.product.quantity < self.quantity_remaining

    @property
    def cogs(self):
        cost = self.cost_override if self.cost_override is not None else self.product.avg_cost
        return cost * self.quantity_sold


class SIFulfillmentRecord(models.Model):
    si_item = models.ForeignKey(
        SalesInvoiceItem, on_delete=models.CASCADE, related_name="fulfillments"
    )
    quantity = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    delivered_at = models.DateTimeField(default=timezone.now)
    notes = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return f"SI Delivery SI#{self.si_item.invoice_id} — {self.si_item.product_sku} x {self.quantity}"