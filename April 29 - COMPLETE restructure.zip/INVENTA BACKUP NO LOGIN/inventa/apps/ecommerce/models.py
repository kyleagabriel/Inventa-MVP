from decimal import Decimal, ROUND_HALF_UP
from django.db import models, transaction
from django.utils import timezone
from django.core.validators import MinValueValidator
from django.contrib.contenttypes.models import ContentType

from apps.core.models import Product, BusinessProfile


class EcommerceSale(models.Model):
    PLATFORM_CHOICES = [
        ("shopee", "Shopee"),
        ("lazada", "Lazada"),
        ("tiktok", "TikTok"),
        ("other",  "Other"),
    ]

    order_id = models.CharField(max_length=128)
    platform = models.CharField(max_length=32, choices=PLATFORM_CHOICES)
    customer_name = models.CharField(max_length=255, blank=True)
    platform_fees = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal("0.00"),
        help_text="Total platform fees in pesos (commission, payment fees, etc.)",
    )

    date = models.DateField(default=timezone.now)
    created_at = models.DateTimeField(auto_now_add=True)
    due_date = models.DateField(null=True, blank=True)

    is_confirmed = models.BooleanField(default=False)
    confirmed_at = models.DateTimeField(null=True, blank=True)

    is_fulfilled = models.BooleanField(default=False)
    fulfilled_at = models.DateTimeField(null=True, blank=True)

    is_cancelled = models.BooleanField(default=False)
    cancelled_at = models.DateTimeField(null=True, blank=True)

    business_profile = models.ForeignKey(
        BusinessProfile,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='ecommerce_sales',
    )

    class Meta:
        unique_together = ("business_profile", "order_id")

    def __str__(self):
        return f"Ecom {self.platform.upper()} — Order {self.order_id} ({self.date})"

    @property
    def subtotal(self):
        return sum((item.line_total for item in self.items.all()), Decimal("0.00"))

    @property
    def net_payout(self):
        result = self.subtotal - self.platform_fees
        return result.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    @property
    def status(self):
        if self.is_cancelled:
            return "Cancelled"
        if self.is_fulfilled:
            return "Fulfilled"
        if self.is_confirmed:
            return "Confirmed"
        return "Draft"

    @property
    def total_quantity_ordered(self):
        return sum(item.quantity_sold for item in self.items.all())

    @property
    def total_quantity_fulfilled(self):
        return sum(
            r.quantity
            for r in EcommerceFulfillmentRecord.objects.filter(ecom_item__sale=self)
        )

    @transaction.atomic
    def confirm(self):
        sale = EcommerceSale.objects.select_for_update().get(pk=self.pk)
        if sale.is_confirmed:
            return
        sale.is_confirmed = True
        sale.confirmed_at = timezone.now()
        sale.save(update_fields=["is_confirmed", "confirmed_at"])

    @transaction.atomic
    def cancel(self):
        sale = EcommerceSale.objects.select_for_update().get(pk=self.pk)
        if sale.is_fulfilled:
            raise ValueError("A fully fulfilled E-commerce Sale cannot be cancelled.")
        if sale.is_cancelled:
            return
        sale.is_cancelled = True
        sale.cancelled_at = timezone.now()
        sale.save(update_fields=["is_cancelled", "cancelled_at"])

    @property
    def total_paid(self):
        from apps.accounting.models import PaymentRecord
        ct = ContentType.objects.get_for_model(self.__class__)
        return PaymentRecord.objects.filter(
            content_type=ct, object_id=self.pk
        ).aggregate(total=models.Sum("amount"))["total"] or Decimal("0.00")

    @property
    def payment_status(self):
        if not self.is_fulfilled:
            return "N/A"
        paid = self.total_paid
        today = timezone.localdate()
        if paid >= self.net_payout:
            return "Paid"
        if paid > 0:
            if self.due_date and self.due_date < today:
                return "Overdue"
            return "Partially Paid"
        if self.due_date and self.due_date < today:
            return "Overdue"
        return "Unpaid"

    @property
    def balance_due(self):
        return max(Decimal("0.00"), self.net_payout - self.total_paid)


class EcommerceSaleItem(models.Model):
    sale = models.ForeignKey(EcommerceSale, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(Product, on_delete=models.PROTECT)

    product_sku = models.CharField(max_length=64, blank=True)
    product_name = models.CharField(max_length=255, blank=True)

    quantity_sold = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    unit_price = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.00"))],
    )
    cost_override = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        null=True,
        blank=True,
        help_text="Override the avg_cost used for COGS calculation. Leave blank to use product's avg_cost.",
    )

    def __str__(self):
        return f"Ecom#{self.sale_id} • {self.product_sku or self.product.sku} x {self.quantity_sold}"

    def save(self, *args, **kwargs):
        if not self.product_sku:
            self.product_sku = self.product.sku
        if not self.product_name:
            self.product_name = self.product.name
        super().save(*args, **kwargs)

    @property
    def line_total(self):
        return self.unit_price * self.quantity_sold

    @property
    def quantity_fulfilled(self):
        return sum(r.quantity for r in self.fulfillments.all())

    @property
    def quantity_remaining(self):
        return self.quantity_sold - self.quantity_fulfilled

    @property
    def has_stock_warning(self):
        return self.quantity_remaining > 0 and self.product.quantity < self.quantity_remaining

    @property
    def cogs(self):
        cost = self.cost_override if self.cost_override is not None else self.product.avg_cost
        return cost * self.quantity_sold


class EcommerceFulfillmentRecord(models.Model):
    ecom_item = models.ForeignKey(
        EcommerceSaleItem, on_delete=models.CASCADE, related_name="fulfillments"
    )
    quantity = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    delivered_at = models.DateTimeField(default=timezone.now)
    notes = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return f"Ecom Delivery #{self.ecom_item.sale_id} — {self.ecom_item.product_sku} x {self.quantity}"