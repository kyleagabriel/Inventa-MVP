from django.urls import path
from apps.ecommerce import views

urlpatterns = [
    path('', views.ecom_list, name='ecom_list'),
    path('new/', views.ecom_create, name='ecom_create'),
    path('<int:pk>/', views.ecom_detail, name='ecom_detail'),
    path('<int:pk>/edit/', views.ecom_edit, name='ecom_edit'),
    path('<int:pk>/confirm/', views.ecom_confirm, name='ecom_confirm'),
    path('<int:pk>/fulfill/', views.ecom_fulfill, name='ecom_fulfill'),
    path('<int:pk>/cancel/', views.ecom_cancel, name='ecom_cancel'),
]