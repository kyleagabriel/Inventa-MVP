from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.contrib import messages
from django.db import transaction
from django.db.models import F
from django.utils import timezone

from apps.core.models import Product
from apps.core.decorators import module_required
from apps.ecommerce.models import EcommerceSale, EcommerceSaleItem, EcommerceFulfillmentRecord
from apps.ecommerce.forms import EcommerceSaleForm, EcommerceSaleItemFormSet


@login_required
@module_required('ecommerce')
def ecom_list(request):
    status_filter = request.GET.get("status", "all")
    bp = request.business_profile
    sales = EcommerceSale.objects.filter(business_profile=bp).order_by("-created_at")

    ecom_ids_with_fulfillments = EcommerceFulfillmentRecord.objects.filter(
        ecom_item__sale__business_profile=bp
    ).values_list("ecom_item__sale_id", flat=True).distinct()

    if status_filter == "draft":
        sales = sales.filter(is_confirmed=False, is_cancelled=False)
    elif status_filter == "confirmed":
        confirmed = sales.filter(is_confirmed=True, is_fulfilled=False, is_cancelled=False)
        sales = confirmed.exclude(pk__in=ecom_ids_with_fulfillments)
    elif status_filter == "fulfilled":
        sales = sales.filter(is_fulfilled=True)
    elif status_filter == "cancelled":
        sales = sales.filter(is_cancelled=True)

    all_confirmed = EcommerceSale.objects.filter(
        business_profile=bp, is_confirmed=True, is_fulfilled=False, is_cancelled=False
    )
    counts = {
        "all":       EcommerceSale.objects.filter(business_profile=bp).count(),
        "draft":     EcommerceSale.objects.filter(business_profile=bp, is_confirmed=False, is_cancelled=False).count(),
        "confirmed": all_confirmed.exclude(pk__in=ecom_ids_with_fulfillments).count(),
        "fulfilled": EcommerceSale.objects.filter(business_profile=bp, is_fulfilled=True).count(),
        "cancelled": EcommerceSale.objects.filter(business_profile=bp, is_cancelled=True).count(),
    }

    return render(request, "ecommerce/ecom_list.html", {
        "sales": sales,
        "status_filter": status_filter,
        "counts": counts,
    })


@login_required
@module_required('ecommerce')
def ecom_create(request):
    if request.method == "POST":
        form = EcommerceSaleForm(
            request.POST, business_profile=request.business_profile
        )
        formset = EcommerceSaleItemFormSet(
            request.POST, business_profile=request.business_profile
        )
        if form.is_valid() and formset.is_valid():
            sale = form.save(commit=False)
            sale.business_profile = request.business_profile
            sale.is_confirmed = False
            sale.save()
            formset.instance = sale
            formset.save()
            messages.success(request, "E-commerce Sale draft created ✅ Review it and confirm when ready.")
            return redirect("ecom_detail", pk=sale.pk)
    else:
        form = EcommerceSaleForm(business_profile=request.business_profile)
        formset = EcommerceSaleItemFormSet(business_profile=request.business_profile)

    return render(request, "ecommerce/ecom_create.html", {
        "form": form,
        "formset": formset,
        "mode": "create",
        "products": Product.objects.filter(
            business_profile=request.business_profile, is_archived=False
        ).order_by("name"),
    })


@login_required
@module_required('ecommerce')
def ecom_edit(request, pk):
    sale = get_object_or_404(EcommerceSale, pk=pk)

    if sale.is_confirmed:
        messages.error(request, "This E-commerce Sale is already confirmed and cannot be edited.")
        return redirect("ecom_detail", pk=sale.pk)
    if sale.is_cancelled:
        messages.error(request, "This E-commerce Sale has been cancelled and cannot be edited.")
        return redirect("ecom_detail", pk=sale.pk)

    if request.method == "POST":
        form = EcommerceSaleForm(
            request.POST, instance=sale, business_profile=request.business_profile
        )
        formset = EcommerceSaleItemFormSet(
            request.POST, instance=sale, business_profile=request.business_profile
        )
        if form.is_valid() and formset.is_valid():
            form.save()
            formset.save()
            messages.success(request, "E-commerce Sale draft updated ✅")
            return redirect("ecom_detail", pk=sale.pk)
    else:
        form = EcommerceSaleForm(instance=sale, business_profile=request.business_profile)
        formset = EcommerceSaleItemFormSet(
            instance=sale, business_profile=request.business_profile
        )

    return render(request, "ecommerce/ecom_create.html", {
        "form": form,
        "formset": formset,
        "mode": "edit",
        "sale": sale,
        "products": Product.objects.filter(
            business_profile=request.business_profile, is_archived=False
        ).order_by("name"),
    })


@login_required
@module_required('ecommerce')
def ecom_detail(request, pk):
    sale = get_object_or_404(EcommerceSale, pk=pk)

    items_with_warnings = []
    for item in sale.items.select_related("product").all():
        item.product.refresh_from_db()
        items_with_warnings.append({
            "item": item,
            "warning": item.has_stock_warning,
            "live_stock": item.product.quantity,
        })

    return render(request, "ecommerce/ecom_detail.html", {
        "sale": sale,
        "items_with_warnings": items_with_warnings,
        "any_stock_warning": any(i["warning"] for i in items_with_warnings),
    })


@login_required
@require_POST
@transaction.atomic
@module_required('ecommerce')
def ecom_confirm(request, pk):
    sale = get_object_or_404(EcommerceSale, pk=pk)

    if sale.is_confirmed:
        messages.info(request, "This sale is already confirmed ✅")
        return redirect("ecom_detail", pk=sale.pk)
    if sale.is_cancelled:
        messages.error(request, "This sale has been cancelled and cannot be confirmed.")
        return redirect("ecom_detail", pk=sale.pk)

    sale.confirm()

    stock_warnings = []
    for item in sale.items.select_related("product").all():
        item.product.refresh_from_db()
        if item.product.quantity < item.quantity_sold:
            stock_warnings.append(
                f"⚠️ {item.product_name} ({item.product_sku}): "
                f"need {item.quantity_sold}, only {item.product.quantity} in stock."
            )

    if stock_warnings:
        messages.warning(request, f"Order {sale.order_id} confirmed 🧾 — but some items have insufficient stock:")
        for w in stock_warnings:
            messages.warning(request, w)
    else:
        messages.success(request, f"Order {sale.order_id} confirmed ✅ Ready to record fulfillment.")

    return redirect("ecom_detail", pk=sale.pk)


@login_required
@transaction.atomic
@module_required('ecommerce')
def ecom_fulfill(request, pk):
    sale = get_object_or_404(EcommerceSale, pk=pk)

    if not sale.is_confirmed:
        messages.error(request, "Sale must be confirmed before fulfillment can be recorded.")
        return redirect("ecom_detail", pk=pk)
    if sale.is_cancelled:
        messages.error(request, "This sale has been cancelled.")
        return redirect("ecom_detail", pk=pk)
    if sale.is_fulfilled:
        messages.info(request, "This sale is already fully fulfilled.")
        return redirect("ecom_detail", pk=pk)
    if request.method != "POST":
        return redirect("ecom_detail", pk=pk)

    items = list(sale.items.all())
    errors = []

    for item in items:
        product = Product.objects.select_for_update().get(pk=item.product_id)
        if item.quantity_sold > product.quantity:
            errors.append(
                f"Not enough stock for {item.product_name} — "
                f"need {item.quantity_sold}, only {product.quantity} available."
            )

    if errors:
        for e in errors:
            messages.error(request, e)
        return redirect("ecom_detail", pk=pk)

    for item in items:
        notes = request.POST.get(f"notes_{item.pk}", "").strip()
        EcommerceFulfillmentRecord.objects.create(
            ecom_item=item,
            quantity=item.quantity_sold,
            notes=notes,
        )
        Product.objects.filter(pk=item.product_id).update(
            quantity=F("quantity") - item.quantity_sold
        )

    sale.is_fulfilled = True
    sale.fulfilled_at = timezone.now()
    sale.save(update_fields=["is_fulfilled", "fulfilled_at"])
    messages.success(request, "E-commerce order fulfilled ✅ Stock updated 📦")
    return redirect("ecom_detail", pk=pk)


@login_required
@require_POST
@module_required('ecommerce')
def ecom_cancel(request, pk):
    sale = get_object_or_404(EcommerceSale, pk=pk)
    try:
        sale.cancel()
        messages.success(request, "E-commerce Sale cancelled.")
    except ValueError as e:
        messages.error(request, str(e))
    return redirect("ecom_detail", pk=pk)