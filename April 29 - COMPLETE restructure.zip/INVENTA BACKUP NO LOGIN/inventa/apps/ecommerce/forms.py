from django import forms
from django.forms import inlineformset_factory
from apps.core.models import Product
from apps.ecommerce.models import EcommerceSale, EcommerceSaleItem


class EcommerceSaleForm(forms.ModelForm):
    class Meta:
        model = EcommerceSale
        fields = [
            "order_id", "platform", "customer_name",
            "date", "platform_fees",
        ]
        widgets = {
            "order_id": forms.TextInput(attrs={
                "placeholder": "Paste Order ID from platform (e.g. 250313ABCXYZ)",
            }),
            "platform": forms.Select(),
            "customer_name": forms.TextInput(attrs={
                "placeholder": "Customer name (optional)",
            }),
            "date": forms.DateInput(attrs={
                "type": "date",
            }),
            "platform_fees": forms.NumberInput(attrs={
                "step": "0.01",
                "min": "0",
                "placeholder": "0.00",
            }),
        }

    def __init__(self, *args, **kwargs):
        self.business_profile = kwargs.pop("business_profile", None)
        self.instance_pk = kwargs.get("instance") and kwargs["instance"].pk
        super().__init__(*args, **kwargs)

    def clean_order_id(self):
        order_id = self.cleaned_data.get("order_id", "").strip()
        if self.business_profile:
            qs = EcommerceSale.objects.filter(
                business_profile=self.business_profile,
                order_id=order_id
            )
        else:
            qs = EcommerceSale.objects.filter(order_id=order_id)
        if self.instance_pk:
            qs = qs.exclude(pk=self.instance_pk)
        if qs.exists():
            raise forms.ValidationError(
                f'Order ID "{order_id}" already exists. Please check for duplicates.'
            )
        return order_id


class EcommerceSaleItemForm(forms.ModelForm):
    class Meta:
        model = EcommerceSaleItem
        fields = ["product", "quantity_sold", "unit_price"]
        widgets = {
            "quantity_sold": forms.NumberInput(attrs={"min": 1, "placeholder": "Qty"}),
            "unit_price": forms.NumberInput(attrs={"step": "0.01", "placeholder": "0.00"}),
        }

    def __init__(self, *args, **kwargs):
        self.business_profile = kwargs.pop("business_profile", None)
        super().__init__(*args, **kwargs)
        if self.business_profile:
            self.fields["product"].queryset = Product.objects.filter(
                business_profile=self.business_profile, is_archived=False
            ).order_by("name")
        else:
            self.fields["product"].queryset = Product.objects.none()


class EcommerceSaleItemFormSetBase(forms.BaseInlineFormSet):
    def __init__(self, *args, **kwargs):
        self.business_profile = kwargs.pop("business_profile", None)
        super().__init__(*args, **kwargs)

    def _construct_form(self, i, **kwargs):
        kwargs["business_profile"] = self.business_profile
        return super()._construct_form(i, **kwargs)


EcommerceSaleItemFormSet = inlineformset_factory(
    parent_model=EcommerceSale,
    model=EcommerceSaleItem,
    form=EcommerceSaleItemForm,
    formset=EcommerceSaleItemFormSetBase,
    extra=0,
    can_delete=True,
    min_num=1,
    validate_min=True,
)