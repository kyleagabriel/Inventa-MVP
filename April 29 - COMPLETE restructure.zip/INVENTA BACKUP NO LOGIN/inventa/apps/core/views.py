from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.urls import reverse
from django.views.decorators.http import require_POST
from django.db.models import Sum, ExpressionWrapper, DecimalField, F
from django.utils import timezone

from apps.core.models import BusinessProfile, Role, ModulePermission, Membership
from apps.core.forms import BusinessProfileForm
from apps.core.decorators import module_required, owner_required


MODULE_CHOICES_LIST = [
    ("dashboard",    "Dashboard"),
    ("inventory",    "Inventory"),
    ("sales",        "Sales Invoice"),
    ("procurement",  "Purchase Order"),
    ("ecommerce",    "E-commerce Sales"),
    ("accounting",   "Accounting"),
    ("intelligence", "Inventory Intel"),
    ("settings",     "Business Profile & Settings"),
]

# ─────────────────────────────────────────────
#  DASHBOARD
# ─────────────────────────────────────────────

@login_required
@module_required('dashboard')
def dashboard(request):
    from apps.sales.models import SalesInvoice, SalesInvoiceItem
    from apps.procurement.models import PurchaseOrder
    from apps.core.models import Product
    from apps.intelligence.analytics import build_product_demand_profile

    today = timezone.localdate()

    todays_invoices = SalesInvoice.objects.filter(
        business_profile=request.business_profile,
        date=today,
        is_confirmed=True
    )
    total_sales_today = sum(inv.subtotal for inv in todays_invoices)
    invoice_count_today = todays_invoices.count()

    top_products = (
        SalesInvoiceItem.objects
        .filter(
            invoice__business_profile=request.business_profile,
            invoice__date=today,
            invoice__is_confirmed=True
        )
        .values('product__name', 'product__sku', 'product_id')
        .annotate(
            total_revenue=Sum(
                ExpressionWrapper(
                    F('quantity_sold') * F('unit_price'),
                    output_field=DecimalField()
                )
            )
        )
        .order_by('-total_revenue')[:5]
    )

    low_stock_products = []
    products = Product.objects.filter(
        business_profile=request.business_profile,
        is_archived=False
    )
    for product in products:
        profile = build_product_demand_profile(product)
        if product.quantity < profile['reorder_point']:
            low_stock_products.append({
                'product': product,
                'current_stock': product.quantity,
                'reorder_point': profile['reorder_point'],
                'recommended_order': profile['recommended_order_qty'],
            })
    low_stock_products.sort(key=lambda x: x['current_stock'])
    low_stock_products = low_stock_products[:10]

    pending_pos = PurchaseOrder.objects.filter(
        business_profile=request.business_profile,
        is_confirmed=True,
        is_fulfilled=False,
        is_cancelled=False
    ).count()

    pending_deliveries = SalesInvoice.objects.filter(
        business_profile=request.business_profile,
        is_confirmed=True,
        is_fulfilled=False,
        is_cancelled=False
    ).count()

    pending_delivery_invoices = SalesInvoice.objects.filter(
        business_profile=request.business_profile,
        is_confirmed=True,
        is_fulfilled=False,
        is_cancelled=False
    ).order_by('-created_at')[:10]

    pending_pos_list = PurchaseOrder.objects.filter(
        business_profile=request.business_profile,
        is_confirmed=True,
        is_fulfilled=False,
        is_cancelled=False
    ).order_by('-created_at')[:10]

    return render(request, 'core/dashboard.html', {
        'total_sales_today': total_sales_today,
        'invoice_count_today': invoice_count_today,
        'top_products': top_products,
        'low_stock_products': low_stock_products,
        'pending_pos': pending_pos,
        'pending_deliveries': pending_deliveries,
        'pending_delivery_invoices': pending_delivery_invoices,
        'pending_pos_list': pending_pos_list,
        'today': today,
    })

# ─────────────────────────────────────────────
#  AUTHENTICATION VIEWS
# ─────────────────────────────────────────────

def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '')
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            next_url = request.GET.get('next')
            if next_url:
                return redirect(next_url)

            try:
                membership = Membership.objects.select_related('role').get(user=user)
                from apps.core.decorators import get_first_accessible_url
                fallback = get_first_accessible_url(membership)
                return redirect(fallback)
            except Membership.DoesNotExist:
                return redirect('dashboard')
        else:
            messages.error(request, 'Invalid username or password.')

    return render(request, 'core/login.html')


def logout_view(request):
    logout(request)
    return redirect('login')


def no_access_view(request):
    return render(request, 'core/no_access.html')


# ─────────────────────────────────────────────
#  SETTINGS & TEAM MANAGEMENT VIEWS
# ─────────────────────────────────────────────

@login_required
@module_required('settings')
def settings_view(request):
    profile = request.business_profile
    membership = request.membership
    active_tab = request.GET.get('tab', 'profile')

    if active_tab == 'team' and membership and not membership.is_owner:
        active_tab = 'profile'

    if request.method == 'POST' and 'save_profile' in request.POST:
        form = BusinessProfileForm(request.POST, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, "Business profile saved ✅")
            return redirect(f"{reverse('settings')}?tab=profile")
    else:
        form = BusinessProfileForm(instance=profile)

    memberships = []
    if membership and membership.is_owner:
        memberships = (
            Membership.objects
            .filter(business_profile=profile)
            .select_related('user', 'role')
            .prefetch_related('role__module_permissions')
            .order_by('joined_at')
        )

    context = {
        'form': form,
        'profile': profile,
        'active_tab': active_tab,
        'memberships': memberships,
        'is_owner': membership.is_owner if membership else False,
        'module_choices': MODULE_CHOICES_LIST,
    }
    return render(request, 'core/settings.html', context)


@login_required
@module_required('settings')
@owner_required
def team_member_create(request):
    if request.method != 'POST':
        return redirect(f"{reverse('settings')}?tab=team")

    profile = request.business_profile
    username = request.POST.get('username', '').strip()
    password = request.POST.get('password', '').strip()
    modules = request.POST.getlist('modules')

    errors = []
    if not username:
        errors.append("Username is required.")
    if not password:
        errors.append("Password is required.")
    if len(password) < 8:
        errors.append("Password must be at least 8 characters.")
    if User.objects.filter(username=username).exists():
        errors.append(f"Username '{username}' is already taken.")

    if errors:
        for e in errors:
            messages.error(request, e)
        return redirect(f"{reverse('settings')}?tab=team")

    user = User.objects.create_user(username=username, password=password)

    role = Role.objects.create(
        business_profile=profile,
        name=f"_{username}",
        is_owner_role=False,
    )

    for module_key, _ in MODULE_CHOICES_LIST:
        ModulePermission.objects.create(
            role=role,
            module=module_key,
            can_access=(module_key in modules),
        )

    Membership.objects.create(
        user=user,
        business_profile=profile,
        role=role,
    )

    messages.success(request, f"Team member '{username}' created successfully ✅")
    return redirect(f"{reverse('settings')}?tab=team")


@login_required
@module_required('settings')
@owner_required
def team_member_edit(request, pk):
    if request.method != 'POST':
        return redirect(f"{reverse('settings')}?tab=team")

    membership = get_object_or_404(
        Membership,
        pk=pk,
        business_profile=request.business_profile
    )

    if membership.is_owner:
        messages.error(request, "The Owner's permissions cannot be modified.")
        return redirect(f"{reverse('settings')}?tab=team")

    modules = request.POST.getlist('modules')

    for module_key, _ in MODULE_CHOICES_LIST:
        ModulePermission.objects.update_or_create(
            role=membership.role,
            module=module_key,
            defaults={'can_access': (module_key in modules)},
        )

    messages.success(
        request,
        f"Permissions updated for '{membership.user.username}' ✅"
    )
    return redirect(f"{reverse('settings')}?tab=team")


@login_required
@module_required('settings')
@owner_required
def team_member_toggle_active(request, pk):
    if request.method != 'POST':
        return redirect(f"{reverse('settings')}?tab=team")

    membership = get_object_or_404(
        Membership,
        pk=pk,
        business_profile=request.business_profile
    )

    if membership.is_owner:
        messages.error(request, "The Owner account cannot be deactivated.")
        return redirect(f"{reverse('settings')}?tab=team")

    user = membership.user
    user.is_active = not user.is_active
    user.save(update_fields=['is_active'])

    status = "activated" if user.is_active else "deactivated"
    messages.success(request, f"'{user.username}' has been {status} ✅")
    return redirect(f"{reverse('settings')}?tab=team")


@login_required
@module_required('settings')
@owner_required
def team_member_reset_password(request, pk):
    if request.method != 'POST':
        return redirect(f"{reverse('settings')}?tab=team")

    membership = get_object_or_404(
        Membership,
        pk=pk,
        business_profile=request.business_profile
    )

    if membership.is_owner:
        messages.error(request, "Use the Django admin to change the Owner's password.")
        return redirect(f"{reverse('settings')}?tab=team")

    new_password = request.POST.get('new_password', '').strip()

    if not new_password:
        messages.error(request, "Password cannot be empty.")
        return redirect(f"{reverse('settings')}?tab=team")

    if len(new_password) < 8:
        messages.error(request, "Password must be at least 8 characters.")
        return redirect(f"{reverse('settings')}?tab=team")

    membership.user.set_password(new_password)
    membership.user.save()

    messages.success(
        request,
        f"Password for '{membership.user.username}' has been reset ✅"
    )
    return redirect(f"{reverse('settings')}?tab=team")