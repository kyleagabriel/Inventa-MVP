from decimal import Decimal
from django.db import models
from django.utils import timezone
from django.core.validators import RegexValidator
from django.contrib.auth.models import User


# ─────────────────────────────────────────────
#  BUSINESS PROFILE
# ─────────────────────────────────────────────

class BusinessProfile(models.Model):
    business_name = models.CharField(max_length=255)
    address = models.CharField(max_length=255)
    tin = models.CharField(
        max_length=15,
        verbose_name="TIN #",
        validators=[
            RegexValidator(
                regex=r"^[0-9\-]+$",
                message="TIN should contain only numbers and dashes."
            )
        ],
        blank=True,
        default="",
    )
    deadstock_threshold_days = models.PositiveIntegerField(
        default=30,
        help_text="Number of days with no sales before a product is considered deadstock.",
    )
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.business_name


# ─────────────────────────────────────────────
#  CATEGORY
# ─────────────────────────────────────────────

class Category(models.Model):
    COLOR_CHOICES = [
        ("cat-orange", "Orange"),
        ("cat-purple", "Purple"),
        ("cat-blue",   "Blue"),
        ("cat-green",  "Green"),
        ("cat-red",    "Red"),
        ("cat-teal",   "Teal"),
        ("cat-pink",   "Pink"),
        ("cat-yellow", "Yellow"),
    ]

    name = models.CharField(max_length=100)
    color = models.CharField(
        max_length=20,
        choices=COLOR_CHOICES,
        default="cat-orange",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    business_profile = models.ForeignKey(
        BusinessProfile,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='categories',
    )

    def __str__(self):
        return self.name

    class Meta:
        verbose_name_plural = "Categories"
        ordering = ["name"]
        unique_together = ("business_profile", "name")


# ─────────────────────────────────────────────
#  PRODUCT
# ─────────────────────────────────────────────

class Product(models.Model):
    sku = models.CharField(max_length=64)
    name = models.CharField(max_length=255)
    quantity = models.IntegerField(default=0)
    category = models.ForeignKey(
        Category,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="products",
    )
    selling_price = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        null=True,
        blank=True,
    )
    avg_cost = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal("0.00"),
        help_text="Weighted average cost per unit. Auto-updated when stock is received.",
    )
    is_archived = models.BooleanField(default=False)
    business_profile = models.ForeignKey(
        BusinessProfile,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='products',
    )

    class Meta:
        unique_together = ("business_profile", "sku")

    def __str__(self):
        return f"{self.sku} — {self.name}"


# ─────────────────────────────────────────────
#  AUTHENTICATION & MULTI-TENANCY MODELS
# ─────────────────────────────────────────────

MODULE_CHOICES = [
    ("dashboard",    "Dashboard"),
    ("inventory",    "Inventory"),
    ("sales",        "Sales Invoice"),
    ("procurement",  "Purchase Order"),
    ("ecommerce",    "E-commerce Sales"),
    ("accounting",   "Accounting"),
    ("intelligence", "Inventory Intel"),
    ("settings",     "Business Profile & Settings"),
]


class Role(models.Model):
    business_profile = models.ForeignKey(
        BusinessProfile,
        on_delete=models.CASCADE,
        related_name="roles",
    )
    name = models.CharField(max_length=100)
    is_owner_role = models.BooleanField(
        default=False,
        help_text="Protected. Auto-created for the first user. Cannot be deleted or edited."
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("business_profile", "name")
        ordering = ["name"]

    def __str__(self):
        return f"{self.name} @ {self.business_profile.business_name}"


class ModulePermission(models.Model):
    role = models.ForeignKey(
        Role,
        on_delete=models.CASCADE,
        related_name="module_permissions",
    )
    module = models.CharField(max_length=50, choices=MODULE_CHOICES)
    can_access = models.BooleanField(default=False)

    class Meta:
        unique_together = ("role", "module")
        ordering = ["module"]

    def __str__(self):
        status = "✓" if self.can_access else "✗"
        return f"{self.role.name} — {self.module} {status}"


class Membership(models.Model):
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name="membership",
    )
    business_profile = models.ForeignKey(
        BusinessProfile,
        on_delete=models.CASCADE,
        related_name="memberships",
    )
    role = models.ForeignKey(
        Role,
        on_delete=models.PROTECT,
        related_name="memberships",
    )
    joined_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} → {self.business_profile.business_name} ({self.role.name})"

    @property
    def is_owner(self):
        return self.role.is_owner_role

    def can_access(self, module: str) -> bool:
        if self.is_owner:
            return True
        return self.role.module_permissions.filter(
            module=module, can_access=True
        ).exists()

    @property
    def display_role_name(self):
        name = self.role.name
        if name.startswith('_'):
            return name[1:]
        return name