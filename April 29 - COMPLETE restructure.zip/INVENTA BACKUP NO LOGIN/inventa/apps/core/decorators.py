from functools import wraps
from django.shortcuts import redirect
from django.contrib import messages

MODULE_REDIRECT_PRIORITY = [
    ("dashboard",    "dashboard"),
    ("inventory",    "product_list"),
    ("sales",        "si_list"),
    ("procurement",  "po_list"),
    ("ecommerce",    "ecom_list"),
    ("accounting",   "accounting_pl"),
    ("intelligence", "inventory_intel"),
    ("settings",     "settings"),
]

MODULE_DISPLAY_NAMES = {
    "dashboard":    "Dashboard",
    "inventory":    "Inventory",
    "sales":        "Sales Invoice",
    "procurement":  "Purchase Order",
    "ecommerce":    "E-commerce Sales",
    "accounting":   "Accounting",
    "intelligence": "Inventory Intel",
    "settings":     "Business Profile & Settings",
}


def get_first_accessible_url(membership):
    for module_key, url_name in MODULE_REDIRECT_PRIORITY:
        if membership.can_access(module_key):
            return url_name
    return "no_access"


def module_required(module_key):
    def decorator(view_func):
        @wraps(view_func)
        def wrapper(request, *args, **kwargs):
            membership = getattr(request, 'membership', None)

            if membership is None:
                return view_func(request, *args, **kwargs)

            if membership.can_access(module_key):
                return view_func(request, *args, **kwargs)

            module_name = MODULE_DISPLAY_NAMES.get(module_key, module_key)
            messages.error(
                request,
                f"You don't have access to {module_name}. "
                f"Contact your account Owner to request access."
            )
            fallback = get_first_accessible_url(membership)
            return redirect(fallback)

        return wrapper
    return decorator


def any_module_required(*module_keys):
    def decorator(view_func):
        @wraps(view_func)
        def wrapper(request, *args, **kwargs):
            membership = getattr(request, 'membership', None)

            if membership is None:
                return view_func(request, *args, **kwargs)

            if any(membership.can_access(m) for m in module_keys):
                return view_func(request, *args, **kwargs)

            messages.error(
                request,
                f"You don't have access to this feature. "
                f"Contact your account Owner to request access."
            )
            fallback = get_first_accessible_url(membership)
            return redirect(fallback)

        return wrapper
    return decorator


def owner_required(view_func):
    """
    Blocks non-Owner users from accessing Owner-only views.
    Must be used after @login_required and @module_required.
    """
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        membership = getattr(request, 'membership', None)

        if membership is None:
            return view_func(request, *args, **kwargs)

        if membership.is_owner:
            return view_func(request, *args, **kwargs)

        messages.error(request, "This area is restricted to the account Owner.")
        return redirect('settings')

    return wrapper