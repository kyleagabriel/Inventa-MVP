from django import forms
from apps.core.models import Product, BusinessProfile, Category


class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ["sku", "name", "quantity", "selling_price", "category"]
        widgets = {
            "sku": forms.TextInput(attrs={"placeholder": "Enter SKU"}),
            "name": forms.TextInput(attrs={"placeholder": "Enter product name"}),
            "quantity": forms.NumberInput(
                attrs={
                    "min": 0,
                    "step": 1,
                    "placeholder": "Enter quantity (e.g. 25)",
                }
            ),
            "selling_price": forms.NumberInput(
                attrs={
                    "min": 0,
                    "step": "0.01",
                    "placeholder": "Selling price (e.g. 2499.00)",
                }
            ),
            "category": forms.HiddenInput(),
        }

    def __init__(self, *args, **kwargs):
        self.business_profile = kwargs.pop("business_profile", None)
        super().__init__(*args, **kwargs)
        if not self.instance.pk and not self.is_bound:
            self.fields["quantity"].initial = ""
        self.fields["category"].required = False

    def clean_sku(self):
        sku = self.cleaned_data.get("sku", "").strip()
        if self.business_profile:
            qs = Product.objects.filter(
                business_profile=self.business_profile,
                sku=sku
            )
            if self.instance.pk:
                qs = qs.exclude(pk=self.instance.pk)
            if qs.exists():
                raise forms.ValidationError("A product with this SKU already exists.")
        return sku


class ProductPriceForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ["selling_price"]
        widgets = {
            "selling_price": forms.NumberInput(attrs={
                "step": "0.01",
                "min": "0",
                "class": "price-input",
                "placeholder": "0.00",
            })
        }


class BusinessProfileForm(forms.ModelForm):
    class Meta:
        model = BusinessProfile
        fields = ["business_name", "address", "tin"]