from django.urls import path
from apps.core import views

urlpatterns = [
    path('dashboard/', views.dashboard, name='dashboard'),
    path('settings/', views.settings_view, name='settings'),
    path('team/create/', views.team_member_create, name='team_member_create'),
    path('team/<int:pk>/edit/', views.team_member_edit, name='team_member_edit'),
    path('team/<int:pk>/toggle-active/', views.team_member_toggle_active, name='team_member_toggle_active'),
    path('team/<int:pk>/reset-password/', views.team_member_reset_password, name='team_member_reset_password'),
    path('no-access/', views.no_access_view, name='no_access'),
]