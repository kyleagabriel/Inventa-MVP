from django.urls import path
from . import views

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("products/", views.product_list, name="product_list"),
    path("api/products/search/", views.product_search_api, name="product_search_api"),
    path("products/add/", views.add_product, name="add_product"),
    path("products/quick-add/", views.add_product_quick, name="add_product_quick"),
    path("products/<int:pk>/delete/", views.delete_product, name="delete_product"),

     # 🆕 Stock card per product
    path("products/<int:pk>/stock-card/", views.product_stock_card, name="product_stock_card"),

    path("po/new/", views.po_create, name="po_create"),
    path("po/<int:pk>/", views.po_detail, name="po_detail"),
    path("po/<int:pk>/edit/", views.po_edit, name="po_edit"),
    path("po/", views.po_list, name="po_list"),
    path("po/<int:pk>/confirm/", views.po_confirm, name="po_confirm"),
    path("po/<int:pk>/fulfill/", views.po_fulfill, name="po_fulfill"),
    path("po/<int:pk>/cancel/", views.po_cancel, name="po_cancel"),

    # Sales Invoices
    path("si/", views.si_list, name="si_list"),
    path("si/new/", views.si_create, name="si_create"),
    path("si/<int:pk>/", views.si_detail, name="si_detail"),
    path("si/<int:pk>/edit/", views.si_edit, name="si_edit"),
    path("si/<int:pk>/confirm/", views.si_confirm, name="si_confirm"),
    path("si/<int:pk>/fulfill/", views.si_fulfill, name="si_fulfill"),
    path("si/<int:pk>/cancel/", views.si_cancel, name="si_cancel"),
    
    path("products/<int:pk>/archive/", views.archive_product, name="archive_product"), 
    path("products/archived/", views.archived_product_list, name="archived_products"),
    path("products/<int:pk>/unarchive/", views.unarchive_product, name="unarchive_product"),

    path("analytics/inventory/", views.inventory_intel, name="inventory_intel"),

    path("profile/", views.business_profile, name="business_profile"),

    ]
