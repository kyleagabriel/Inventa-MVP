from decimal import Decimal, ROUND_HALF_UP
from django.db import models, transaction
from django.utils import timezone
from django.core.validators import MinValueValidator, RegexValidator
from django.db.models import F

# Create your models here.
class Product(models.Model):
    sku = models.CharField(max_length=64, unique=True)
    name = models.CharField(max_length=255)
    quantity = models.IntegerField(default=0)
    selling_price = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        null=True,
        blank=True,
    )
    avg_cost = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal("0.00"),
        help_text="Weighted average cost per unit. Auto-updated when stock is received.",
    )
    is_archived = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.sku} — {self.name}"
    
class PurchaseOrder(models.Model):
    # Supplier Info
    supplier_name = models.CharField(max_length=255)
    supplier_address = models.CharField(max_length=255, blank=True)

    # Business Info
    business_name = models.CharField(max_length=255)
    business_address = models.CharField(max_length=255, blank=True)

    business_tin = models.CharField(max_length=64, blank=True)
    business_contact = models.CharField(max_length=64, blank=True)
    business_email = models.CharField(max_length=255, blank=True)
    footer_note = models.CharField(
        max_length=255,
        blank=True,
        default="THIS DOCUMENT IS NOT VALID FOR CLAIMING INPUT TAX"
    )


    # Payment Terms
    payment_terms = models.CharField(max_length=255, default="COD")

    # Date
    date = models.DateField(default=timezone.now)

    # Tax and totals
    tax_percent = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal("12.00"),
        help_text="Tax rate as a whole percent (e.g., 12.00 for 12%)"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    is_confirmed = models.BooleanField(default=False)
    confirmed_at = models.DateTimeField(null=True, blank=True)
    
    is_fulfilled = models.BooleanField(default=False)
    fulfilled_at = models.DateTimeField(null=True, blank=True)

    is_cancelled = models.BooleanField(default=False)
    cancelled_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"PO #{self.id} — {self.supplier_name} ({self.date})"

    # ---------- COMPUTED FIELDS ----------
    @property
    def po_number(self):
        if not self.pk:
            return ""
        return f"{self.date:%Y/%m/%d}-PO{self.pk}"


    @property
    def subtotal(self):
        # Sum of all line totals (unit_price × qty)
        return sum((item.line_total for item in self.items.all()), Decimal("0.00"))

    @property
    def total_order_price(self):
        return self.subtotal

    def tax_value(self):
        # Convert tax_amount (12) → 0.12
        rate = self.tax_percent / Decimal("100")
        value = self.subtotal * rate
        return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    @property
    def total_with_tax(self):
        rate = self.tax_percent / Decimal("100")  # convert to 0.12
        total = self.subtotal * (Decimal("1.00") + rate)
        return total.quantize(Decimal("0.01"))

    @property
    def status(self):
        if self.is_cancelled:
            return "Cancelled"
        if self.is_fulfilled:
            return "Fulfilled"
        if self.is_confirmed:
            return "Confirmed"
        return "Draft"

    @property
    def total_quantity_ordered(self):
        return sum(item.quantity_received for item in self.items.all())

    @property
    def total_quantity_fulfilled(self):
        return sum(r.quantity for r in FulfillmentRecord.objects.filter(po_item__po=self))

    @transaction.atomic
    def confirm_and_increase_stock(self):
        """Confirm PO — marks it as sent to supplier. Stock does NOT change here."""
        po = PurchaseOrder.objects.select_for_update().get(pk=self.pk)
        if po.is_confirmed:
            return
        po.is_confirmed = True
        po.confirmed_at = timezone.now()
        po.save(update_fields=["is_confirmed", "confirmed_at"])

    @transaction.atomic
    def cancel(self):
        """Cancel PO. Cannot cancel if already fully fulfilled."""
        po = PurchaseOrder.objects.select_for_update().get(pk=self.pk)
        if po.is_fulfilled:
            raise ValueError("A fully fulfilled PO cannot be cancelled.")
        if po.is_cancelled:
            return
        po.is_cancelled = True
        po.cancelled_at = timezone.now()
        po.save(update_fields=["is_cancelled", "cancelled_at"])


class PurchaseOrderItem(models.Model):
    # Link to Purchase Order
    po = models.ForeignKey(PurchaseOrder, on_delete=models.CASCADE, related_name="items")

    # 🔗 Link to Product
    product = models.ForeignKey(Product, on_delete=models.PROTECT)

    # Snapshot fields (keep historical name/SKU for printing)
    product_sku = models.CharField(max_length=64, blank=True)
    product_name = models.CharField(max_length=255, blank=True)

    # Order details
    quantity_received = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    unit_price = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(Decimal("0.00"))])

    def __str__(self):
        return f"PO#{self.po_id} • {self.product_sku or self.product.sku} x {self.quantity_received}"

    def save(self, *args, **kwargs):
        # Automatically copy product SKU and name for recordkeeping
        if not self.product_sku:
            self.product_sku = self.product.sku
        if not self.product_name:
            self.product_name = self.product.name
        super().save(*args, **kwargs)

    @property
    def line_total(self):
        # Total price per product
        return self.unit_price * self.quantity_received

    @property
    def quantity_fulfilled(self):
        return sum(r.quantity for r in self.fulfillments.all())

    @property
    def quantity_remaining(self):
        return self.quantity_received - self.quantity_fulfilled


class FulfillmentRecord(models.Model):
    """Tracks partial or full receipt of a PurchaseOrderItem."""
    po_item = models.ForeignKey(
        PurchaseOrderItem, on_delete=models.CASCADE, related_name="fulfillments"
    )
    quantity = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    received_at = models.DateTimeField(default=timezone.now)
    notes = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return f"Fulfillment of PO#{self.po_item.po_id} — {self.po_item.product_sku} x {self.quantity}"
    
class SalesInvoice(models.Model):
    # Customer Info
    customer_name = models.CharField(max_length=255)
    customer_address = models.CharField(max_length=255, blank=True)

    # Business Info (your business)
    business_name = models.CharField(max_length=255)
    business_address = models.CharField(max_length=255, blank=True)

    business_tin = models.CharField(max_length=64, blank=True)
    business_contact = models.CharField(max_length=64, blank=True)
    business_email = models.CharField(max_length=255, blank=True)
    footer_note = models.CharField(max_length=255, blank=True, default="THIS DOCUMENT IS NOT VALID FOR CLAIMING INPUT TAX")

    # Payment Terms
    payment_terms = models.CharField(max_length=255, default="COD")

    # Date
    date = models.DateField(default=timezone.now)

    # Tax and totals
    tax_percent = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal("12.00"),
        help_text="Tax rate as a whole percent (e.g. 12.00 for 12%)"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    is_confirmed = models.BooleanField(default=False)
    confirmed_at = models.DateTimeField(null=True, blank=True)

    is_fulfilled = models.BooleanField(default=False)
    fulfilled_at = models.DateTimeField(null=True, blank=True)

    is_cancelled = models.BooleanField(default=False)
    cancelled_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"SI #{self.id} — {self.customer_name} ({self.date})"

    # ---------- COMPUTED FIELDS ----------
    @property
    def si_number(self):
        if not self.pk:
            return ""
        return f"{self.date:%Y/%m/%d}-SI{self.pk}"


    @property
    def subtotal(self):
        return sum((item.line_total for item in self.items.all()), Decimal("0.00"))

    def tax_value(self):
        rate = self.tax_percent / Decimal("100")
        value = self.subtotal * rate
        return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    @property
    def total_with_tax(self):
        rate = self.tax_percent / Decimal("100")
        total = self.subtotal * (Decimal("1.00") + rate)
        return total.quantize(Decimal("0.01"))

    @property
    def status(self):
        if self.is_cancelled:
            return "Cancelled"
        if self.is_fulfilled:
            return "Fulfilled"
        if self.is_confirmed:
            has_fulfillments = SIFulfillmentRecord.objects.filter(si_item__invoice=self).exists()
            if has_fulfillments:
                return "Partial"
            return "Confirmed"
        return "Draft"

    @property
    def total_quantity_ordered(self):
        return sum(item.quantity_sold for item in self.items.all())

    @property
    def total_quantity_fulfilled(self):
        return sum(r.quantity for r in SIFulfillmentRecord.objects.filter(si_item__invoice=self))

    @transaction.atomic
    def confirm(self):
        """
        Confirm the SI — locks editing and commits it to the customer.
        Stock is NOT deducted here. Deduction happens per fulfillment record.
        Allowed even if stock is insufficient (lead-time use case).
        """
        si = SalesInvoice.objects.select_for_update().get(pk=self.pk)
        if si.is_confirmed:
            return
        si.is_confirmed = True
        si.confirmed_at = timezone.now()
        si.save(update_fields=["is_confirmed", "confirmed_at"])

    @transaction.atomic
    def cancel(self):
        """
        Cancel the SI. Cannot cancel a fully fulfilled SI.
        Stock already deducted through partial fulfillments stays deducted.
        """
        si = SalesInvoice.objects.select_for_update().get(pk=self.pk)
        if si.is_fulfilled:
            raise ValueError("A fully fulfilled Sales Invoice cannot be cancelled.")
        if si.is_cancelled:
            return
        si.is_cancelled = True
        si.cancelled_at = timezone.now()
        si.save(update_fields=["is_cancelled", "cancelled_at"])


class SalesInvoiceItem(models.Model):
    # Link to Sales Invoice
    invoice = models.ForeignKey(SalesInvoice, on_delete=models.CASCADE, related_name="items")

    # 🔗 Link to Product
    product = models.ForeignKey(Product, on_delete=models.PROTECT)

    # Snapshot fields
    product_sku = models.CharField(max_length=64, blank=True)
    product_name = models.CharField(max_length=255, blank=True)

    # Details
    quantity_sold = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    unit_price = models.DecimalField(
        max_digits=12, decimal_places=2,
        validators=[MinValueValidator(Decimal("0.00"))]
    )


    def __str__(self):
        return f"SI#{self.invoice_id} • {self.product_sku or self.product.sku} x {self.quantity_sold}"

    def save(self, *args, **kwargs):
        if not self.product_sku:
            self.product_sku = self.product.sku
        if not self.product_name:
            self.product_name = self.product.name
        super().save(*args, **kwargs)

    @property
    def line_total(self):
        return self.unit_price * self.quantity_sold

    @property
    def quantity_fulfilled(self):
        """Units already delivered to the customer for this line item."""
        return sum(r.quantity for r in self.fulfillments.all())

    @property
    def quantity_remaining(self):
        """Units still owed to the customer."""
        return self.quantity_sold - self.quantity_fulfilled

    @property
    def has_stock_warning(self):
        """True if we cannot currently fulfill the remaining quantity."""
        return self.quantity_remaining > 0 and self.product.quantity < self.quantity_remaining

class SIFulfillmentRecord(models.Model):
    """
    Tracks partial or full delivery of a SalesInvoiceItem to the customer.
    Each record = one physical delivery batch.
    Stock is deducted from the product when each record is created.
    """
    si_item = models.ForeignKey(
        SalesInvoiceItem, on_delete=models.CASCADE, related_name="fulfillments"
    )
    quantity = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    delivered_at = models.DateTimeField(default=timezone.now)
    notes = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return f"SI Delivery SI#{self.si_item.invoice_id} — {self.si_item.product_sku} x {self.quantity}"

class BusinessProfile(models.Model):
    business_name = models.CharField(max_length=255)
    address = models.CharField(max_length=255)

    tin = models.CharField(
        max_length=15,
        verbose_name="TIN #",
        validators=[
            RegexValidator(
                regex=r"^[0-9\-]+$",
                message="TIN should contain only numbers and dashes."
            )
        ],
        blank=True,
        default="",
    )

    deadstock_threshold_days = models.PositiveIntegerField(
        default=30,
        help_text="Number of days with no sales before a product is considered deadstock.",
    )

    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.business_name