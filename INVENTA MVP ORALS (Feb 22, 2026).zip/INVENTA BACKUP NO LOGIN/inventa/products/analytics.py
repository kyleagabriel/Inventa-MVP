# products/analytics.py

import datetime as dt
from decimal import Decimal
from statistics import mean, pstdev

from django.db.models import ExpressionWrapper, DecimalField, F, Sum

from .models import Product, SalesInvoiceItem


HISTORY_DAYS_DEFAULT = 180
FORECAST_DAYS_DEFAULT = 30
LEAD_TIME_DAYS_DEFAULT = 7
Z_SERVICE_LEVEL = 1.65            # ~95% service level


def _daterange(start_date, end_date):
    for n in range((end_date - start_date).days + 1):
        yield start_date + dt.timedelta(days=n)


def _get_daily_sales_series(product, history_days=HISTORY_DAYS_DEFAULT):
    today = dt.date.today()
    start_date = today - dt.timedelta(days=history_days)

    qs = (
        SalesInvoiceItem.objects
        .filter(
            product=product,
            invoice__date__gte=start_date,
            invoice__date__lte=today,
            invoice__is_cancelled=False,
        )
        .values("invoice__date")
        .annotate(qty=Sum("quantity_sold"))
    )

    raw = {row["invoice__date"]: row["qty"] for row in qs}

    series = []
    for d in _daterange(start_date, today):
        series.append((d, raw.get(d, 0)))
    return series


def _simple_exponential_smoothing(values, alpha=0.3):
    if not values:
        return 0.0, []
    s = values[0]
    smoothed = [s]
    for x in values[1:]:
        s = alpha * x + (1 - alpha) * s
        smoothed.append(s)
    return s, smoothed


# ─────────────────────────────────────────────
#  TAB 1 — REORDER ALERTS
# ─────────────────────────────────────────────

def build_product_demand_profile(
    product: Product,
    history_days: int = HISTORY_DAYS_DEFAULT,
    forecast_days: int = FORECAST_DAYS_DEFAULT,
    lead_time_days: int = LEAD_TIME_DAYS_DEFAULT,
):
    series = _get_daily_sales_series(product, history_days=history_days)
    daily_values = [qty for _, qty in series]

    if any(daily_values):
        avg_daily = sum(daily_values) / len(daily_values)
    else:
        avg_daily = 0.0

    smoothed_last, _ = _simple_exponential_smoothing(daily_values)
    forecast_daily = smoothed_last

    nonzero_days = [v for v in daily_values if v > 0]
    if len(nonzero_days) >= 2:
        demand_std_daily = float(pstdev(nonzero_days))
    else:
        demand_std_daily = 0.0

    forecast_total_horizon = forecast_daily * forecast_days
    safety_stock = Z_SERVICE_LEVEL * demand_std_daily * (lead_time_days ** 0.5)
    demand_during_lead_time = forecast_daily * lead_time_days
    reorder_point = demand_during_lead_time + safety_stock

    on_hand = float(product.quantity or 0)

    # Days of stock left
    if forecast_daily > 0:
        days_of_stock = on_hand / forecast_daily
    else:
        days_of_stock = None  # no demand — can't compute

    # Reorder by date
    if days_of_stock is not None:
        reorder_by_date = dt.date.today() + dt.timedelta(days=max(0, days_of_stock - lead_time_days))
    else:
        reorder_by_date = None

    # Stockout risk over 14 days
    horizon14 = 14
    forecast_14d = forecast_daily * horizon14
    if forecast_14d <= 0:
        stockout_risk_14d = 0.0
    else:
        shortfall = max(0.0, forecast_14d - on_hand)
        stockout_risk_14d = shortfall / forecast_14d

    # Recommended order qty
    target_stock_level = forecast_daily * forecast_days
    if on_hand < reorder_point:
        recommended_order_qty = max(0.0, target_stock_level - on_hand)
    else:
        recommended_order_qty = 0.0

    return {
        "avg_daily_demand": round(avg_daily, 2),
        "forecast_daily": round(forecast_daily, 2),
        "forecast_total_horizon": round(forecast_total_horizon, 2),
        "safety_stock": round(safety_stock, 2),
        "reorder_point": round(reorder_point, 2),
        "stockout_risk_14d": round(stockout_risk_14d, 3),
        "recommended_order_qty": int(round(recommended_order_qty)),
        "days_of_stock": round(days_of_stock, 1) if days_of_stock is not None else None,
        "reorder_by_date": reorder_by_date,
    }


# ─────────────────────────────────────────────
#  TAB 2 — FAST MOVERS
# ─────────────────────────────────────────────

def get_fast_movers_by_velocity(products, days=30, top_n=20):
    """
    Returns products ranked by total units sold in the last `days` days.
    """
    today = dt.date.today()
    start_date = today - dt.timedelta(days=days)

    results = []
    for p in products:
        qs = (
            SalesInvoiceItem.objects
            .filter(
                product=p,
                invoice__date__gte=start_date,
                invoice__is_cancelled=False,
            )
        )
        total_sold = qs.aggregate(total=Sum("quantity_sold"))["total"] or 0
        if total_sold > 0:
            revenue = qs.aggregate(
                total_revenue=Sum(
                    ExpressionWrapper(
                        F("quantity_sold") * F("unit_price"),
                        output_field=DecimalField()
                    )
                )
            )["total_revenue"] or Decimal("0.00")
            results.append({
                "product": p,
                "units_sold": total_sold,
                "avg_daily": round(total_sold / days, 2),
                "revenue_30d": revenue,
            })

    results.sort(key=lambda x: x["units_sold"], reverse=True)
    return results[:top_n]


def get_fast_movers_by_margin(products, top_n=20):
    """
    Returns products ranked by gross profit per unit (selling_price - avg_cost).
    Only includes products that have both selling_price and avg_cost > 0.
    """
    results = []
    for p in products:
        if p.selling_price and p.avg_cost and p.avg_cost > 0:
            margin = p.selling_price - p.avg_cost
            margin_pct = (margin / p.selling_price * 100) if p.selling_price > 0 else Decimal("0")
            results.append({
                "product": p,
                "selling_price": p.selling_price,
                "avg_cost": p.avg_cost,
                "margin_per_unit": margin,
                "margin_pct": round(margin_pct, 1),
            })

    results.sort(key=lambda x: x["margin_per_unit"], reverse=True)
    return results[:top_n]


# ─────────────────────────────────────────────
#  TAB 3 — DEADSTOCK
# ─────────────────────────────────────────────

def _get_last_sale_date(product):
    """Returns the date of the most recent fulfilled sale for a product, or None."""
    last = (
        SalesInvoiceItem.objects
        .filter(product=product, invoice__is_cancelled=False)
        .order_by("-invoice__date")
        .values_list("invoice__date", flat=True)
        .first()
    )
    return last


def get_deadstock_items(products, threshold_days=30, fast_movers=None):
    """
    Returns products with no sales in the last `threshold_days` days.
    Attaches idle capital value and a simple action plan.
    `fast_movers` is an optional list of fast-mover product objects for bundle suggestions.
    """
    today = dt.date.today()
    cutoff = today - dt.timedelta(days=threshold_days)

    # Build a list of fast mover product objects for bundle suggestions
    fm_products = []
    if fast_movers:
        fm_products = [row["product"] for row in fast_movers]

    results = []
    for p in products:
        if p.quantity <= 0:
            continue  # no stock, skip

        last_sale = _get_last_sale_date(p)

        if last_sale is None:
            # Never been sold — definitely deadstock
            days_since_sale = None
            is_deadstock = True
        elif last_sale <= cutoff:
            days_since_sale = (today - last_sale).days
            is_deadstock = True
        else:
            continue  # sold recently, not deadstock

        # Idle capital = units on hand × avg cost
        idle_capital = Decimal(str(p.quantity)) * p.avg_cost

        # Action plan
        action = _build_action_plan(p, fm_products)

        results.append({
            "product": p,
            "last_sale_date": last_sale,
            "days_since_sale": days_since_sale,
            "units_on_hand": p.quantity,
            "avg_cost": p.avg_cost,
            "idle_capital": idle_capital.quantize(Decimal("0.01")),
            "action": action,
        })

    # Sort by idle capital descending (highest value first)
    results.sort(key=lambda x: x["idle_capital"], reverse=True)
    return results


def _build_action_plan(product, fast_movers):
    """
    Returns a simple dict with:
    - suggested_discount_pct: integer %
    - bundle_with: product object or None
    """
    suggested_discount = 15  # default %

    if product.selling_price and product.avg_cost and product.avg_cost > 0:
        # Cap discount so we don't sell below cost
        max_discount = int(((product.selling_price - product.avg_cost) / product.selling_price) * 100)
        suggested_discount = min(suggested_discount, max(5, max_discount - 5))

    # Bundle suggestion — pair with a fast mover that isn't this product
    bundle_partner = None
    for fm in fast_movers:
        if fm.pk != product.pk:
            bundle_partner = fm
            break

    return {
        "suggested_discount_pct": suggested_discount,
        "bundle_with": bundle_partner,
    }