from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST
from django.contrib import messages
from django.http import JsonResponse
from decimal import Decimal, ROUND_HALF_UP
from django.db import transaction, models
from django.urls import reverse
from django.db.models import Exists, OuterRef, F, Sum, Count, ExpressionWrapper, DecimalField
from datetime import date
import datetime as dt
from django.utils import timezone
import json as _json
from .analytics import build_product_demand_profile, get_fast_movers_by_velocity, get_fast_movers_by_margin, get_deadstock_items
from .forms import ProductForm, PurchaseOrderForm, PurchaseOrderItemFormSet, SalesInvoiceForm, SalesInvoiceItemFormSet, ProductPriceForm, BusinessProfileForm
from .models import Product, PurchaseOrder, PurchaseOrderItem, SalesInvoice, SalesInvoiceItem, BusinessProfile, FulfillmentRecord, SIFulfillmentRecord

# Create your views here.
def dashboard(request):
    """Dashboard homepage showing today's summary and quick actions."""
    
    today = timezone.localdate()
    
    # 📊 TODAY'S SALES
    todays_invoices = SalesInvoice.objects.filter(
        date=today,
        is_confirmed=True
    )
    
    total_sales_today = sum(inv.subtotal for inv in todays_invoices)
    invoice_count_today = todays_invoices.count()
    
    # 🏆 TOP SELLING PRODUCTS TODAY
    top_products = (
    SalesInvoiceItem.objects
    .filter(invoice__date=today, invoice__is_confirmed=True)
    .values('product__name', 'product__sku', 'product_id')
    .annotate(
        total_revenue=Sum(
            ExpressionWrapper(
                F('quantity_sold') * F('unit_price'),
                output_field=DecimalField()
            )
        )
    )
    .order_by('-total_revenue')[:5]
)
    
    # ⚠️ LOW STOCK ALERTS (products below reorder point)
    low_stock_products = []
    products = Product.objects.filter(is_archived=False)
    
    for product in products:
        profile = build_product_demand_profile(product)
        if product.quantity < profile['reorder_point']:
            low_stock_products.append({
                'product': product,
                'current_stock': product.quantity,
                'reorder_point': profile['reorder_point'],
                'recommended_order': profile['recommended_order_qty'],
            })
    
    # Sort by urgency (lowest stock first)
    low_stock_products.sort(key=lambda x: x['current_stock'])
    low_stock_products = low_stock_products[:10]  # Top 10 most urgent
    
    # 📦 PENDING PURCHASE ORDERS (confirmed, awaiting delivery from supplier)
    pending_pos = PurchaseOrder.objects.filter(
        is_confirmed=True,
        is_fulfilled=False,
        is_cancelled=False
    ).count()

    # 🚚 PENDING DELIVERIES TO CUSTOMERS (confirmed SIs not yet fully fulfilled)
    pending_deliveries = SalesInvoice.objects.filter(
        is_confirmed=True,
        is_fulfilled=False,
        is_cancelled=False
    ).count()

    # List of those invoices for the dashboard card (latest 10)
    pending_delivery_invoices = SalesInvoice.objects.filter(
        is_confirmed=True,
        is_fulfilled=False,
        is_cancelled=False
    ).order_by('-created_at')[:10]

    # List of confirmed POs awaiting delivery from supplier (latest 10)
    pending_pos_list = PurchaseOrder.objects.filter(
        is_confirmed=True,
        is_fulfilled=False,
        is_cancelled=False
    ).order_by('-created_at')[:10]
    
    context = {
    'total_sales_today': total_sales_today,
    'invoice_count_today': invoice_count_today,
    'top_products': top_products,
    'low_stock_products': low_stock_products,
    'pending_pos': pending_pos,
    'pending_deliveries': pending_deliveries,
    'pending_delivery_invoices': pending_delivery_invoices,
    'pending_pos_list': pending_pos_list,
    'today': today,
}
    
    return render(request, 'products/dashboard.html', context)

def get_business_profile():
    profile, _ = BusinessProfile.objects.get_or_create(
        pk=1,
        defaults={"business_name": "", "address": "", "tin": ""}
    )
    return profile

def product_search_api(request):
    """API endpoint for product autocomplete search."""
    query = request.GET.get('q', '').strip()
    
    if len(query) < 1:  # Only search if 1 characters
        return JsonResponse({'results': []})
    
    # Search by name or SKU
    products = Product.objects.filter(
        is_archived=False
    ).filter(
        models.Q(name__icontains=query) | models.Q(sku__icontains=query)
    )[:20]  # Limit to 20 results
    
    results = []
    for product in products:
        results.append({
            'id': product.id,
            'sku': product.sku,
            'name': product.name,
            'stock': product.quantity,
            'price': float(product.selling_price) if product.selling_price else 0.00,
        })
    
    return JsonResponse({'results': results})

def product_list(request):
    products = (
        Product.objects
        .filter(is_archived=False)               # 👈 hide archived
        .annotate(
            has_po_items=Exists(
                PurchaseOrderItem.objects.filter(product=OuterRef("pk"))
            ),
            has_si_items=Exists(
                SalesInvoiceItem.objects.filter(product=OuterRef("pk"))
            ),
        )
        .order_by("name")
    )

    return render(
        request,
        "products/product_list.html",
        {"products": products},
    )

def add_product(request):
    if request.method == "POST":
        form = ProductForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("product_list")  
    else:
        form = ProductForm()
    return render(request, "products/add_product.html", {"form": form})

@require_POST
def add_product_quick(request):
    """Quick-add a product via AJAX from the PO create modal."""
    sku = request.POST.get("sku", "").strip()
    name = request.POST.get("name", "").strip()
    selling_price = request.POST.get("selling_price", "").strip()

    errors = {}
    if not sku:
        errors["sku"] = "SKU is required."
    if not name:
        errors["name"] = "Product name is required."
    if Product.objects.filter(sku=sku).exists():
        errors["sku"] = "A product with this SKU already exists."

    if errors:
        return JsonResponse({"success": False, "errors": errors})

    product = Product.objects.create(
        sku=sku,
        name=name,
        quantity=0,
        selling_price=selling_price if selling_price else None,
    )
    return JsonResponse({
        "success": True,
        "product": {
            "id": product.id,
            "sku": product.sku,
            "name": product.name,
            "stock": 0,
            "price": float(product.selling_price) if product.selling_price else None,
        }
    })

@require_POST
def delete_product(request, pk):
    product = get_object_or_404(Product, pk=pk)

    # ❌ Block delete if product already used in any transaction
    has_po = PurchaseOrderItem.objects.filter(product=product).exists()
    has_si = SalesInvoiceItem.objects.filter(product=product).exists()

    if has_po or has_si:
        messages.error(
            request,
            "This product already has transactions and cannot be deleted. "
            "You can archive it instead."
        )
        return redirect("product_list")

    # ✅ Safe to hard-delete
    product.delete()
    messages.success(request, f"Product {product.sku} deleted.")
    return redirect("product_list")

def po_create(request):
    profile = get_business_profile()

    if request.method == "POST":
        form = PurchaseOrderForm(request.POST)
        formset = PurchaseOrderItemFormSet(request.POST)

        if form.is_valid() and formset.is_valid():
            po = form.save(commit=False)

            # ✅ enforce profile values (so user never needs to type them)
            po.business_name = profile.business_name
            po.business_address = profile.address
            po.business_tin = profile.tin

            # ✅ enforce today's date
            po.date = timezone.localdate()

            po.is_confirmed = False
            po.confirmed_at = None
            po.save()

            formset.instance = po
            formset.save()

            messages.success(request, "PO saved as draft ✅")
            return redirect("po_detail", pk=po.pk)
    else:
        # ✅ Pre-fill on create
        form = PurchaseOrderForm(initial={
            "business_name": profile.business_name,
            "business_address": profile.address,
            "business_tin": profile.tin,
            "date": timezone.localdate(),
        })
        formset = PurchaseOrderItemFormSet()

        # ✅ Make profile fields read-only so user doesn't touch them
        for f in ["business_name", "business_address", "business_tin", "date"]:
            if f in form.fields:
                form.fields[f].widget.attrs["readonly"] = True

    return render(request, "products/po_create.html", {
    "form": form,
    "formset": formset,
    "mode": "create",
    "products": Product.objects.filter(is_archived=False).order_by("name"),
})

@transaction.atomic
def po_edit(request, pk):
    po = get_object_or_404(PurchaseOrder, pk=pk)

    if po.is_confirmed:
        messages.error(request, "This PO is already confirmed and cannot be edited.")
        return redirect("po_detail", pk=po.pk)

    if request.method == "POST":
        form = PurchaseOrderForm(request.POST, instance=po)
        formset = PurchaseOrderItemFormSet(request.POST, instance=po)

        if form.is_valid() and formset.is_valid():
            form.save()
            formset.save()
            messages.success(request, "Draft updated ✅")
            return redirect("po_detail", pk=po.pk)
    else:
        form = PurchaseOrderForm(instance=po)
        formset = PurchaseOrderItemFormSet(instance=po)

    return render(request, "products/po_create.html", {
    "form": form,
    "formset": formset,
    "mode": "edit",
    "po": po,
    "products": Product.objects.filter(is_archived=False).order_by("name"),
})

def po_detail(request, pk):
    po = get_object_or_404(PurchaseOrder, pk=pk)

    from_stock_card = request.GET.get("from_stock_card")

    if from_stock_card:
        # Opened from a product's stock card
        back_url = reverse("product_stock_card", args=[from_stock_card])
        back_label = "Back to Stock Card"
    else:
        # Normal behavior
        back_url = reverse("po_list")
        back_label = "Back to Purchase Orders"

    context = {
        "po": po,
        "back_url": back_url,
        "back_label": back_label,
    }
    return render(request, "products/po_detail.html", context)
    
def po_confirm(request, pk):
    """Confirm PO = mark it as sent to supplier. Stock does NOT change here."""
    if request.method != "POST":
        return redirect("po_detail", pk=pk)

    po = get_object_or_404(PurchaseOrder, pk=pk)

    if po.is_confirmed:
        messages.info(request, "This PO is already confirmed ✅")
        return redirect("po_detail", pk=po.pk)

    po.confirm_and_increase_stock()
    messages.success(request, "PO confirmed ✅ — Awaiting delivery from supplier 🚚")
    return redirect("po_detail", pk=po.pk)


def po_list(request):
    """List all purchase orders with status filtering."""
    status_filter = request.GET.get("status", "all")

    pos = PurchaseOrder.objects.prefetch_related("items").order_by("-created_at")

    if status_filter == "draft":
        pos = pos.filter(is_confirmed=False, is_cancelled=False)
    elif status_filter == "confirmed":
        # Awaiting Delivery = confirmed, not fulfilled, not cancelled
        # Then we filter down to only those with NO fulfillment records
        confirmed_pos = pos.filter(is_confirmed=True, is_fulfilled=False, is_cancelled=False)
        po_ids_with_fulfillments = FulfillmentRecord.objects.values_list("po_item__po_id", flat=True).distinct()
        pos = confirmed_pos.exclude(pk__in=po_ids_with_fulfillments)
    elif status_filter == "partial":
        confirmed_pos = pos.filter(is_confirmed=True, is_fulfilled=False, is_cancelled=False)
        po_ids_with_fulfillments = FulfillmentRecord.objects.values_list("po_item__po_id", flat=True).distinct()
        pos = confirmed_pos.filter(pk__in=po_ids_with_fulfillments)
    elif status_filter == "fulfilled":
        pos = pos.filter(is_fulfilled=True)
    elif status_filter == "cancelled":
        pos = pos.filter(is_cancelled=True)

    # For counts
    all_confirmed = PurchaseOrder.objects.filter(is_confirmed=True, is_fulfilled=False, is_cancelled=False)
    po_ids_with_fulfillments = FulfillmentRecord.objects.values_list("po_item__po_id", flat=True).distinct()

    counts = {
        "all": PurchaseOrder.objects.count(),
        "draft": PurchaseOrder.objects.filter(is_confirmed=False, is_cancelled=False).count(),
        "confirmed": all_confirmed.exclude(pk__in=po_ids_with_fulfillments).count(),
        "partial": all_confirmed.filter(pk__in=po_ids_with_fulfillments).count(),
        "fulfilled": PurchaseOrder.objects.filter(is_fulfilled=True).count(),
        "cancelled": PurchaseOrder.objects.filter(is_cancelled=True).count(),
    }

    return render(request, "products/po_list.html", {
        "pos": pos,
        "status_filter": status_filter,
        "counts": counts,
    })


@transaction.atomic
def po_fulfill(request, pk):
    """Record a (partial) fulfillment — this is when stock actually increases."""
    po = get_object_or_404(PurchaseOrder, pk=pk)

    if not po.is_confirmed:
        messages.error(request, "PO must be confirmed before it can be fulfilled.")
        return redirect("po_detail", pk=pk)

    if po.is_cancelled:
        messages.error(request, "This PO has been cancelled.")
        return redirect("po_detail", pk=pk)

    if po.is_fulfilled:
        messages.info(request, "This PO is already fully fulfilled.")
        return redirect("po_detail", pk=pk)

    if request.method != "POST":
        return redirect("po_detail", pk=pk)

    items = po.items.all()
    any_received = False
    errors = []

    for item in items:
        field_key = f"qty_fulfill_{item.pk}"
        raw = request.POST.get(field_key, "").strip()
        if not raw:
            continue
        try:
            qty = int(raw)
        except ValueError:
            errors.append(f"Invalid quantity for {item.product_name}.")
            continue

        if qty <= 0:
            continue

        remaining = item.quantity_remaining
        if qty > remaining:
            errors.append(
                f"Cannot receive {qty} for {item.product_name} — only {remaining} units still outstanding."
            )
            continue

        notes = request.POST.get(f"notes_{item.pk}", "").strip()
        FulfillmentRecord.objects.create(po_item=item, quantity=qty, notes=notes)

        # Update quantity AND recalculate weighted average cost atomically
        product = Product.objects.select_for_update().get(pk=item.product_id)
        old_qty = product.quantity
        old_cost = product.avg_cost
        new_cost_per_unit = item.unit_price
        new_total_qty = old_qty + qty
        if new_total_qty > 0:
            weighted_avg = ((old_qty * old_cost) + (qty * new_cost_per_unit)) / new_total_qty
        else:
            weighted_avg = new_cost_per_unit
        weighted_avg = Decimal(str(weighted_avg)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        Product.objects.filter(pk=item.product_id).update(
            quantity=F("quantity") + qty,
            avg_cost=weighted_avg,
        )
        any_received = True

    if errors:
        for e in errors:
            messages.error(request, e)
        if not any_received:
            return redirect("po_detail", pk=pk)

    if not any_received and not errors:
        messages.warning(request, "No quantities entered. Nothing was recorded.")
        return redirect("po_detail", pk=pk)

    # Check if PO is now fully fulfilled
    po.refresh_from_db()
    all_items = po.items.prefetch_related("fulfillments").all()
    fully_fulfilled = all(
        item.quantity_fulfilled >= item.quantity_received for item in all_items
    )
    if fully_fulfilled:
        po.is_fulfilled = True
        po.fulfilled_at = timezone.now()
        po.save(update_fields=["is_fulfilled", "fulfilled_at"])
        messages.success(request, "PO fully fulfilled ✅ Stock has been updated 📦")
    else:
        messages.success(request, "Partial fulfillment recorded ✅ Stock updated for received items 📦")

    return redirect("po_detail", pk=pk)


@require_POST
def po_cancel(request, pk):
    """Cancel a PO. Cannot cancel a fully fulfilled PO."""
    po = get_object_or_404(PurchaseOrder, pk=pk)
    try:
        po.cancel()
        messages.success(request, "Purchase Order cancelled.")
    except ValueError as e:
        messages.error(request, str(e))
    return redirect("po_detail", pk=pk)

@transaction.atomic
def si_create(request):
    """Create a NEW Sales Invoice as DRAFT — no stock movement."""
    profile = get_business_profile()

    if request.method == "POST":
        form = SalesInvoiceForm(request.POST)
        formset = SalesInvoiceItemFormSet(request.POST)

        if form.is_valid() and formset.is_valid():
            invoice = form.save(commit=False)
            invoice.business_name = profile.business_name
            invoice.business_address = profile.address
            invoice.business_tin = profile.tin
            invoice.date = timezone.localdate()
            invoice.is_confirmed = False
            invoice.save()

            formset.instance = invoice
            formset.save()

            messages.success(request, "Sales Invoice draft created ✅ Review it and confirm when ready.")
            return redirect(f"/si/{invoice.pk}/?from=create")
    else:
        form = SalesInvoiceForm(initial={
            "business_name": profile.business_name,
            "business_address": profile.address,
            "business_tin": profile.tin,
            "date": timezone.localdate(),
        })
        formset = SalesInvoiceItemFormSet()

        for f in ["business_name", "business_address", "business_tin", "date"]:
            if f in form.fields:
                form.fields[f].widget.attrs["readonly"] = True

    products = Product.objects.filter(is_archived=False).order_by("name")
    return render(request, "products/si_create.html", {
        "form": form,
        "formset": formset,
        "products": products,
        "mode": "create",
    })

def si_edit(request, pk):
    si = get_object_or_404(SalesInvoice, pk=pk)

    if si.is_confirmed:
        messages.error(request, "This SI is already confirmed and cannot be edited.")
        return redirect("si_detail", pk=si.pk)

    if si.is_cancelled:
        messages.error(request, "This SI has been cancelled and cannot be edited.")
        return redirect("si_detail", pk=si.pk)

    if request.method == "POST":
        form = SalesInvoiceForm(request.POST, instance=si)
        formset = SalesInvoiceItemFormSet(request.POST, instance=si)

        if form.is_valid() and formset.is_valid():
            form.save()
            formset.save()
            messages.success(request, "Sales Invoice draft updated ✅")
            return redirect(f"/si/{si.pk}/?from=create")
    else:
        form = SalesInvoiceForm(instance=si)
        formset = SalesInvoiceItemFormSet(instance=si)

    products = Product.objects.filter(is_archived=False).order_by("name")
    return render(request, "products/si_create.html", {
        "form": form,
        "formset": formset,
        "products": products,
        "mode": "edit",
        "invoice": si,
    })

def si_list(request):
    """List all Sales Invoices with status filter tabs."""
    status_filter = request.GET.get("status", "all")
    sis = SalesInvoice.objects.all().order_by("-created_at")

    si_ids_with_fulfillments = SIFulfillmentRecord.objects.values_list(
        "si_item__invoice_id", flat=True
    ).distinct()

    if status_filter == "draft":
        sis = sis.filter(is_confirmed=False, is_cancelled=False)
    elif status_filter == "confirmed":
        confirmed = sis.filter(is_confirmed=True, is_fulfilled=False, is_cancelled=False)
        sis = confirmed.exclude(pk__in=si_ids_with_fulfillments)
    elif status_filter == "partial":
        confirmed = sis.filter(is_confirmed=True, is_fulfilled=False, is_cancelled=False)
        sis = confirmed.filter(pk__in=si_ids_with_fulfillments)
    elif status_filter == "fulfilled":
        sis = sis.filter(is_fulfilled=True)
    elif status_filter == "cancelled":
        sis = sis.filter(is_cancelled=True)

    all_confirmed = SalesInvoice.objects.filter(is_confirmed=True, is_fulfilled=False, is_cancelled=False)
    counts = {
        "all": SalesInvoice.objects.count(),
        "draft": SalesInvoice.objects.filter(is_confirmed=False, is_cancelled=False).count(),
        "confirmed": all_confirmed.exclude(pk__in=si_ids_with_fulfillments).count(),
        "partial": all_confirmed.filter(pk__in=si_ids_with_fulfillments).count(),
        "fulfilled": SalesInvoice.objects.filter(is_fulfilled=True).count(),
        "cancelled": SalesInvoice.objects.filter(is_cancelled=True).count(),
    }

    return render(request, "products/si_list.html", {
        "sis": sis,
        "status_filter": status_filter,
        "counts": counts,
    })

def si_detail(request, pk):
    invoice = get_object_or_404(SalesInvoice, pk=pk)

    from_create = request.GET.get("from")
    from_stock_card = request.GET.get("from_stock_card")

    if from_create == "create":
        back_url = reverse("si_list")
        back_label = "← Back to Sales Invoices"
    elif from_stock_card:
        back_url = reverse("product_stock_card", args=[from_stock_card])
        back_label = "← Back to Stock Card"
    else:
        back_url = reverse("si_list")
        back_label = "← Back to Sales Invoices"

    # Build stock warning data for each item (live stock vs remaining to deliver)
    items_with_warnings = []
    for item in invoice.items.select_related("product").all():
        item.product.refresh_from_db()
        items_with_warnings.append({
            "item": item,
            "warning": item.has_stock_warning,
            "live_stock": item.product.quantity,
        })

    context = {
        "invoice": invoice,
        "back_url": back_url,
        "back_label": back_label,
        "items_with_warnings": items_with_warnings,
        "any_stock_warning": any(i["warning"] for i in items_with_warnings),
    }
    return render(request, "products/si_detail.html", context)

@require_POST
@transaction.atomic
def si_confirm(request, pk):
    """
    Confirm the SI. Stock is NOT deducted here.
    Allowed even with insufficient stock (lead-time use case).
    A warning is shown if stock is short.
    """
    invoice = get_object_or_404(SalesInvoice, pk=pk)

    if invoice.is_confirmed:
        messages.info(request, "This invoice is already confirmed ✅")
        return redirect("si_detail", pk=invoice.pk)

    if invoice.is_cancelled:
        messages.error(request, "This invoice has been cancelled and cannot be confirmed.")
        return redirect("si_detail", pk=invoice.pk)

    invoice.confirm()

    # Warn if any items have insufficient stock — but do not block
    stock_warnings = []
    for item in invoice.items.select_related("product").all():
        item.product.refresh_from_db()
        if item.product.quantity < item.quantity_sold:
            stock_warnings.append(
                f"⚠️ {item.product_name} ({item.product_sku}): "
                f"need {item.quantity_sold}, only {item.product.quantity} in stock — order stock immediately."
            )

    if stock_warnings:
        messages.warning(request, f"Invoice #{invoice.id} confirmed 🧾 — but some items have insufficient stock:")
        for w in stock_warnings:
            messages.warning(request, w)
    else:
        messages.success(request, f"Invoice #{invoice.id} confirmed ✅ Ready to record deliveries.")

    return redirect("si_detail", pk=invoice.pk)

def si_fulfill(request, pk):
    """Record a (partial) delivery of a Sales Invoice — stock deducts here."""
    invoice = get_object_or_404(SalesInvoice, pk=pk)

    if not invoice.is_confirmed:
        messages.error(request, "SI must be confirmed before deliveries can be recorded.")
        return redirect("si_detail", pk=pk)

    if invoice.is_cancelled:
        messages.error(request, "This SI has been cancelled.")
        return redirect("si_detail", pk=pk)

    if invoice.is_fulfilled:
        messages.info(request, "This SI is already fully fulfilled.")
        return redirect("si_detail", pk=pk)

    if request.method != "POST":
        return redirect("si_detail", pk=pk)

    items = invoice.items.all()
    any_delivered = False
    errors = []

    with transaction.atomic():
        for item in items:
            field_key = f"qty_fulfill_{item.pk}"
            raw = request.POST.get(field_key, "").strip()
            if not raw:
                continue
            try:
                qty = int(raw)
            except ValueError:
                errors.append(f"Invalid quantity for {item.product_name}.")
                continue

            if qty <= 0:
                continue

            remaining = item.quantity_remaining
            if qty > remaining:
                errors.append(
                    f"Cannot deliver {qty} for {item.product_name} — "
                    f"only {remaining} units still outstanding."
                )
                continue

            # Lock the product row and validate live stock
            product = Product.objects.select_for_update().get(pk=item.product_id)
            if qty > product.quantity:
                errors.append(
                    f"Not enough stock to deliver {qty} of {item.product_name} — "
                    f"only {product.quantity} available. Order more stock first."
                )
                continue

            notes = request.POST.get(f"notes_{item.pk}", "").strip()
            SIFulfillmentRecord.objects.create(si_item=item, quantity=qty, notes=notes)

            # Deduct stock at point of fulfillment
            Product.objects.filter(pk=item.product_id).update(
                quantity=F("quantity") - qty
            )
            any_delivered = True

    if errors:
        for e in errors:
            messages.error(request, e)
        if not any_delivered:
            return redirect("si_detail", pk=pk)

    if not any_delivered and not errors:
        messages.warning(request, "No quantities entered. Nothing was recorded.")
        return redirect("si_detail", pk=pk)

    # Check if SI is now fully fulfilled
    invoice.refresh_from_db()
    all_items = invoice.items.prefetch_related("fulfillments").all()
    fully_fulfilled = all(item.quantity_remaining == 0 for item in all_items)
    if fully_fulfilled:
        invoice.is_fulfilled = True
        invoice.fulfilled_at = timezone.now()
        invoice.save(update_fields=["is_fulfilled", "fulfilled_at"])
        messages.success(request, "Sales Invoice fully fulfilled ✅ All items delivered, stock updated 📦")
    else:
        messages.success(request, "Partial delivery recorded ✅ Stock updated for delivered items 📦")

    return redirect("si_detail", pk=pk)


@require_POST
def si_cancel(request, pk):
    """Cancel a Sales Invoice. Cannot cancel a fully fulfilled SI."""
    invoice = get_object_or_404(SalesInvoice, pk=pk)
    try:
        invoice.cancel()
        messages.success(request, "Sales Invoice cancelled.")
    except ValueError as e:
        messages.error(request, str(e))
    return redirect("si_detail", pk=pk)

def product_stock_card(request, pk):
    product = get_object_or_404(Product, pk=pk)

    # Handle selling price update
    if request.method == "POST":
        price_form = ProductPriceForm(request.POST, instance=product)
        if price_form.is_valid():
            price_form.save()
            return redirect(request.path)
    else:
        price_form = ProductPriceForm(instance=product)

    entries = []
    total_qty_in = 0
    total_cost = Decimal("0.00")

    # 🟢 IN: Fulfillment records only (actual stock received)
    fulfillments = (
        FulfillmentRecord.objects
        .filter(po_item__product=product)
        .select_related("po_item", "po_item__po")
    )
    for record in fulfillments:
        item = record.po_item
        po = item.po
        tx_datetime = record.received_at

        entries.append({
            "date": tx_datetime,
            "type": "IN",
            "ref_type": "PO",
            "ref_id": po.id,
            "partner": po.supplier_name,
            "qty_in": record.quantity,
            "qty_out": 0,
        })

        total_qty_in += record.quantity
        total_cost += item.unit_price * record.quantity

    # 🔴 OUT: SI Fulfillment records only (actual stock delivered to customers)
    si_fulfillments = (
        SIFulfillmentRecord.objects
        .filter(si_item__product=product)
        .select_related("si_item", "si_item__invoice")
    )
    for record in si_fulfillments:
        item = record.si_item
        inv = item.invoice
        tx_datetime = record.delivered_at

        entries.append({
            "date": tx_datetime,
            "type": "OUT",
            "ref_type": "SI",
            "ref_id": inv.id,
            "partner": inv.customer_name,
            "qty_in": 0,
            "qty_out": record.quantity,
        })

    # 🧮 Compute correct balances

    # 1) sort oldest → newest
    entries.sort(key=lambda e: e["date"])

    # 2) net movement from all confirmed transactions
    total_delta = sum(e["qty_in"] - e["qty_out"] for e in entries)

    # 3) infer opening quantity so last balance = product.quantity
    current_qty = product.quantity
    opening_qty = current_qty - total_delta

    # 4) walk forward in time and assign running balance
    running = opening_qty
    for e in entries:
        delta = e["qty_in"] - e["qty_out"]
        running += delta
        e["balance"] = running

    # 5) for display: newest at the top
    entries.sort(key=lambda e: e["date"], reverse=True)

    # Average cost from confirmed IN movements only
    average_cost = (total_cost / total_qty_in) if total_qty_in > 0 else None

    context = {
        "product": product,
        "entries": entries,
        "average_cost": average_cost,
        "price_form": price_form,
    }
    return render(request, "products/stock_card.html", context)

@require_POST
def archive_product(request, pk):
    product = get_object_or_404(Product, pk=pk)
    product.is_archived = True
    product.save(update_fields=["is_archived"])

    messages.success(
        request,
        f"Product {product.sku} archived. It will no longer appear in the product list."
    )
    return redirect("product_list")

def archived_product_list(request):
    products = (
        Product.objects
        .filter(is_archived=True)
        .annotate(
            has_po_items=Exists(
                PurchaseOrderItem.objects.filter(product=OuterRef("pk"))
            ),
            has_si_items=Exists(
                SalesInvoiceItem.objects.filter(product=OuterRef("pk"))
            ),
        )
        .order_by("name")
    )

    return render(
        request,
        "products/archived_products.html",
        {"products": products},
    )

@require_POST
def unarchive_product(request, pk):
    product = get_object_or_404(Product, pk=pk)
    product.is_archived = False
    product.save(update_fields=["is_archived"])
    messages.success(request, f"{product.sku} restored.")
    return redirect("archived_products")

# -------------- ANALYTICS -----------------------

def inventory_intel(request):
    """
    Inventory Intelligence — 4 tabs:
    0. Overview
    1. Reorder Alerts
    2. Fast Movers (velocity + margin)
    3. Deadstock (with configurable threshold saved to BusinessProfile)
    """
    profile = BusinessProfile.objects.get_or_create(pk=1)[0]

    # ── Handle deadstock threshold save ──
    if request.method == "POST" and "deadstock_threshold_days" in request.POST:
        try:
            threshold = int(request.POST["deadstock_threshold_days"])
            if threshold < 1:
                threshold = 1
            profile.deadstock_threshold_days = threshold
            profile.save(update_fields=["deadstock_threshold_days"])
            messages.success(request, "Deadstock threshold updated.")
        except (ValueError, TypeError):
            messages.error(request, "Invalid threshold value.")
        return redirect("inventory_intel")

    products = (
        Product.objects
        .filter(is_archived=False)
        .order_by("name")
    )
    products_list = list(products)

    # ── TAB 1: Reorder Alerts ──
    reorder_rows = []
    needs_reorder_count = 0
    high_risk_count = 0

    for p in products_list:
        prof = build_product_demand_profile(p)
        risk = prof["stockout_risk_14d"]
        if risk > 0.7:
            risk_label = "high"
            high_risk_count += 1
        elif risk > 0.3:
            risk_label = "medium"
        else:
            risk_label = "low"

        if prof["recommended_order_qty"] > 0:
            needs_reorder_count += 1

        reorder_rows.append({
            "product": p,
            "days_of_stock": prof["days_of_stock"],
            "reorder_by_date": prof["reorder_by_date"],
            "recommended_order_qty": prof["recommended_order_qty"],
            "risk_label": risk_label,
            "stockout_risk_14d": risk,
        })

    # Sort: high risk first
    risk_order = {"high": 0, "medium": 1, "low": 2}
    reorder_rows.sort(key=lambda r: risk_order[r["risk_label"]])

    # ── TAB 2: Fast Movers ──
    fast_by_velocity = get_fast_movers_by_velocity(products_list, days=30)
    fast_by_margin = get_fast_movers_by_margin(products_list)

    # ── TAB 3: Deadstock ──
    threshold = profile.deadstock_threshold_days
    deadstock_rows = get_deadstock_items(
        products_list,
        threshold_days=threshold,
        fast_movers=fast_by_velocity,
    )
    total_idle_capital = sum(r["idle_capital"] for r in deadstock_rows)

    active_tab = request.GET.get("tab", "overview")

    # ── TAB 0: OVERVIEW ──
    overview_days = 90
    overview_start = dt.date.today() - dt.timedelta(days=overview_days)

    daily_revenue_qs = (
        SalesInvoiceItem.objects
        .filter(
            invoice__date__gte=overview_start,
            invoice__is_cancelled=False,
            invoice__is_confirmed=True,
        )
        .values("invoice__date")
        .annotate(
            revenue=Sum(
                ExpressionWrapper(
                    F("quantity_sold") * F("unit_price"),
                    output_field=DecimalField()
                )
            ),
            units=Sum("quantity_sold"),
        )
        .order_by("invoice__date")
    )

    daily_revenue_data = [
        {
            "date": str(row["invoice__date"]),
            "revenue": float(row["revenue"] or 0),
            "units": int(row["units"] or 0),
        }
        for row in daily_revenue_qs
    ]

    invoice_counts_qs = (
        SalesInvoice.objects
        .filter(
            date__gte=overview_start,
            is_cancelled=False,
            is_confirmed=True,
        )
        .values("date")
        .annotate(count=Count("id"))
        .order_by("date")
    )

    invoice_counts_data = {
        str(row["date"]): row["count"]
        for row in invoice_counts_qs
    }

    for d in daily_revenue_data:
        d["invoices"] = invoice_counts_data.get(d["date"], 0)

    # Per-product revenue for overview top products table
    product_revenue_qs = (
        SalesInvoiceItem.objects
        .filter(
            invoice__date__gte=overview_start,
            invoice__is_cancelled=False,
            invoice__is_confirmed=True,
        )
        .values("product__id", "product__name", "product__sku", "invoice__date")
        .annotate(
            revenue=Sum(
                ExpressionWrapper(
                    F("quantity_sold") * F("unit_price"),
                    output_field=DecimalField()
                )
            ),
            units=Sum("quantity_sold"),
        )
    )

    product_revenue_data = []
    for row in product_revenue_qs:
        product_revenue_data.append({
            "product_id": row["product__id"],
            "name": row["product__name"],
            "sku": row["product__sku"],
            "date": str(row["invoice__date"]),
            "revenue": float(row["revenue"] or 0),
            "units": int(row["units"] or 0),
        })

    context = {
        "active_tab": active_tab,
        "overview_data_json": _json.dumps(daily_revenue_data),
        "overview_product_json": _json.dumps(product_revenue_data),
        # Tab 1
        "reorder_rows": reorder_rows,
        "needs_reorder_count": needs_reorder_count,
        "high_risk_count": high_risk_count,
        "total_skus": len(products_list),
        # Tab 2
        "fast_by_velocity": fast_by_velocity,
        "fast_by_margin": fast_by_margin,
        # Tab 3
        "deadstock_rows": deadstock_rows,
        "total_idle_capital": total_idle_capital,
        "deadstock_threshold": threshold,
    }
    return render(request, "products/inventory_intel.html", context)

def business_profile(request):
    # MVP: single global profile (always edit row #1)
    profile, _ = BusinessProfile.objects.get_or_create(
        pk=1,
        defaults={
            "business_name": "",
            "address": "",
            "tin": "",
        }
    )

    if request.method == "POST":
        form = BusinessProfileForm(request.POST, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, "Business profile saved ✅")
            return redirect("business_profile")
    else:
        form = BusinessProfileForm(instance=profile)

    return render(request, "products/business_profile.html", {
        "form": form,
        "profile": profile,
    })