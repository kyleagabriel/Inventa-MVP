from django import forms
from django.forms import inlineformset_factory
from .models import Product, PurchaseOrder, PurchaseOrderItem, SalesInvoice, SalesInvoiceItem, BusinessProfile, EcommerceSale, EcommerceSaleItem, Category, Expense, ExpenseCategory, PaymentRecord
from django.db.models import Case, When, IntegerField

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ["sku", "name", "quantity", "selling_price", "category"]
        widgets = {
            "sku": forms.TextInput(attrs={"placeholder": "Enter SKU"}),
            "name": forms.TextInput(attrs={"placeholder": "Enter product name"}),
            "quantity": forms.NumberInput(
                attrs={
                    "min": 0,
                    "step": 1,
                    "placeholder": "Enter quantity (e.g. 25)",
                }
            ),
            "selling_price": forms.NumberInput(
                attrs={
                    "min": 0,
                    "step": "0.01",
                    "placeholder": "Selling price (e.g. 2499.00)"},
            ),
            "category": forms.HiddenInput(),
        }

    def __init__(self, *args, **kwargs):
        self.business_profile = kwargs.pop("business_profile", None)
        super().__init__(*args, **kwargs)
        if not self.instance.pk and not self.is_bound:
            self.fields["quantity"].initial = ""
        self.fields["category"].required = False

    def clean_sku(self):
        sku = self.cleaned_data.get("sku", "").strip()
        if self.business_profile:
            qs = Product.objects.filter(
                business_profile=self.business_profile,
                sku=sku
            )
            if self.instance.pk:
                qs = qs.exclude(pk=self.instance.pk)
            if qs.exists():
                raise forms.ValidationError("A product with this SKU already exists.")
        return sku
    
class ProductPriceForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ["selling_price"]
        widgets = {
            "selling_price": forms.NumberInput(attrs={
                "step": "0.01",
                "min": "0",
                "class": "price-input",
                "placeholder": "0.00",
            })
        }

class PurchaseOrderForm(forms.ModelForm):
    class Meta:
        model = PurchaseOrder
        fields = [
            "supplier_name", "supplier_address",
            "business_name", "business_address",
            "business_tin", "business_contact", "business_email",
            "payment_terms", "tax_percent", "date",
            "footer_note",
        ]
        widgets = {
            "date": forms.DateInput(attrs={"type": "date"}),
        }

class PurchaseOrderItemForm(forms.ModelForm):
    class Meta:
        model = PurchaseOrderItem
        fields = ["product", "quantity_received", "unit_price"]
        widgets = {
            "quantity_received": forms.NumberInput(attrs={"min": 1, "placeholder": "Qty"}),
            "unit_price": forms.NumberInput(attrs={"step": "0.01", "placeholder": "0.00"}),
        }

    def __init__(self, *args, **kwargs):
        self.business_profile = kwargs.pop("business_profile", None)
        super().__init__(*args, **kwargs)
        if self.business_profile:
            self.fields["product"].queryset = Product.objects.filter(business_profile=self.business_profile, is_archived=False).order_by("name")
        else:
            self.fields["product"].queryset = Product.objects.none()

class PurchaseOrderItemFormSetBase(forms.BaseInlineFormSet):
    def __init__(self, *args, **kwargs):
        self.business_profile = kwargs.pop("business_profile", None)
        super().__init__(*args, **kwargs)

    def _construct_form(self, i, **kwargs):
        kwargs["business_profile"] = self.business_profile
        return super()._construct_form(i, **kwargs)

PurchaseOrderItemFormSet = inlineformset_factory(
    parent_model=PurchaseOrder,
    model=PurchaseOrderItem,
    form=PurchaseOrderItemForm,
    formset=PurchaseOrderItemFormSetBase,
    extra=0,
    can_delete=True,
    min_num=1,
    validate_min=True,
)

class SalesInvoiceForm(forms.ModelForm):
    class Meta:
        model = SalesInvoice
        fields = [
            "customer_name", "customer_address",
            "business_name", "business_address",
            "business_tin", "business_contact", "business_email",
            "date", "tax_percent", "payment_terms",
            "footer_note",
        ]
        widgets = {
            "date": forms.DateInput(attrs={"type": "date"}),
        }

class SalesInvoiceItemForm(forms.ModelForm):
    class Meta:
        model = SalesInvoiceItem
        fields = ["product", "quantity_sold", "unit_price"]
        widgets = {
            "quantity_sold": forms.NumberInput(attrs={"min": 1, "placeholder": "Qty"}),
            "unit_price": forms.NumberInput(attrs={"step": "0.01", "placeholder": "0.00"}),
        }

    def __init__(self, *args, **kwargs):
        self.business_profile = kwargs.pop("business_profile", None)
        super().__init__(*args, **kwargs)
        if self.business_profile:
            self.fields["product"].queryset = Product.objects.filter(business_profile=self.business_profile, is_archived=False).order_by("name")
        else:
            self.fields["product"].queryset = Product.objects.none()

    def clean(self):
        cleaned_data = super().clean()
        return cleaned_data

class SalesInvoiceItemFormSetBase(forms.BaseInlineFormSet):
    def __init__(self, *args, **kwargs):
        self.business_profile = kwargs.pop("business_profile", None)
        super().__init__(*args, **kwargs)

    def _construct_form(self, i, **kwargs):
        kwargs["business_profile"] = self.business_profile
        return super()._construct_form(i, **kwargs)

SalesInvoiceItemFormSet = inlineformset_factory(
    parent_model=SalesInvoice,
    model=SalesInvoiceItem,
    form=SalesInvoiceItemForm,
    formset=SalesInvoiceItemFormSetBase,
    extra=0,
    can_delete=True,
    min_num=1,
    validate_min=True,
)

class BusinessProfileForm(forms.ModelForm):
    class Meta:
        model = BusinessProfile
        fields = ["business_name", "address", "tin"]

class EcommerceSaleForm(forms.ModelForm):
    class Meta:
        model = EcommerceSale
        fields = [
            "order_id", "platform", "customer_name",
            "date", "platform_fees",
        ]
        widgets = {
            "order_id": forms.TextInput(attrs={
                "placeholder": "Paste Order ID from platform (e.g. 250313ABCXYZ)",
            }),
            "platform": forms.Select(),
            "customer_name": forms.TextInput(attrs={
                "placeholder": "Customer name (optional)",
            }),
            "date": forms.DateInput(attrs={
                "type": "date",
            }),
            "platform_fees": forms.NumberInput(attrs={
                "step": "0.01",
                "min": "0",
                "placeholder": "0.00",
            }),
        }

    def __init__(self, *args, **kwargs):
        self.business_profile = kwargs.pop("business_profile", None)
        self.instance_pk = kwargs.get("instance") and kwargs["instance"].pk
        super().__init__(*args, **kwargs)

    def clean_order_id(self):
        order_id = self.cleaned_data.get("order_id", "").strip()
        if self.business_profile:
            qs = EcommerceSale.objects.filter(
                business_profile=self.business_profile,
                order_id=order_id
            )
        else:
            qs = EcommerceSale.objects.filter(order_id=order_id)
        if self.instance_pk:
            qs = qs.exclude(pk=self.instance_pk)
        if qs.exists():
            raise forms.ValidationError(
                f'Order ID "{order_id}" already exists. Please check for duplicates.'
            )
        return order_id


class EcommerceSaleItemForm(forms.ModelForm):
    class Meta:
        model = EcommerceSaleItem
        fields = ["product", "quantity_sold", "unit_price"]
        widgets = {
            "quantity_sold": forms.NumberInput(attrs={"min": 1, "placeholder": "Qty"}),
            "unit_price": forms.NumberInput(attrs={"step": "0.01", "placeholder": "0.00"}),
        }

    def __init__(self, *args, **kwargs):
        self.business_profile = kwargs.pop("business_profile", None)
        super().__init__(*args, **kwargs)
        if self.business_profile:
            self.fields["product"].queryset = Product.objects.filter(business_profile=self.business_profile, is_archived=False).order_by("name")
        else:
            self.fields["product"].queryset = Product.objects.none()


class EcommerceSaleItemFormSetBase(forms.BaseInlineFormSet):
    def __init__(self, *args, **kwargs):
        self.business_profile = kwargs.pop("business_profile", None)
        super().__init__(*args, **kwargs)

    def _construct_form(self, i, **kwargs):
        kwargs["business_profile"] = self.business_profile
        return super()._construct_form(i, **kwargs)

EcommerceSaleItemFormSet = inlineformset_factory(
    parent_model=EcommerceSale,
    model=EcommerceSaleItem,
    form=EcommerceSaleItemForm,
    formset=EcommerceSaleItemFormSetBase,
    extra=0,
    can_delete=True,
    min_num=1,
    validate_min=True,
)

# ─────────────────────────────────────────────
#  ACCOUNTING FORMS
# ─────────────────────────────────────────────

class ExpenseForm(forms.ModelForm):
    class Meta:
        model = Expense
        fields = ["category", "amount", "date", "notes"]
        widgets = {
            "category": forms.Select(attrs={"class": "form-select"}),
            "amount": forms.NumberInput(attrs={
                "step": "0.01",
                "min": "0.01",
                "placeholder": "0.00",
                "class": "form-input",
            }),
            "date": forms.DateInput(attrs={
                "type": "date",
                "class": "form-input",
            }),
            "notes": forms.TextInput(attrs={
                "placeholder": "Optional note (e.g. May rent, Meralco bill)",
                "class": "form-input",
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["category"].queryset = ExpenseCategory.objects.all().annotate(
            sort_order=Case(
                When(name="Other", then=1),
                default=0,
                output_field=IntegerField(),
            )
        ).order_by("sort_order", "name")
        self.fields["notes"].required = False


class PaymentRecordForm(forms.ModelForm):
    class Meta:
        model = PaymentRecord
        fields = ["amount", "date", "notes"]
        widgets = {
            "amount": forms.NumberInput(attrs={
                "step": "0.01",
                "min": "0.01",
                "placeholder": "0.00",
                "class": "form-input",
            }),
            "date": forms.DateInput(attrs={
                "type": "date",
                "class": "form-input",
            }),
            "notes": forms.TextInput(attrs={
                "placeholder": "Optional note (e.g. GCash transfer, cash payment)",
                "class": "form-input",
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["notes"].required = False